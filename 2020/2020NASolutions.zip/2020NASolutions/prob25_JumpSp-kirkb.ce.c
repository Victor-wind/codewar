#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 1024
#define BUF 5

/* https://www.redblobgames.com/grids/hexagons/ */

typedef struct { int row,col; } rc_coord;
typedef struct { int x,y,z; } cube_coord;

void conv(cube,hex) cube_coord *cube; rc_coord *hex; {
 cube->x = hex->col;
 cube->z = hex->row - (hex->col + (hex->col & 1))/2;
 cube->y = -(cube->x)-(cube->z);
}

int distance(a,b) cube_coord a,b; {
return (abs(a.x-b.x) + abs(a.y-b.y) + abs(a.z-b.z))/2;
}


char name[MAX][BUF];
int coord[MAX];
int systems;
int q;
int f,t;

rc_coord frc,trc;
cube_coord fc,tc;

char from[BUF],to[BUF];

int main(argc,argv) int argc; char **argv; {
int i,j;
if(scanf("%d %d\n",&systems,&q)!=EOF) {
 for(i=0;i<systems;i++)
  scanf("%d %s\n",&coord[i],name[i]);
}
for(i=0;i<q;i++) {
 scanf("%s %s\n",from,to);
 for(f=0;f<systems;f++)
  if(strcmp(from,name[f])==0) break;
 for(t=0;t<systems;t++)
  if(strcmp(to,name[t])==0) break;

// printf("from %s %d to %s %d\n",from,coord[f],to,coord[t]);

 frc.row=coord[f]%100;
 frc.col=coord[f]/100;

 trc.row=coord[t]%100;
 trc.col=coord[t]/100;

 conv(&fc,&frc);
 conv(&tc,&trc);

 printf("%s %s %d\n",from,to,distance(fc,tc));
}

exit(0);
}

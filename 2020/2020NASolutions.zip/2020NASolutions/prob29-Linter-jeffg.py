#!/usr/bin/python3
# Jeff G
# About 50 minutes (!)
import sys
import re


class Linter(object):
    IGNORE_VARS_IN_COMMENTS = True

    def Lint(self, doc):
        """Reports all lint errors found in doc"""
        # scan for lint errors, collecting a list of tuples to hold the results
        errors = []
        for code in self.CHECKS:
            for e in self.CHECKS[code][1](self, doc):
                errors.append((e, code, f"{e}:{code} {self.CHECKS[code][0]}"))

        # python sort is stable
        errors.sort(key=lambda x: x[1])
        errors.sort(key=lambda x: x[0])
        return (e[2] for e in errors)

    def _check_unused_var(self, lines):
        """Check that declared variables are used later"""
        declared = {}
        for i, line in enumerate(lines):
            if line.strip().startswith("VAR "):
                # var declaration found, extract variable name
                v = line.strip().split(" ")[1]
                # record line number where variable was declared
                declared[v] = (False, i + 1)
            elif "$" in line:
                for v in declared:
                    if self.IGNORE_VARS_IN_COMMENTS:
                        # Paste into regex101.com or similar tool for help!
                        # Match variable "$foo" where it appears:
                        # - at the beginning of a line
                        # - or, after any number of characters that aren't "#"
                        #   and when immediately preceded by a space
                        # and
                        # - followed by a space (and then any number of characters)
                        # - or, at the end of a line
                        rexp = re.compile(f"^([^#]*\s|)\${v}(\s.*|)$")
                    else:
                        rexp = re.compile(f"^(.*\s|)\${v}(\s.*|)$")
                    if rexp.search(line):
                        # this variable is used , mark it thus
                        declared[v] = (True, None)
        # collect line numbers for any unused variables
        lines_with_errors = [v[1] for _, v in declared.items() if v[0] == False]
        return sorted(lines_with_errors)

    def _check_unexpected_indent(self, lines):
        """Check for indentation rules (non-nested)"""
        inc_keys = ("FOR", "IF", "FUNC")
        dec_keys = ("NEXT", "ENDIF", "ENDFUNC")
        indent = "    "

        lines_with_errors = []
        level = 0
        for i, line in enumerate(lines):
            # skip empty lines
            if line.strip() == "":
                continue
            if line.strip().startswith(dec_keys):
                level -= 1
            lineStartsWithSpace = line[0].isspace()
            lineIndentWrong = not line.startswith(indent * level)
            if (level == 0 and lineStartsWithSpace) or lineIndentWrong:
                lines_with_errors.append(i + 1)
            if line.strip().startswith(inc_keys):
                level += 1
        return lines_with_errors

    def _check_trailing_whitespace(self, lines):
        lines_with_errors = []
        for i, line in enumerate(lines):
            # look for trailing tab or space character (\s consumes the \n or \r\n)
            if re.search("[\t ]+[\s]+$", line):
                lines_with_errors.append(i + 1)
        return lines_with_errors

    def _check_func_docstring(self, lines):
        """Check that all FUNCtion declarations have a docstring"""
        FUNC = "FUNC "
        lines_with_errors = []
        for i, line in enumerate(lines):
            statement = line.strip()
            if statement.startswith(FUNC):
                # note: if the first line declares a function,
                # then it cannot have a valid docstring above it.
                if i > 0:
                    # using string manipulation to extract function name
                    start = len(FUNC)
                    end = statement.find("(") - 1
                    func_name = statement[start:end]
                    # check if the previous line matches required docstring syntax
                    if lines[i - 1].startswith(f"# {func_name}"):
                        # is valid
                        continue
                lines_with_errors.append(i + 1)
        return lines_with_errors

    CHECKS = {
        10: ("Variable declared but not used", _check_unused_var),
        20: ("Unexpected indentation", _check_unexpected_indent),
        30: ("Trailing whitespace", _check_trailing_whitespace),
        40: ("Func declaration without documentation", _check_func_docstring),
    }


if __name__ == "__main__":
    doc = sys.stdin.readlines()

    linter = Linter()
    result = linter.Lint(doc)

    print("\n".join(result))

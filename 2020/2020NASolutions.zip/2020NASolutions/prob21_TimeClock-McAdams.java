import java.time.LocalTime;//required to represent time objects
import java.time.temporal.ChronoUnit;//required to compare dates/times
import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required to parse split from array into List
import java.util.List;//required for List generics
import java.text.DecimalFormat;//required for rounding
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Time Clock
 * DIFFICULTY LEVEL: Intermediate
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 16 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 20-22 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-27
 * WHAT IT TESTS: 
 * 	1.) Ability to carry out basic mathematical operations
 * 	2.) Ability to convert units in order to get the correct answer
 * 	3.) Ability to work with date/time data
 *  4.) Ability to format a string/round a number
 * 	5.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# Time Clock
## (8 pts.)

Math can be tricky. You have been hired to fix the timeclock calculations for a company whose prior developer failed to account for the differences in units when calcuating the amount an employee earns for a day.

### Input

You will receive the data from the timeclock application in the format of:

    EMPLOYEE NAME (string)
    RATE ##.## (double)
    IN #### (int)
    OUT #### (int)
    IN #### (int)
    OUT #### (int)

The number of employees in the data file can number as few as one, and up to ten in a single data file. Each employee's data for the day will always contain 6 lines in the standard format (even if they only work a half-day and leave after lunch, their in-2 & out-2 times will show times of '0000')

    Example:

    EMPLOYEE JANE
    RATE 12.00
    IN 0800
    OUT 1200
    IN 1230
    OUT 1630
    EMPLOYEE MIKE
    RATE 09.99
    IN 0917
    OUT 1200
    IN 1303
    OUT 1700
    EMPLOYEE MICHELLE
    RATE 15.00
    IN 0730
    OUT 1200
    IN 0000
    OUT 0000

### Output

Run the calculations for each employee's day and output the amount they earned by multiplying the time they worked by their hourly rate. Use the employee's name, and format their day's earnings into the format of $#.00 (rounded to 2 decimal places)

    JANE earned $96.00
    MIKE earned $66.60
    MICHELLE earned $67.50

 * 	
 * */
public class prob21 {
	private static final String DEBUG_PROB_ID = "probAE";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	private static DecimalFormat df = new DecimalFormat("0.00");//global constant for rounding decimals
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same as input from problem
	 * 2.) Single employee with in/out values for AM and PM, and whole numbers for everything
	 * 3.) 2 employees, onee working all day 00:00 to 23:59, and one working very odd hours
	 * 4.) Large employee file, up to maximum stated in the problem. Each with varied times and pay rates 
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Single employee, odd pay rate, and odd hours
	 * 2.) 3 employees, each with odd pay rates, one only working a half day, the others working odd hours
	 * 3.) Large employee file, each with varied times and pay rates
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * This problem can actually be deceptively difficult. I have encountered real production code
	 * written by 'professional' programmers, which real people were using and real money was being
	 * paid as a result of -- that had the calculations for money earned vs. time worked, WRONG.
	 * (Luckily for the business it was wrong in favor of the employees, so nobody got sued) 
	 * 
	 * The problem is the mismatch in units, and counting systems. There are 60 seconds in a minute,
	 * 60 minutes in an hour, and 24 hours in a day (which makes PERFECT SENSE ... right? ... RIGHT? O_o)
	 * 
	 * US Dollars, however, have 100 cents to a dollar, and wages are usually paid as dollars per hour.
	 * 
	 * The instinct many people have is to take the total time worked and to multiply it by the rate/hour
	 * and call it a day. The problem with that is a simple divison of time worked where minutes are 
	 * included will result in the whole number hours being correct, and the minutes paying out wrong,
	 * because our number system is in base-10. The insidious thing is that SOME minute divisions done
	 * that way WILL work (specifically whole fractions such as 1/2, 1/4, 1/10, etc.) so spot-checking
	 * the calculations by hand won't always save you.
	 * 
	 * The easiest (and safest) way to solve the problem is to convert everything into the same units
	 * and THEN multiply it all out. That means reducing the hours to minutes, and then lumping all of
	 * the time worked together as minutes, and then calculating the employee's rate as dollars per 
	 * minute, instead of dollars per hour. After that it's simple arithmetic, aside from working
	 * with times. But even if the student doesn't know how to work with any fancy language-specific
	 * time classes, they could always just run the numbers manually with the knowledge of 60-60-24
	 * for times.
	 * 
	 * I chose to solve this one using a class simply to provide an example of a data-passing class 
	 * approach to solving. Could just as easily have solved it as one large "main" procedural (which
	 * is what most students will probably do)
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		runCalcs(parseEmployeeData(readFromFileInputByCommandLine()));
		//debugging
		//runCalcs(parseEmployeeData(Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt").toPath())));
	}
	/**
	 * Parses a list of employee data. Relies on the guarantee from the problem
	 * that an employee dataset will be "fixed width" and have a set number of
	 * lines. Splits the lines into sets for employees, using the EmployeeDay
	 * class, which will be passed to the final output function
	 * */
	private static List<EmployeeDay> parseEmployeeData(List<String> lines){
		List<String> tmp = new ArrayList<String>();
		List<EmployeeDay> employees = new ArrayList<EmployeeDay>();
		for(String line:lines){
			List<String> parts = Arrays.asList(line.trim().split(" "));
			if (line.indexOf("EMPLOYEE") >=0){
				if (tmp.size() > 0){
					employees.add(new EmployeeDay(tmp));
					tmp= new ArrayList<String>();
				}
			}
			tmp.add(parts.get(parts.size()-1));
		}
		employees.add(new EmployeeDay(tmp));//add final employee in the queue
		return employees;
	}
	/**
	 * Pulls the employee's name from the object, then outputs their
	 * earnings using the "earned" method on the object given the
	 * data for that day for the employee
	 * */
	private static void runCalcs(List<EmployeeDay> employees){
		for(EmployeeDay e:employees){
			System.out.println(e.name +" earned $"+df.format(e.earned()));
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}
/**
 * CLASS: EmployeeDay
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-08-22
 * PURPOSE: Simple data passing/holding class. Can be instantiated as blank, or with property values.
 * 			There is one main utility method which is used to calculate the "amount earned" for the day.
 * */
class EmployeeDay{
	/**
	 * Not used, provided for completeness*/
	public EmployeeDay()
	{
	}
	/**
	 * Assumes a String List with exactly 6 lines in it, in the order of:
	 * NAME: string
	 * RATE: double (as string)
	 * IN1 TIME: int (as string)
	 * OUT1 TIME: int (as string)
	 * IN2 TIME: int (as string)
	 * OUT2 TIME: int (as string)
	 * 
	 * The raw string data will be loaded into the private properties so
	 * the accessor methods can format the data into primitive types more
	 * suited for calculations.
	 * */
	public EmployeeDay(List<String> lines)
	{
		name = lines.get(0);
		rateRaw = lines.get(1);
		in1Raw = lines.get(2);
		out1Raw = lines.get(3);
		in2Raw = lines.get(4);
		out2Raw = lines.get(5);
	}
	/**
	 * Not used, provided for completeness*/
	public EmployeeDay(String _name, String _rate, String _in1, String _in2, String _out1, String _out2)
	{
		name = _name;
		rateRaw = _rate;
		in1Raw = _in1;
		in2Raw = _in2;
		out1Raw = _out1;
		out2Raw = _out2;
	}
	public String name ="";
	//all "raw" properties are entry points to the class for (easily) parsing in string data
	private String rateRaw = "";
	private double rate = 0.0;
	public double getRate(){
		if (!rateRaw.equalsIgnoreCase("")){
			rate = Double.parseDouble(rateRaw);
		}
		return rate;
	}
	private String in1Raw = "";
	private String in2Raw = "";
	private String out1Raw = "";
	private String out2Raw = "";
	private LocalTime in1 = LocalTime.of(0,0);
	private LocalTime in2 = LocalTime.of(0,0);
	private LocalTime out1 = LocalTime.of(0,0);
	private LocalTime out2 = LocalTime.of(0,0);
	public LocalTime getIn1(){
		if (!in1Raw.equalsIgnoreCase("") && in1Raw.length() > 3){
			int hours = Integer.parseInt(in1Raw.substring(0, 2));
			int mins = Integer.parseInt(in1Raw.substring(2));
			in1 = LocalTime.of(hours,mins);
		} 
		return in1;
	}
	public LocalTime getIn2(){
		if (!in2Raw.equalsIgnoreCase("") && in2Raw.length() > 3){
			int hours = Integer.parseInt(in2Raw.substring(0, 2));
			int mins = Integer.parseInt(in2Raw.substring(2));
			in2 = LocalTime.of(hours,mins);
		} 
		return in2;
	}
	public LocalTime getOut1(){
		if (!out1Raw.equalsIgnoreCase("") && out1Raw.length() > 3){
			int hours = Integer.parseInt(out1Raw.substring(0, 2));
			int mins = Integer.parseInt(out1Raw.substring(2));
			out1 = LocalTime.of(hours,mins);
		} 
		return out1;
	}
	public LocalTime getOut2(){
		if (!out2Raw.equalsIgnoreCase("") && out2Raw.length() > 3){
			int hours = Integer.parseInt(out2Raw.substring(0, 2));
			int mins = Integer.parseInt(out2Raw.substring(2));
			out2 = LocalTime.of(hours,mins);
		} 
		return out2;
	}
	//Easiest/best way to reliably calculate anything when multiple units are involved, is to first put everything 
	//into the same units, and THEN output in the final units once calcs are done
	public double earned()
	{
		long mins1 = ChronoUnit.MINUTES.between(getIn1(),getOut1());
		long mins2 = ChronoUnit.MINUTES.between(getIn2(),getOut2());
		double ratePerMin = getRate()/60;//converting $/hour to $/minute
		return ratePerMin * (mins1+mins2);
	}
}

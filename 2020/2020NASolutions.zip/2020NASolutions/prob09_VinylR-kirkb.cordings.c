#include <stdio.h>
#include <stdlib.h>

#define SIDE (25*60)

int main(argc,argv) int argc; char **argv; {
int min;
int sec;
int total=0;
while(scanf("%d %d",&min,&sec),min*60+sec)
 total+=min*60+sec;

if(total<=SIDE) {
 printf("Time remaining %d minutes and %d seconds\n",(SIDE*2-total)/60,(SIDE*2-total)%60);
 exit(0);
 }

if(total<=2*SIDE) {
 printf("Time remaining %d minutes and %d seconds (we'll need both sides)\n",(SIDE*2-total)/60,(SIDE*2-total)%60);
 exit(0);
 }

printf("Time remaining %d minutes and %d seconds (we're gonna need a bigger record)\n",-(total-SIDE*2)/60,-(total-SIDE*2)%60);
exit(0);
}

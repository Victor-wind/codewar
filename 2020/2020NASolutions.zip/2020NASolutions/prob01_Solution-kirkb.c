#include <stdio.h>
#include <stdlib.h>
#define LEN 256

int main(argc,argv) int argc; char **argv; {
char name[LEN];
scanf("%s",name);
printf("Welcome to CodeWars, %s!\n",name);
exit(0);
}

#!/usr/bin/python3
# probAG Mad Libs
# Solution author: jeffg, 2020
import sys
import collections

# WORDTYPE_MAP allows translation of word type headers to word type symbols
WORDTYPE_MAP = {"NOUNS": "[N]", "ADVERBS": "[AV]", "VERBS": "[V]", "ADJECTIVES": "[AJ]"}


def parse(lines):
    """
    parse mad libs raw input into:
      template - string, the mad libs sentence with symbols like "[N]"
      data     - dict, where
                   key: word type symbol
                   value: ordered list of words of type key
    """
    template = lines[0].strip()

    data = collections.defaultdict(list)
    raw_words = (x.strip() for x in lines[1:])
    for word in raw_words:
        if word in WORDTYPE_MAP:
            # "word" is header, set word type for following lines
            current_word_type = WORDTYPE_MAP[word]
        else:
            # "word" is actually a word, add to appropriate category
            data[current_word_type].insert(0, word)
    return template, data


def render(template, data):
    """
    render template by replacing symbols with a word from data,
    removing the used words from data (updates "data" in-place)
    """
    for word_type in data:
        while word_type in template:
            template = template.replace(word_type, data[word_type].pop(), 1)
    return template 


if __name__ == "__main__":
    template, data = parse(sys.stdin.readlines())
    for _ in range(2):
        result = render(template, data)
        print(result)

#include <stdio.h>
#include <stdlib.h>
#define DIM 11
int dim=DIM;
int debug=0;
int solutions=0;

typedef char brd[DIM][DIM];
brd boards[DIM*DIM];
brd board;
brd copy;

void dump(b) brd b; {
int r,c;
for(r=0;r<dim;r++){
 for(c=0;c<dim;c++)
  putchar(b[r][c]);
 printf("\n");
 }
}

void dup(t,f) brd t,f; {
int d;
for(d=0;d<dim*dim;d++) t[d/dim][d%dim]=f[d/dim][d%dim];
}

int flood(copy,r,c,p,q) brd copy; int r,c; char p,q; {
copy[r][c]=q;
if((r>      0)&&((copy[r-1][c]==p)||(copy[r-1][c]=='?'))) {copy[r-1][c]=q;flood(copy,r-1,c,p,q);}
if((r<(dim-1))&&((copy[r+1][c]==p)||(copy[r+1][c]=='?'))) {copy[r+1][c]=q;flood(copy,r+1,c,p,q);}
if((c>      0)&&((copy[r][c-1]==p)||(copy[r][c-1]=='?'))) {copy[r][c-1]=q;flood(copy,r,c-1,p,q);}
if((c<(dim-1))&&((copy[r][c+1]==p)||(copy[r][c+1]=='?'))) {copy[r][c+1]=q;flood(copy,r,c+1,p,q);}
}

int legalFlood(board) brd board;{
int d;
char p;
int f;
brd copy;

dup(copy,board);
for(d=0;(d<dim*dim)&&(copy[d/dim][d%dim]!='.');d++);
p=copy[d/dim][d%dim];
flood(copy,d/dim,d%dim,p,'X');
for(f=1,d=0;f&&d<dim*dim;d++)
 f=f&&(copy[d/dim][d%dim]!=p);
if(!f&&debug) {
printf("FLOODED with .->X @ %d,%d\n",d/dim,d%dim);
dump(copy);
}
if(f) {
dup(copy,board);
for(d=0;(d<dim*dim)&&(copy[d/dim][d%dim]!='#');d++);
p=copy[d/dim][d%dim];
flood(copy,d/dim,d%dim,p,'X');
for(f=1,d=0;d<dim*dim;d++)
 f=f&&(copy[d/dim][d%dim]!=p);
if(!f&&debug){
printf("FLOODED with #->X@ %d,%d\n",d/dim,d%dim);
dump(copy);
}
}

return(f);
}

int legalIslands(board,d)brd board;int d;{
int f=1;
int r,c;
int t;
int o;

for(r=0;f&&(r<dim);r++)
 for(c=0;f&&(c<dim);c++) {
  if((r*dim+c)>d) break;
  if(board[r][c]=='?') continue;

  t = 0;
  o = 4;

  if(r==0) o--; if(r==(dim-1)) o--;
  if(c==0) o--; if(c==(dim-1)) o--;

  t += ((r>0      )&&((board[r][c]==board[r-1][c])||('?'==board[r-1][c])));
  t += ((r<(dim-1))&&((board[r][c]==board[r+1][c])||('?'==board[r+1][c])));
  t += ((c>0      )&&((board[r][c]==board[r][c-1])||('?'==board[r][c-1])));
  t += ((c<(dim-1))&&((board[r][c]==board[r][c+1])||('?'==board[r][c+1])));
  f = f && (t>0);

  if(!f) {
//   printf("island @ %d,%d=%c, t=%d, o=%d\n",r,c,board[r][c],t,o);
   //dump(board);
   }
   
 }
return f;
}


int legalEdge(board)brd board;{
int i;
int c;
for(c=i=0;i<dim;i++) {
 c+=(board[0][i]=='#');
 c+=(board[dim-1][i]=='#');
 c+=((i>0)&&(i<(dim-2)))?(board[i][0]=='#'):0;
 c+=((i>0)&&(i<(dim-2)))?(board[dim-1][i]=='#'):0;
}
return (c<(dim*2+(dim-2)*2));
}

int legalBlocks(board,d)brd board;int d; {
int r,c;
int f;
int a,b;

for(f=1,r=0;f&&r<(dim-1);r++) 
 for(c=0;f&&c<(dim-1);c++) {
 if((r*dim+c)>d) break;
  a=
  (
  (board[r][c]=='#') +
  (board[r+1][c]=='#') +
  (board[r][c+1]=='#') +
  (board[r+1][c+1]=='#')
  );

  b=
  (
  (board[r][c]=='.') +
  (board[r+1][c]=='.') +
  (board[r][c+1]=='.') +
  (board[r+1][c+1]=='.')
  );

  f=f&&(a <4);
  f=f&&(b <4);
  if(
   (board[r][c]==board[r+1][c+1]) &&
   (board[r+1][c]==board[r][c+1]) &&
   (board[r][c]!=board[r][c+1]) &&
   ((a+b)==4)
  ) {
//   dump(board);
//   printf("Checkerboard @ %d,%d\n",r,c);
   f=0;
   }
 }

return f;
}

int vc(board,d) brd board;int d;{
int f[4];
int r=d/dim;
int c=d%dim;

f[0]=legalEdge(board); if(!f[0]) printf("illegal edge\n");
f[1]=legalBlocks(board,r*dim+c); if(!f[1]) printf("illegal blocks\n");
f[2]=legalIslands(board,r*dim+c); if(!f[2]) printf("illegal islands\n");
f[3]=legalFlood(board);  if(!f[3]) printf("illegal flood\n");

return(f[0]&&f[1]&&f[2]&&f[3]);
}


int onceOver(board) brd board; {
int r,c;
int sets=0;
int a,b;

for(r=0;r<dim;r++)
 for(c=0;c<dim;c++)
  if(board[r][c]=='?') {

   board[r][c]='.';
   a=legalEdge(board)&&legalBlocks(board,r*dim+c)&&legalIslands(board,r*dim+c)&&legalFlood(board);

   board[r][c]='#';
   b=legalEdge(board)&&legalBlocks(board,r*dim+c)&&legalIslands(board,r*dim+c)&&legalFlood(board);

   board[r][c]='?';

   if(a && !b) {board[r][c]='.';sets++; if(debug) printf("\tforced . @ %d,%d\n",r,c); }
   if(!a && b) {board[r][c]='#';sets++; if(debug) printf("\tforced # @ %d,%d\n",r,c); }

   if(!a && !b) { 
    if(debug) printf("aborted %d,%d, no legal moves\n",r,c);
    return -1;
    }
  }

return sets;
}

void play(b,d) brd b; int d; {
int r,c;
brd board;
brd once;

if(debug) {
printf("D=%d\n",d);
dump(b);
}

if((d==dim*dim )){
  dump(b);
  exit(0);
 }

else {
 r=0;
 dup(once,b);
 while((c=onceOver(once))>0)
  if(debug) printf("\tD=%d %d: Found %d forced moves\n",d,r++,c);

 if(c>=0) {
  
 if(r&&debug) {
  printf("from:\n");
  dump(b);
  printf("to:\n");
  dump(once);
  }

 r=d/dim;
 c=d%dim;

 dup(board,once);
 if(board[r][c]!='?') 
  play(board,d+1);
 else {
  board[r][c]='#'; //(d%2)?'.':'#';
  if(legalEdge(board)&&legalBlocks(board,r*dim+c)&&legalIslands(board,r*dim+c)&&legalFlood(board))
   play(board,d+1);
  board[r][c]='.'; //(d%2)?'#':'.';
  if(legalEdge(board)&&legalBlocks(board,r*dim+c)&&legalIslands(board,r*dim+c)&&legalFlood(board))
   play(board,d+1);
 }
}
}
}

int main(argc,argv) int argc; char **argv; {
int r,c;
brd board;
char buf[32];
if(argc>1) debug=1;

for(r=0;r<DIM;r++) for(c=0;c<DIM;c++) board[r][c]=copy[r][c]='_';

if(scanf("%d\n",&dim)!=EOF)
for(r=0;r<dim;r++) {
 if(fgets(buf,31,stdin))
  for(c=0;c<dim;c++)
   board[r][c]=buf[c];
} 
play(board,0);
exit(0);
}

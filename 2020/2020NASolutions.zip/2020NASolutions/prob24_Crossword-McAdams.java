import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required to cast list to array
import java.util.Collections;
import java.util.List;//required for List generics
import java.awt.Point;//required for Points
import java.awt.geom.*;//required for Lines
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Crossword
 * DIFFICULTY LEVEL: Intermediate
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 20 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 22-25 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-27
 * WHAT IT TESTS: 
 * 	1.) Ability to track 2-dimensional data (X,Y grid)
 * 	2.) Ability to keep track of multiple sets of data concurrently
 * 	3.) Ability to use the same set of information multiple times as dictated by the logic of the problem
 *  4.) Ability to either use arrays or Lists to organize sets of data
 * 	5.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# Crossword
## (10 pts.)

The regional crossword puzzler competition is coming up, and your team is in training. In order to practice for the competition, your team is making their own puzzles. The puzzle grid is always a 11x11 grid, with (0,0) in the upper left corner. As the only programmer on your team, it falls to you to sanity check the puzzles to make sure everything fits.

### Input

You will receive a 3-part dataset separated by 6 hyphens on a line alone "------". The first section are the list of spaces for the puzzle in the format of: N V #1 #2 #3 where:

    N = the number of the word (from the puzzle)
    V = orientation (H: horizontal, V: vertical)
    #1 = Length of the space
    #2 = X coordinate of start of space
    #3 = Y coordinate of start of space

The second section lists the coordinates of given letters in the puzzle in the format of: #1 #2 C where:

    #1 = X coordinate of the letter
    #2 = Y coordinate of the letter
    C = the letter

The third section lists all possible words for the puzzle. Here is an example of a complete dataset:

    1 H 5 1 0
    2 V 4 3 0
    3 H 9 2 3
    4 V 6 5 3
    5 H 3 4 7
    -------
    3 0 P
    3 3 L
    5 3 A
    5 7 Y
    -------
    PICKLE
    APPLE
    WALRUS
    PEEL
    ALMAMATER
    COLLEGE
    ALWAYS
    AYE

### Output

Your program should output the number of the puzzle space, and the word that fits in the space both by length and 
which matches the given known letters from section 2 of the dataset. List the output in ascending (smallest to 
largest from the top) order. List all space numbers with a leading zero if they are not 2 digits long

    01 is APPLE
    02 is PEEL
    03 is ALMAMATER
    04 is ALWAYS
    05 is AYE
	
 * 	
 * */
public class prob24 {
	private static final String DEBUG_PROB_ID = "probAA";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Standard crossword puzzle
	 * 2.) Standard crossword puzzle, has some floating elements
	 * 3.) Standard crossword puzzle
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Standard crossword puzzle
	 * 2.) Standard crossword puzzle
	 * 3.) Standard crossword puzzle, has some floating elements
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * This is intended as a problem of intermediate difficulty mostly due to the necessity of
	 * keeping track of the spaces the words must fit into in 2-dimensional space, while ALSO
	 * keeping track of the known letters for the puzzle.
	 * 
	 * There are a large number of ways to accomplish this, from simple loops and arrays to
	 * full-blown applications. I chose to solve it using classes (because Java ^_-) which
	 * represent the parts of the problem, and know how to solve various aspects of the overall
	 * problem, by being able to tell you if a letter's coordinates fall inside the space for
	 * a word, or whether a full word fits into a space or not.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
		System.exit(0);
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-student-2-in.txt").toPath());
		List<WordSpace> spaces = new ArrayList<WordSpace>();
		List<String> words = new ArrayList<String>();
		List<String> output = new ArrayList<String>();
		int counter = 0;
		for(String line:lines){
			if (line.equals("-------")){
				counter++;
			}
			else{
				if (counter == 0){
					spaces.add(new WordSpace(line.trim()));
				}
				else if (counter == 1){
					Letter l = new Letter(line);
					for(WordSpace s:spaces){
						s.contains(l);
					}
				}
				else{
					words.add(line.trim());
				}
			}
		}
		for (String word:words){
			for(WordSpace w:spaces){
				if (w.fits(word)){
					output.add(String.format("%02d",w.No)+" is "+word);
				}
			}
		}
		Collections.sort(output);
		for(String foundWord:output){
			System.out.println(foundWord);
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}
/**
 * CLASS: WordSpace
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-08-22
 * PURPOSE: represents a space for a word on the puzzle grid. Keeps track of the:
 * Number of the space: No
 * X coordinate of the start of the space: X
 * Y coordinate of the state of the space: Y
 * Length of the space: Len
 * Whether or the space runs vertical or not: isVertical
 * Also has utility methods to help the main program determine what fits in the space
 * */
class WordSpace{
	public WordSpace()
	{
	}
	public WordSpace(int n, boolean o, int l, int x, int y)
	{
		No = n;
		isVertical = o;
		Len = l;
		X = x;
		Y = y;
	}
	/**
	 * Assumes input in format of:
	 * N V 1 2 3
	 * Where:
	 * N = the number of the word (from the puzzle)
	 * V = orientation (H: horizontal, V: vertical)
	 * 1 = Length of word
	 * 2 = X coordinate of start of word
	 * 3 = Y coordinate of start of word
	 * */
	public WordSpace(String line){
		List<String> parts = Arrays.asList(line.split(" "));
		if (parts.size() == 5){
			No = Integer.parseInt(parts.get(0));
			if (parts.get(1).equalsIgnoreCase("V")){
				isVertical = true;//false by default
			}
			Len = Integer.parseInt(parts.get(2));
			X = Integer.parseInt(parts.get(3));
			Y = Integer.parseInt(parts.get(4));
		}
	}
	public int No = 0;
	public int X = 0;
	public int Y = 0; 
	public int Len = 0;
	public boolean isVertical = false;
	//represents the area the space takes up on the grid as a "line", calculated from the
	//X,Y start coordinate, the length of the space, and whether or not it runs vertically
	private Line2D thisLine(){
		//have to subtract 1 from length because our grid is zero-based
		if (isVertical){
			//X will stay the same, Y will grow
			return new Line2D.Double(X,Y,X,(Y+(Len-1)));
		}
		else{
			//Y will stay the same, X will grow
			return new Line2D.Double(X,Y,(X+(Len-1)),Y);
		}
	}
	//A list of the letters given in the puzzle which the space contains
	private List<Letter> knownLetters = new ArrayList<Letter>();
	//True if the coordinates for the letter intersect with the coordinates of the space (inclusive)
	public boolean contains (Letter l){
		return contains(l.X,l.Y,l.letter);
	}
	//given a Letter (l) which exists in this word space, get the (0-indexed)
	//index for that letter given the coordinates for the letter, and the
	//coordinates for the word space
	private int getIndex(Letter l){
		int index = 0;
		if (isVertical){
			//count on Y axis
			index = l.Y-this.Y;
		}
		else{
			//count on X axis
			index = l.X-this.X;
		}
		return index;
	}
	//Given a string for a word, determine if it fits in the WordSpace
	//taking into account the known letters the word must contain, and
	//the coordinates for those letters.
	public boolean fits(String word){
		boolean result = false;
		if (word.length() == Len){
			result = true;
			for(Letter l:knownLetters){
				String c = word.substring(getIndex(l), getIndex(l)+1);
				if (!c.equalsIgnoreCase(l.letter)){
					result = false;
					break;
				}
			}
		}
		return result;
	}
	//given X & Y coordinates for a letter (C) determine if the coordinates
	//for the letter fall inside the coordinates for the WordSpace (inclusive)
	//using Line2D objects and the built-in "intersectsLine" method, by
	//creating a line from the coordinates as a line of size 0 with beginning
	//and ending coordinates the same
	public boolean contains(int x, int y, String c){
		Point p = new Point(x,y);
		Line2D pLine = new Line2D.Double(p,p);
		Line2D line = thisLine();
		boolean result =line.contains(p) || line.intersectsLine(pLine);
		if (result){
			boolean foundLetter = false;
			for(Letter l:knownLetters){
				if (l.Equals(new Letter(x,y,c))){
					foundLetter = true;
					break;
				}
			}
			if (!foundLetter){
				knownLetters.add(new Letter(x,y,c));
			}
		}
		return result;
	}
}
/**
 * CLASS: Letter
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-08-22
 * PURPOSE: Represents a known letter in the puzzle which is contained in
 * at least one of the WordSpaces in the puzzle. Keeps track of:
 * The X coordinate of the letter: X
 * The Y coordinate of the letter: Y
 * The letter itself: letter
 * Provides one utility method to determine equality with another letter by
 * comparing all 3 main properties (X,Y,letter). All 3 must match for the
 * objects to be considered equal.
 * */
class Letter{
	public Letter()
	{
	}
	public Letter(int x, int y, String l)
	{
		X = x;
		Y = y;
		letter = l;
	}
	/** Assumes input in format of:
	 * 1 2 C
	 * Where:
	 * 1 = X coordinate of the letter
	 * 2 = Y coordinate of the letter
	 * C = the letter
	 * */
	public Letter(String line){
		List<String> parts = Arrays.asList(line.split(" "));
		if (parts.size() == 3){
			X = Integer.parseInt(parts.get(0));
			Y = Integer.parseInt(parts.get(1));
			letter = parts.get(2);
		}
	}
	public int X = 0;
	public int Y = 0; 
	public String letter = "";
	public boolean Equals(Letter that){
		return (this.X==that.X && this.Y==that.Y && this.letter.equals(that.letter));
	}
}

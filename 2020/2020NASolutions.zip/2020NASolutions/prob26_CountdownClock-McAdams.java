import java.util.Scanner;//required for I/O from stdin
import java.time.LocalDateTime;//required for DateTime parsing
import java.time.format.DateTimeFormatter;//required for DateTime parsing
import java.time.temporal.ChronoUnit;//required for doing date length calculations
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required to parse split from array into List
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Countdown Clock
 * DIFFICULTY LEVEL: Difficult
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 30 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 35-40 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-27
 * WHAT IT TESTS: 
 * 	1.) Ability to work with dates AND times
 * 	2.) Ability to understand total time per unit, and to convert units
 * 	3.) Ability to output and format dates and times
 *  4.) Ability to work with, and keep track of (requires a logic structure), various types of units for dates and times
 * 	5.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# Countdown Clock
## (15 pts.)

You're going skiing in Nagano! You created a countdown clock so you can see just how long you have to wait until your trip. Now your friends have seen your coundown clock, and they want their own! You decide to generalize your countdown clock code to pull the start and end date from a configuration file, so anyone can use it and put in their own custom dates and times.

## Formatting

Your program needs to handle a dataset of dates and times, with one beginning date/time and ending date/time per line. The lines will be in the format of:

    yyyy-MM-dd HH:mm:ss yyyy-MM-dd HH:mm:ss DHMS

The leftmost date and time should be taken together to be the "start" date, and the rightmost date and time are the "end" date. The DHMS tell you how to output the remaining time. You are guaranteed to receive at least one "D" or "H" or "M" or "S" (possibly up to all 4 together). The D,H,M,S output format flags may be listed in any order.

    D = output total remaining whole days (ignoring hours, minutes, seconds)
    H = output total remaining hours (ignoring days, minutes, seconds)
    M = output total remaining minutes (ignoring days, hours, seconds)
    S = output total remaining seconds (ignoring days, hours, minutes)

The output formats can also be combined (in which case they need to subtract from the output any time already output as part of a larger "unit". E.G. if 49 hours are remaining, and the output asks for DH output:

    2 days 1 hour, taking into account the 24 hours/day when outputting the hours

Other combinations:

    DH = output total remaining days + total remaining hours (less the time output as days)
    DHM = output total remaining days + total remaining hours (less the time output as days) + total remaining minutes (less the time output as hours)
    DHMS = output total remaining days hours minutes and seconds, each taking into account prior time already accounted for

    Any output not asked for being output as a whole number (E.G. if there are 61 seconds to output, but the format only calls for minutes, leaving 1 second left over) discard the remainder of non whole-number time units

### Input

Here are some sample input lines from a dataset (note, your program will only ever receive 5 lines at a time, except for the example file showing all 12 combinations of output types)

    2019-01-01 00:00:00 2019-02-01 01:01:01 D
    2019-01-01 00:00:00 2019-02-01 01:01:01 H
    2019-01-01 00:00:00 2019-02-01 01:01:01 M
    2019-01-01 00:00:00 2019-02-01 01:01:01 S
    2019-01-01 00:00:00 2019-02-01 01:01:01 DHMS
    2019-01-01 00:00:00 2019-02-01 01:01:01 HMS
    2019-01-01 00:00:00 2019-02-01 01:01:01 MS
    2019-01-01 00:00:00 2019-02-01 01:01:01 DH
    2019-01-01 00:00:00 2019-02-01 01:01:01 DM
    2019-01-01 00:00:00 2019-02-01 01:01:01 DS
    2019-01-01 00:00:00 2019-02-01 01:01:01 HM
    2019-01-01 00:00:00 2019-02-01 01:01:01 HS

### Output

Output the remaining time until the countdown finishes, taking care to output the largest units first, and subtract those units of time from the remaining units output, in sequence.

    there are 31 days remaining until 2019-02-01 01:01:01
    there are 745 hours remaining until 2019-02-01 01:01:01
    there are 44701 minutes remaining until 2019-02-01 01:01:01
    there are 2682061 seconds remaining until 2019-02-01 01:01:01
    there are 31 days 1 hours 1 minutes 1 seconds remaining until 2019-02-01 01:01:01
    there are 745 hours 1 minutes 1 seconds remaining until 2019-02-01 01:01:01
    there are 44701 minutes 1 seconds remaining until 2019-02-01 01:01:01
    there are 31 days 1 hours remaining until 2019-02-01 01:01:01
    there are 31 days 61 minutes remaining until 2019-02-01 01:01:01
    there are 31 days 3661 seconds remaining until 2019-02-01 01:01:01
    there are 745 hours 1 minutes remaining until 2019-02-01 01:01:01
    there are 745 hours 61 seconds remaining until 2019-02-01 01:01:01

 * 	
 * */
public class prob26 {
	private static final String DEBUG_PROB_ID = "probAJ";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Tests single time-keeeping output: days, hours, minutes, seconds, and then all combined
	 * 3.) Tests doubling up of a lot of the time-keeping units, and one triple
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Single test for days and seconds time-keeping output
	 * 2.) Single test for minutes and seconds time-keeping output
	 * 3.) Single test for hour output
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * Another date/time problem, and another headache. The main sticking point on this problem
	 * (besides the difficulty of working with dates and times) will be in understanding the 
	 * output formats, and knowing that the output asks only for days, to throw the rest of the
	 * time away. However, if it asks for days AND hours, then to output the whole days, and then
	 * the whole hours, and then throw the rest away, etc. It requires a level of precision and
	 * attention to detail that some beginning students may struggle with. Students working in
	 * a language without a built-in date/time language-level provided set of tools (such as C) 
	 * will be particularly challenged on this one. Hence the higher time cost and higher 
	 * difficulty rating.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt").toPath());
		for(String line:lines){
			System.out.print("there are ");
			List<String> parts = Arrays.asList(line.trim().split(" "));
			if (parts.size() > 4){
				LocalDateTime date1 = LocalDateTime.parse(parts.get(0).trim() + " " + parts.get(1).trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
				LocalDateTime date2 = LocalDateTime.parse(parts.get(2).trim() + " " + parts.get(3).trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
				List<String> format = Arrays.asList(parts.get(4).trim().split("|"));
				boolean haveDays = false;
				boolean haveHours = false;
				boolean haveMins = false;
				//Java does not provide an (easy) way to output the total vs. remaining date/time parts for a timespan. Easiest
				//way to do it is self-calcs
				for(String f:format){
					switch (f) {
		            	case "D":
		            		haveDays = true;
		            		long days = ChronoUnit.DAYS.between(date1,date2);
		            		System.out.print(days+" days ");
		            		break;
		            	case "H":
		            		haveHours = true;
		            		long hours = ChronoUnit.HOURS.between(date1,date2);
		            		if (haveDays)
		            		{
		            			while (hours >= 24)
		            			{
		            				hours -= 24;
		            			}
		            		}
		            		System.out.print(hours+" hours ");
		            		break;
		            	case "M":
		            		haveMins = true;
		            		long mins = ChronoUnit.MINUTES.between(date1,date2);
		            		if (haveDays)
		            		{
		            			while (mins >= 1440)
		            			{
		            				mins -= 1440;
		            			}
		            		}
		            		if (haveHours)
		            		{
		            			while (mins >= 60)
		            			{
		            				mins -= 60;
		            			}
		            		}
		            		System.out.print(mins+" minutes ");
		            		break;
		            	case "S":
		            		long seconds = ChronoUnit.SECONDS.between(date1,date2);
		            		long m = 60;
		            		long h = m*60;
		            		long d = h*24;
		            		if (haveDays)
		            		{
		            			while (seconds >= d)
		            			{
		            				seconds -= d;
		            			}
		            		}
		            		if (haveHours)
		            		{
		            			while (seconds >= h)
		            			{
		            				seconds -= h;
		            			}
		            		}
		            		if (haveMins)
		            		{
		            			while (seconds >= m)
		            			{
		            				seconds -= m;
		            			}
		            		}
		            		System.out.print(seconds+" seconds ");
		            		break;
					}
				}
				System.out.println("remaining until "+date2.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
			}
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

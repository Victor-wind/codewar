import sys
import math
#PROBLEM: Hordak's Boss
#DIFFICULTY LEVEL: Easy
#TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 2 minutes
#ESTIMATED STUDENT COMPLETION TIME NEEDED: < 5 minutes
#PROBLEM AUTHOR: Anil Mishra & Nittin Aggarwal
#SOLUTION AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
#LAST MODIFIED: 2020-01-22
#WHAT IT TESTS: 
#	1.) Understanding what a prime number is
#	2.) Outputting string and number data together
#	3.) Having branching "end conditions"
#	4.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
# 
#PROBLEM DESCRIPTION: 
# 
# # Hordak's Boss
# ## (2 pts.)
# Julia is working on an encryption algorithm which uses the factors of prime numbers for the basis of its one-way hashing. The first step she needs to solve for her algorithm is determining if her random number generator (RNG) is sending prime numbers or not. So she needs to code a prime number tester.
# Read in the number from the RNG, stop reading when the word "STOP" is read. Then test the number to determine if it is Prime or not. A Prime number is only evenly divisible by the number 1, and itself.
# Print # is PRIME if the number being tested is Prime.  
# Else, print # is NOT Prime.  
# Where # is the number being tested.  
# ### Input
#     6
# 	STOP
# ### Output
#     6 is NOT Prime.
#
debugging = False
problemID = "BJ"
#SOLUTION:
#----------------------------------------------------------------------------------------
#STUDENT DATA:
#----------------------------------------------------------------------------------------
#1.) Data from problem example, simple case (not prime)
#2.) A large number (not prime)
#3.) A very large prime number (won't overflow a standard 32-bit integer)
#----------------------------------------------------------------------------------------
#JUDGE DATA:
#----------------------------------------------------------------------------------------
#1.) Simple prime number
#2.) Large (non-prime) number
#3.) Almost a prime number (off by a few digits), but not quite
#----------------------------------------------------------------------------------------
#NOTES:
#
#This is intended as a problem of beginner difficulty. It is basically a math problem.
#All of the needed information to solve it is given in the problem though, so no special
#math knowledge is needed to program a solution for it. MY solution uses some time-saving
#tricks to make the Prime-testing faster, but brute-force testing every number 1-n of the
#test of n as Prime won't hurt a student's code's performance in the contest, given the
#size of the numbers they will be working with.
#
#The solution provided only uses libraries found in the standard Python installation,
#no external modules or 3rd party libraries are used.
#*/
#----------------------------------------------------------------------------------------
try:
	#------------------------------------------------------------------------------------
    # FUNCTION: isPrime
    # PURPOSE: determines if a number 'n' is Prime or not
    # INPUT PARAMETER: n (int): the number to check
    # PRECONDITIONS: none
    # POSTCONDITIONS: returns True if Prime, False otherwise
    # AUTHOR: Robert McAdams, mcadams@hpe.com
    # LAST MODIFIED: 2020-01-22
	def isPrime(n):
		if(n < 2): return False #zero and 1 are not considered prime
		if(n < 4): return True #2 and 3 are considered prime
		if(n % 2 == 0): return False #if it can be evenly divided by 2, then it has 2 as a factor, so not prime
		squareRoot = math.sqrt(n) #using square root as a ceiling for division check, after that point, we would simply be checking factors of the same base numbers. High school students most likely wouldn't know about this shortcut, but that's okay, the numbers they will be using won't run into performance issues that are measurable anyway :D
		sqrtCeiling = int(math.ceil(squareRoot)) #taking the ceiling of the square root because for loops require ints
		i = 3
		while (i <= sqrtCeiling): #starting with 3, and incrementing by 2 so all checks will be on odd numbers
			if(n % i == 0): return False #if we ever find a number that we can divide into the number evenly, it isn't prime
			i+=2
		return True #if we get here, nothing failed the test, so it is prime
	#------------------------------------------------------------------------------------
    # FUNCTION: main
    # PURPOSE: main program, gets the data and runs the operations
    # PRECONDITIONS: none
    # POSTCONDITIONS: program has executed
    # AUTHOR: Robert McAdams, mcadams@hpe.com
    # LAST MODIFIED: 2020-01-22
	def main():
    	#--------------------------------------------------------------------------------
		#LOAD THE DATA
		lines = []
		if (debugging):
			#r"" instructs the linter to treat the string as a literal, and not to parse it
			f = open(r"data\prob"+problemID+"-student-3-in.txt", "r")
			for line in f:
				lines.append(line.rstrip().strip())
		else:
			for line in sys.stdin:
				lines.append(line.rstrip().strip())
		#--------------------------------------------------------------------------------
		for line in lines:
			if (line != "STOP"):
				num = int(line.strip())
				if (isPrime(num)):
					print(f'{num} is PRIME')
				else:
					print(f'{num} is NOT Prime')
	#------------------------------------------------------------------------------------
	main()
except:
	e = sys.exc_info()[0]
	print("bad things happened: "+str(e))

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define POWER 0
#define MULTIPLY 1
#define DIVIDE 2
#define ADD 3
#define SUBTRACT 4

#define LINES 5

char *cmds[5] = { "POWER", "MULTIPLY", "DIVIDE", "ADD", "SUBTRACT"};
char symbol[5] = "^*/+-";

double calc(cmd,a,b,op) char *cmd; int a,b,*op; {
int i;

if(strcmp(cmd,cmds[*op=POWER])==0) return pow((double)a,(double)b);
if(strcmp(cmd,cmds[*op=MULTIPLY])==0) return (double)a*(double)b;
if(strcmp(cmd,cmds[*op=DIVIDE])==0) return (double)a/(double)b;
if(strcmp(cmd,cmds[*op=ADD])==0) return (double)a+(double)b;
if(strcmp(cmd,cmds[*op=SUBTRACT])==0) return (double)a-(double)b;

printf("Error: unknown command: %s\n",cmd);
exit(1);
}

int main(argc,argv) int argc; char **argv; {
int a,b;
int op;
char cmd[32];
double result;
double check;

int i;

for(i=0;i<LINES;i++) {
 if(scanf("%d %d %s %lf",&a,&b,cmd,&result)==EOF) exit(0);
 result=round(result*10.0)/10.0;
 check=calc(cmd,a,b,&op);
 check=round(check*10.0)/10.0;
 if(check==result)
  printf("%.1lf is correct for %.1lf %c %.1lf\n",check,(double)a,symbol[op],(double)b); 
 else
  printf("%.1lf %c %.1lf = %.1lf, not %.1lf\n",(double)a,symbol[op],(double)b,check,result);
}
}

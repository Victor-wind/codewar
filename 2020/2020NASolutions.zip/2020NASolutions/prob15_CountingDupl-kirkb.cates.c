#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define WORDS 256
#define LEN 256
int main(argc,argv) int argc; char **argv; {
int l[2];
int i,j,k,n;

char words[2][WORDS][LEN];
char common[WORDS][LEN];
int c;

while(scanf("%d %d",&l[0],&l[1]),(l[0]!=0)&&(l[1]!=0)) {
c=0;
for(i=0;i<2;i++) 
 for(j=0;j<l[i];j++)
  scanf("%s", words[i][j]);
for(i=0;i<2;i++)
 for(j=0;j<l[i];j++)
  for(k=0;k<l[!j];k++)
   if(strcasecmp(words[i][j],words[!i][k])==0) {
    for(n=0;n<c;n++)
     if(strcasecmp(common[n],words[i][j])==0) break;
    if(n==c) {
     strcpy(common[n],words[i][j]);
     c++;
    }
   }
for(i=0;i<2;i++)
 for(j=0;j<l[i];j++)
  printf("%s%s",words[i][j],(j==(l[i]-1))?"\n":" ");
printf("%d ",c);
for(i=0;i<c;i++)
 printf("%s%s",common[i],(i==(c-1))?"\n":" ");
}

exit(0);
}

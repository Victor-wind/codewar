import sys
#PROBLEM: Problem 1
#DIFFICULTY LEVEL: Very Easy
#TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: < 1 minutes
#ESTIMATED STUDENT COMPLETION TIME NEEDED: < 1 minutes
#PROBLEM AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
#LAST MODIFIED: 2020-05-06
#WHAT IT TESTS: 
#	1.) Basic 'hello world' coding ability, e.g. "can you get any kind of program at all to run on your environment?"
#	2.) Basic file I/O, e.g. "can you read data in from a file?"
# 
#PROBLEM DESCRIPTION: 
# 
# Input will consist of a single line with a single word that is your new friend's first name.
# Harvey
#
# Welcome your new friend to CodeWars in the message format shown below, including the name you received as input.
# Welcome to CodeWars, Harvey!
try:
    debugging = False
    problemID = "01"
    #------------------------------------------------------------------------------------
    # FUNCTION: main
    # PURPOSE: main program, gets the data and runs the operations
    # PRECONDITIONS: none
    # POSTCONDITIONS: program has executed
    # AUTHOR: Robert McAdams, mcadams@hpe.com
    # LAST MODIFIED: 2020-05-06
    def main():
    	#--------------------------------------------------------------------------------
		#LOAD THE DATA
        lines = []
        if (debugging):
            #r"" instructs the linter to treat the string as a literal, and not to parse it
            f = open(r"data\prob"+problemID+"-judge-1-in.txt", "r")
            for line in f:
                lines.append(line.rstrip().strip())
        else:
            for line in sys.stdin:
                lines.append(line.rstrip().strip())
		#--------------------------------------------------------------------------------
        if (len(lines) >= 1):
            print(f'Welcome to CodeWars, {lines[0]}!')
        else:
            print('error, data missing')
	#------------------------------------------------------------------------------------
    main()
except:
	e = sys.exc_info()[0]
	print("bad things happened: "+str(e))

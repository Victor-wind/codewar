#!/usr/bin/python3
# Cyclops Number
# Solution author: jeffg, 2020
# Alternative string manipulation approach. This is a bit of a trick.
# A good question to ask is "why does this answer correctly for even numbers?"
import sys

def isCyclops(num):
    sNum = bin(num)[2:]
    half = len(sNum) // 2
    side = "1" * half
    return sNum == side + "0" + side

if __name__ == "__main__":
    for num in map(int, sys.stdin):
        ans = "yes" if isCyclops(num) else "no"
        print(num, ans)

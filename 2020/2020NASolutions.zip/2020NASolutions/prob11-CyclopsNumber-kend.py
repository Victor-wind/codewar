# Cyclops Number
#    Does the binary representation of a number have a single zero in the middle?
# 
# Recursively divide by 2
#  - Count the number of 0 bits and 1 bits
#  - When a zero is found mark its location to see if it's in the middle
import sys

debugPrint = False
def countBits(num,ones,zeros,zeroloc):
    if debugPrint:
        print("Received:",num,ones,zeros,zeroloc)
    if num==0: # Special case
        return 0,1,1
    if zeroloc>0:
        zeroloc=zeroloc+1
    if num==1: # End of search
        return ones+1,zeros,zeroloc
    bit = num%2
    if bit==0:
        zeros = zeros+1
        if zeroloc==0:
            zeroloc=1
    else:
        ones = ones+1
    newnum = (num-bit)/2
    return countBits(newnum,ones,zeros,zeroloc)

def isCyclops(num):
    ones,zeros,zeroloc = countBits(num,0,0,0)
    if debugPrint:
        print("Data:",num,ones,zeros,zeroloc)
    if zeros==0 or zeros>1:
        return False
    if ones%2 ==1:  # Can't have an odd number of ones
        return False
    if zeroloc == (ones/2)+1: # The one zero is in the middle
        return True
    return False

#------------------------------------------------------------------------
# Main program starts here.

line = sys.stdin.readline().rstrip('\n').rstrip(' ')
while (line):
    num = int(line)
    print(num, end='')
    if isCyclops(num):
        print (" yes")
    else:
        print (" no")
    line = sys.stdin.readline().rstrip('\n').rstrip(' ')


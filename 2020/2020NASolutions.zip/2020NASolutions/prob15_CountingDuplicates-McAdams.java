import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required to parse split from array into List
import java.util.Comparator;//used to sort
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Counting Duplicates
 * DIFFICULTY LEVEL: Intermediate
 * TIME TAKEN TO CODE SOLUTION: 16 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 18-20 minutes
 * PROBLEM AUTHOR: Lee Jenkins
 * SOLUTION AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2020-02-20
 * WHAT IT TESTS: 
 * 	1.) Keeping track of multiple data sets at the same time
 * 	2.) Dealing with comparing strings while ignoring case
 * 	3.) (Possible: dealing with preserving case for output, while ignoring case for input)
 *  4.) (Possible: sorting outuput alphabetically)
 *  5.) Dealing with double-counting (check all words in first list, check all words in second list, don't double count)
 * 	6.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 * */
public class prob15 {
	private static final String DEBUG_PROB_ID = "probAN";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Longer lists of words of varying lengths (movie quotes)
	 * 3.) Much longer lists of words of various lengths (book quotes)
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Simple random word lists of various lengths
	 * 2.) Simple random word lists of various lengths
	 * 3.) Simple random word lists of various lengths
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * Ignoring case causes the solution to take much longer, especially if the student doesn't
	 * have a handy library function to use to do it quickly (such as in C).
	 * Output won't be uniform against judge solution unless the student PRESERVES the case for
	 * the output.
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt").toPath());
		try{
			int lineNum = 0;
			List<String> line1 =new ArrayList<String>();
			List<String> line2 =new ArrayList<String>();
			for(String line:lines){
				//ignore the terminator line
				if (!line.trim().equals("0 0"))
				{
					lineNum++;
					//if we have read in 3 lines, output the evaluation results, and reset all of the counters
					if (lineNum > 3){
						output(line1, line2);
						lineNum = 1;
						line1 =new ArrayList<String>();
						line2 =new ArrayList<String>();
					}
					if (lineNum ==2){//load line 1
						System.out.println(line);
						line1 =Arrays.asList(line.trim().split(" "));
						
					}
					else if (lineNum ==3){//load line 2
						System.out.println(line);
						line2 =Arrays.asList(line.trim().split(" "));
					}
				}
				else{
					output(line1, line2);
				}
			}
		} 
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	//outputs the comparison evaluation
	private static void output(List<String> line1, List<String> line2){
		List<String> duplicates =new ArrayList<String>();
		//cycle through each word in line 1, and see if line 2 contains it, if so, add it to the duplicates list if
		//(and only if) we haven't already found that word as a duplicate already (we don't need to test list 2
		//against list 1, because even though list 2 might contain words not in list 1, we are testing for the
		//existance of a word in BOTH lists, so it is irrelevant)
		for(String word:line1){
			if (line2.stream().anyMatch(word::equalsIgnoreCase) && !duplicates.stream().anyMatch(word::equalsIgnoreCase)){
				duplicates.add(word);
			}
		}
		System.out.print(duplicates.size());
		duplicates.sort(Comparator.naturalOrder());
		for(String word:duplicates){
			System.out.print(" "+word);	
		}
		System.out.println("");
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

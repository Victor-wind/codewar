#!/usr/bin/python3
# JumpSpace Problem Generator
# Author: jeffg, 2020
import argparse
import random
import sys

alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def generate(num_rows, num_cols, num_systems, num_trips, words=None):
    """Given constraints, generates a Jump Space input problem represented as a string"""
    rng = random.Random()
    if words:
        words = list(set(words))  # remove duplicates
        rng.shuffle(words)
        system_names = words[:num_systems]
    else:
        system_names = []
        while len(system_names) < num_systems:
            name = "".join(rng.choices(alpha, k=4))
            if name not in system_names:
                system_names.append(name)

    system_placements = {}
    for name in system_names:
        while True:
            row = rng.randint(1, num_rows + 1)
            col = rng.randint(1, num_cols + 1)
            loc = (col, row)
            if loc not in system_placements:
                system_placements[loc] = name
                break

    problem = [f"{num_systems} {num_trips}"]
    for loc in sorted(system_placements.keys(), key=lambda x: (x[0] * 100) + x[1]):
        problem.append("%02d%02d %s" % (loc[0], loc[1], system_placements[loc]))

    rng.shuffle(system_names)
    for i in range(num_trips):
        problem.append(f"{system_names[i]} {system_names[i+num_trips]}")

    return problem


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--rows", required=True, type=int)
    parser.add_argument("--cols", required=True, type=int)
    parser.add_argument("--systems", required=True, type=int)
    parser.add_argument("--trips", required=True, type=int)
    parser.add_argument(
        "--words", action="store_true", help="If set, derive system names from stdin"
    )
    args = parser.parse_args()

    if args.words:
        words = list(map(lambda x: x.strip().upper()[:4], sys.stdin.readlines()))
    else:
        words = None
    problem = generate(
        min(args.rows, 98), min(args.cols, 98), args.systems, args.trips, words
    )
    print("\n".join(problem))

import sys #import system tools
import re #import regular expressions
#PROBLEM: Rhymes with Ablaut
#DIFFICULTY LEVEL: Intermediate/Advanced (leans toward advanced)
#TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 2 minutes
#ESTIMATED STUDENT COMPLETION TIME NEEDED: < 5 minutes
#PROBLEM AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
#LAST MODIFIED: 2020-02-19
#WHAT IT TESTS: 
#	1.) Ability to parse text
#	2.) Ability to determine the order tests need to logically run
#	3.) Ability to compare and/or sort strings
#	4.) Ability to handle branching logic
#	5.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
# 
#PROBLEM DESCRIPTION: 
"""
Rhymes with Ablaut
(15 pts.)

This problem explores various types of reduplication in the English language. In linguistics, reduplication is the repetition of a word, either with an altered consonant or an altered vowel.

For example, have you ever noticed pairs of English words in which only an inner vowel sound changes, such as chit-chat, hip-hop, or ping-pong? The technical term for this pattern is Ablaut Reduplication. In addition to word pairs, English has examples of three or more words that follow the pattern of ablaut reduplication, such as sing, sang, song, and sung.

What could be more fun? Just this: when ablaut reduplication is used in a phrase, native English speakers usually prefer saying and hearing a specific short vowel-sound sequence. That's why we say splish-splash and tick-tock, but almost never splash-splish or tock-tick. When the vowels are reversed it just doesn't sound right. This is called progressive vowel retraction. The progressive order of the short vowels is I, A, E, O, U. When the inner vowel changes in a non-progressive order, we'll just call it ablaut reduplication.

The English language includes other types of reduplication. For example, in copy reduplication a word is wholly repeated, as in bye-bye and yada-yada-yada. And in rhyming reduplication, a change in the initial consonant sound produces words that rhyme, such as nitty-gritty and hocus-pocus. In some cases one of the initial consonants may be missing, as in itsy-bitsy. Finally, there is a "shm" reduplication, which is a specific type of rhyming reduplication in which there are exactly two words and the initial consonant sound of the second word is replaced by the letters s-h-m, as in fancy-shmancy, Joe Shmoe, and apple-shmapple.

All the above rules are simplifications of patterns that have many complications and variations. Since this is a CodeWars problem, we'll not delve too deeply into phonetics and exceptions. In particular, we'll pretend English words are always pronounced the way they are spelled. Words will be one or two syllables. Vowel substitutions only occur with single-letter vowel sounds. Write a program to determine the type of reduplication present in a sequence of words.
Input

Each line of input begins with an integer word count (two, three, or four) and that same number of words, all in upper case. (For parsing simplicity hyphenated and compound words have been presented as individual words.) The end of input is signalled with the number zero.

2 CHIT CHAT
2 APPLE SHMAPPLE
2 BOT BIT
4 LONG PONG TONG SONG
2 SHMICK SHMUCK
2 CHICK FLICK
4 SING SANG SONG SUNG
2 BUG BAG
2 BYE BYE
2 HOCUS POCUS
2 DIG DUG
3 YADA YADA YADA
2 JOE SHMOE
2 CULTURE VULTURE
2 FORGET FORGOT
0

Output

For each word sequence, the program must print the sequence and the correct type of reduplication, either COPY, RHYMING, SHM, ABLAUT, or PROGRESSIVE. Every line will fit a pattern. Keep in mind that shm is a specific subtype of rhyming reduplication and progressive is a specific subtype of ablaut reduplication.

CHIT CHAT  PROGRESSIVE
APPLE SHMAPPLE  SHM
BOT BIT  ABLAUT
LONG PONG TONG SONG  RHYMING
SHMICK SHMUCK PROGRESSIVE
CHICK FLICK  RHYMING
SING SANG SONG SUNG  PROGRESSIVE
BUG BAG  ABLAUT
BYE BYE  COPY
HOCUS POCUS  RHYMING
DIG DUG  PROGRESSIVE
YADA YADA YADA  COPY
JOE SHMOE  SHM
CULTURE VULTURE  RHYMING
FORGET FORGOT  PROGRESSIVE
"""
debugging = False
problemID = "AM"
#SOLUTION:
#----------------------------------------------------------------------------------------
#STUDENT DATA:
#----------------------------------------------------------------------------------------
#1.) Data from problem example, simple case
#2.) Mix of possible types of reduplications (not all represented) in various lengths
#3.) Mix of possible types of reduplications (all ARE represented) in various lengths
#4.) One-each of all possible reduplication types, in various lengths. Nothing tricky
#----------------------------------------------------------------------------------------
#JUDGE DATA:
#----------------------------------------------------------------------------------------
#1.) One-each of all possible reduplication types, in various lengths. Nothing tricky
#2.) Large list of multiple types of reduplications, including a lot of progressives
#3.) One-each of all possible reduplication types, in various lengths. Nothing tricky
#----------------------------------------------------------------------------------------
#NOTES:
#
# The coding for this one won't actually be too terrible, but the advanced skills will 
# come into play when trying to come up with the algorithm to satisfy all of the rules
# of this problem, and also pulling out all of the requirements from the problem as well
# (there are a lot of them, and they aren't presented in a simple bulleted list)
# 
# The actual solution to the problem is to simply setup tests for all of the word rules
# (and combinations of those rules) to figure out what rule BEST applies to a line from 
# the data file (many lines COULD be one of the types given in the problem, but only 
# BEST match ONE of the rules.) The rest of the coding difficulty will come about if the
# student doesn't know how to use lists/arrays and tries to solve the problem using only
# text manipulation techniques like substrings.
#
# Note, the solution presented here is NOT a robust way to test for all of the word rules
# shown in this problem. It ONLY works given the rules for this problem.
#
# Note 2: for students new to logic notation, iff isn't a typo in the documentation below,
# it it logical shorthand for "if and only if" ^_-
#
#The solution provided only uses libraries found in the standard Python installation,
#no external modules or 3rd party libraries are used.
#*/
#----------------------------------------------------------------------------------------

try:
    #------------------------------------------------------------------------------------
    #FUNCTION: isCopy
    #AUTHOR: Robert D. McAdams
    #LAST UPDATED: 2020-02-14
    #PURPOSE: determine if X words in a string are copies of each other
    #PRECONDITION: must have loaded at least one line of data to send to this function
    #POSTCONDITION: returns True if the line satisfies the rules for this type of 
    #               word reduplication
    #INPUT: line (string): a line of data in the format: # X X1 X2 ... Xn
    #           Where # is the number of words on the line, X is the first word,
    #           X1 is the second word, and so on up to Xn being the last word
    #OUTPUT: Boolean: True iff each word is exactly the same as every other
    #           word in the data line (ignoring cAsE and leading/trailing spaces)
    #------------------------------------------------------------------------------------
    def isCopy(line):
        parts = line.split(' ') #splitting the line into parts on the space character to
        #                       make is trivial to compare the pieces
        equal = True #assuming we will respond with True
        #setting up a test to see if we need to change our answer to False. Cycle through
        #each word in the list and compare it to every other word in the list, as soon as
        #we find one word that is not the same, change our response to false, and break
        #out of the loop
        for i in range(1,len(parts)):
            for j in range(1,len(parts)):
                equal = parts[i].upper() == parts[j].upper()
                if not equal:
                    break
            if not equal:
                break
        return equal #return our response based on our tests
    #------------------------------------------------------------------------------------
    #FUNCTION: isRhyme
    #AUTHOR: Robert D. McAdams
    #LAST UPDATED: 2020-02-14
    #PURPOSE: determine if X words in a string rhyme with each other (using the rule that
    #           they must use the same vowels in the same order)
    #PRECONDITION: must have loaded at least one line of data to send to this function,
    #               the isCopy() function must exist
    #POSTCONDITION: returns True if the line satisfies the rules for this type of 
    #               word reduplication
    #INPUT: line (string): a line of data in the format: # X X1 X2 ... Xn
    #           Where # is the number of words on the line, X is the first word,
    #           X1 is the second word, and so on up to Xn being the last word
    #OUTPUT: Boolean: True iff each word has exactly the same vowels, in the 
    #           same order as every other word in the data line (ignoring cAsE and 
    #           leading/trailing spaces), else False
    #------------------------------------------------------------------------------------
    def isRhyme(line):
        #remove all non-vowels from the line using regular expressions (if the student
        # doesn't know how to use regular expressions, another simple way to do this
        # is to use the string 'remove()' function (or whatever it is called in the 
        # student's programming language) to search for each non-vowel letter, & replace
        # that letter with the empty string).
        line = re.sub('[BCDFGHJKLMNPQRSTVWXYZ]', '', line.upper())
        #once we have all of the non-vowels removed, we can use the isCopy() function to
        #check to see if the words "rhyme" as the vowels must be the same (and in the 
        # same order) to rhyme
        return(isCopy(line))
        #print(line) #debugging
        #exit() #exit the program early (used for debugging) (I left this in to show 
        # students how to exit a program early in Python, if they didn't know ^_-)
    #------------------------------------------------------------------------------------
    #FUNCTION: isShm
    #AUTHOR: Robert D. McAdams
    #LAST UPDATED: 2020-02-14
    #PURPOSE: determine if the second word in a string is the same as the first word, but
    #           modified as a "shm" (apple to schmapple for instance.)
    #PRECONDITION: must have loaded at least one line of data to send to this function,
    #               the isRhyme() function must exist
    #POSTCONDITION: returns True if the line satisfies the rules for this type of 
    #               word reduplication
    #INPUT: line (string): a line of data in the format: # X X1 X2 ... Xn
    #           Where # is the number of words on the line, X is the first word,
    #           X1 is the second word, and so on up to Xn being the last word
    #OUTPUT: Boolean: True iff both words rhyme (uses the isRhyme function for
    #               that) and the second word starts with "SHM"
    #------------------------------------------------------------------------------------
    def isShm(line):
        parts = line.split(' ') #splitting the line into parts on the space character to
        #                       make is trivial to compare the pieces
        #look at the first 3 letters of the second word, test to make sure they equal 'SHM'
        hasSHM = (parts[len(parts)-1][0:3].upper() == 'SHM')
        #test if the 2 words rhyme (have the same vowels), and the second word starts 
        # with 'SHM' -- if so, return True (that's what the logical 'and' means)
        return (hasSHM and isRhyme(line))
    #------------------------------------------------------------------------------------
    #FUNCTION: ablautProgressiveTest
    #AUTHOR: Robert D. McAdams
    #LAST UPDATED: 2020-02-14
    #PURPOSE: determine if the words in a given data line follow the ablaut or 
    #           progressive vowel progression.
    #PRECONDITION: must have loaded at least one line of data to send to this function
    #POSTCONDITION: returns True if the line satisfies the rules for this type of 
    #               word reduplication
    #INPUT: line (string): a line of data in the format: # X X1 X2 ... Xn
    #           Where # is the number of words on the line, X is the first word,
    #           X1 is the second word, and so on up to Xn being the last word
    #OUTPUT: Int: 1 iff all of the words in a given line have a vowel progression that
    #           is 'lower' than the next word in the line in the 'progressive vowel' 
    #           scale of: I, A, E, O, U.
    #           -1 iff all of the words in a given line have a vowel progressin that
    #           is 'higher' than the next word in the line in the 'progressive vowel'
    #           scale of: I, A, E, O, U.
    #           E.G. if word1 uses an 'A' and word2 uses an 'O', it is NOT 'ablaut' (it's
    #           progressive ^_-), but if word2 used a 'I', that is "lower" than 'A' in 
    #           the scale, reading left to right with left being the "lowest" and right
    #           being the "highest". So, if from word1 to word 2 the vowels move left to
    #           right, they are "progressive", if they move right to left, they are "ablaut"
    #------------------------------------------------------------------------------------
    def ablautProgressiveTest(line):
        #remove the non-vowels from the data line
        test = re.sub('[BCDFGHJKLMNPQRSTVWXYZ]', '', line.upper())
        #splitting the line into parts on the space character to make is trivial to 
        # compare the pieces
        parts = test.split(' ')
        #remove the number of words from the beginning of the line
        words = []
        count = 0
        for part in parts:
            count += 1
            if (count > 1):
                words.append(part)
        #define the order for "progressive" vowels in a list, we will use the index
        #of each item's position in the list to test for ablaut/progressive
        progressiveVowelOrder = ['I','A','E','O','U']
        #setups variable to hold the vowels from each word
        vowels = []
        #setup a variable to determine if we need to find the changing vowel
        #(as in the example FORGET FORGOT, there are 2 vowels in those words
        # (OE and OO) but, as per the problem rules, only one of the vowels
        # is changing. In such as case we need to focus only on the changing
        # vowel in each word in the data line)
        needToFindChanged = False
        for v in words:
            if (len(v) > 1):
                needToFindChanged = True
                break
            else:
                vowels.append(v)
        #we have multiple vowels in the words, cycle through and find the
        #vowels which are changing, and isolate them into the vowels list
        if needToFindChanged:
            changedIndex = -1
            for c in range(0,len(words[0])):
                letter1 = words[0][c:c+1]
                letter2 = words[1][c:c+1]
                if (letter1 != letter2):
                    changedIndex = c
                    break
            vowels = []
            for word in words:
                vowels.append(word[changedIndex:changedIndex+1])
        # now we are going to find the index of each vowel in the vowel list by looking at
        # each vowel's index in the progressiveVowelOrder list, and recording it to the
        # vowelOrder list
        vowelOrder = []
        for vowel in vowels:
            index = -1
            for order in progressiveVowelOrder:
                index += 1
                if vowel == order:
                    vowelOrder.append(index)
                    break
        # now that we have the 'progressive vowel index' of each vowel in our list we 
        # will test each vowel in our list to see if each vowel is greater than or less
        # than it's next (right) neighbor using a logical-AND test to change to false
        # if we find an index out of order from the expected test: reading left to right
        # if the index of the left is always greater than the index to the right, then
        # the list is ablaut. Else, if the index on the left is always less than the
        # index to the right, then it is progressive. According to the rules of the
        # problem: 'every line will fit a pattern.' So, we could assume if the line
        # wasn't ablaut it must be progressive (and vice versa, so long as we test
        # for ablaut/progressive last) but that isn't good coding practice. So this 
        # example solution returns -1 for ablaut, 1 for progressive, and 0 for unknown
        # if the vowels don't follow eithe pattern ^_-
        ablautOrder = True
        progressiveOrder = True
        #test for ablaut
        for index in range(0,(len(vowelOrder)-1)):
            ablautOrder = (ablautOrder and (int(vowelOrder[index]) > int(vowelOrder[index+1])))
        #test for progressive
        for index in range(0,(len(vowelOrder)-1)):
            progressiveOrder = (progressiveOrder and (int(vowelOrder[index]) < int(vowelOrder[index+1])))
        if (ablautOrder):
            return -1
        elif (progressiveOrder):
            return 1
        else:
            return 0
        return result

    #------------------------------------------------------------------------------------
    #FUNCTION: analyze
    #AUTHOR: Robert D. McAdams
    #LAST UPDATED: 2020-02-14
    #PURPOSE: runs through each line in the data list and tests what type of data line 
    #           it is for word reduplication
    #PRECONDITION: must have loaded at least one line of data into a list and sent it
    #               to this function
    #POSTCONDITION: none
    #INPUT: List<string>: a list of strings containing data lines in the format of:
    #           # X X1 X2 ... Xn
    #           Where # is the number of words on the line, X is the first word,
    #           X1 is the second word, and so on up to Xn being the last word
    #OUTPUT: prints the line (minus the number at the start of the line) and then:
    #           COPY or SHM or RHYMING or ABLAUT or PROGRESSIVE or UNKNOWN depending on
    #           what rules the line satisfies when tested. Only prints UNKNOWN if the
    #           line satisfies no rules (not technically required by the problem desc.
    #           but a good thing to do regardless)
    #------------------------------------------------------------------------------------
    def analyze(lines):
        for line in lines:
            print(line[(line.index(" ")+1):len(line)],end=' ')
            if (isCopy(line)):
                print("COPY")
            elif (isShm(line)):
                print("SHM")
            elif (isRhyme(line)):
                print("RHYMING")
            else:
                vowelOrder = int(ablautProgressiveTest(line))
                if (vowelOrder == -1):
                    print("ABLAUT")
                elif (vowelOrder == 1):
                    print("PROGRESSIVE")
                else:
                    print("UNKNOWN")
    #------------------------------------------------------------------------------------
    # FUNCTION: main
    # AUTHOR: Robert McAdams
    # LAST UPDATED: 2020-02-14
    # PURPOSE: main program, gets the data and runs the operations
    # PRECONDITION: none
    # POSTCONDITION: program has executed
    # INPUT: none (opens a file to get data, or reads from command line, depending on mode)
    # OUTPUT: sends List<string> list of strings to the main program
    #------------------------------------------------------------------------------------
    def main():
    	#--------------------------------------------------------------------------------
		#LOAD THE DATA
        lines = []
        if (debugging):
            #r"" instructs the linter to treat the string as a literal, and not to parse it
            f = open(r"data\prob"+problemID+"-judge-3-in.txt", "r")
            for line in f:
                if (len(line) > 2):
                    lines.append(line.rstrip().strip())
        else:
            for line in sys.stdin:
                if (len(line) > 2):
                    lines.append(line.rstrip().strip())
		#--------------------------------------------------------------------------------
        analyze(lines)
	#------------------------------------------------------------------------------------
    main()
except SystemExit: #handles calling exit() in the code to exit the program early
    pass
except: #handles general exceptions/errors
    e = sys.exc_info()[0]
    print("bad things happened: "+str(e))

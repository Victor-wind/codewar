#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define DIM 12
#define BUF 64
#define H 0
#define V 1
#define WORDS 100

int debug=0;

char grid[DIM][DIM];
char words[WORDS][BUF];
int section=0;

void dump(){
int i,j;
for(i=0;i<DIM;i++) {for(j=0;j<DIM;j++) putchar(grid[i][j]); printf("\n");}}
char buf[BUF];

int main(argc,argv) int argc; char **argv; {
int i,j,k;
int n[WORDS],o[WORDS],l[WORDS],x[WORDS],y[WORDS];
char c;
int space=0;
int word=0;
int f;

if(argc>1) debug=1;
for(i=0;i<DIM;i++) for(j=0;j<DIM;j++) grid[i][j]=' ';

while(fgets(buf,BUF-1,stdin)) {
 if(strncmp("------",buf,6)==0) {
  section++;
  continue;
 };

 if(section==0) {
  sscanf(buf,"%d %c %d %d %d\n", &n[space], &c, &l[space], &x[space], &y[space]);
  o[space]=(c=='V');
 for(j=0;j<l[space];j++) {
  grid[x[space]+(!o[space])*j][y[space]+(o[space])*j]='*';
 }

 space++;


 };

 if(section==1) {
  sscanf(buf,"%d %d %c\n",&i, &j, &c);
  grid[i][j]=c;
 }

 if(section==2)
  sscanf(buf,"%s\n", words[word++]);

}

if(debug)dump();
for(i=0;i<space;i++) {
if(debug) {
 printf("space %d: \"",i);

 for(j=0;j<l[i];j++) {
  c=grid[x[i]+(!o[i])*j][y[i]+(o[i])*j];
  putchar(c);
 }

 printf("\"\n");
}
 for(k=0;k<word;k++) {
  if(strlen(words[k])!=l[i]) continue;
  for(f=1,j=0;f&&(j<l[i]);j++) {
   c=grid[x[i]+(!o[i])*j][y[i]+(o[i])*j];
   f=f && (c=='*')||(c==words[k][j]);
  }
  if(f)
   printf("%02d is %s\n",i+1,words[k]);
 }
}
}

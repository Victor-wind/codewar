import java.io.FileNotFoundException;//required for I/O from file
import java.text.DecimalFormat;//required for rounding
import java.util.Scanner;//required for I/O from stdin
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Math Checker
 * DIFFICULTY LEVEL: Easy
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 10 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 12-14 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-27
 * WHAT IT TESTS: 
 * 	1.) Ability to carry out basic mathematic operations (addition, subtraction, multiplication, division, and exponential)
 * 	2.) Ability to handle integer division and output a decimal answer (this isn't explicitly called out as a warning to the students, and novice students (depending on the language they use) may too quickly think they are "done" when setting up division in their program, when in reality they need to cast to a type that can get a decimal answer first.)
 * 	3.) Ability to handle both "good" and "bad" data gracefully
 * 	4.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# Math Checker
## (6 pts.)

Your old sixth grade teacher needs help grading math homework! He's made a few mistakes grading papers lately, and wants to make sure his math is correct. Write a simple program that will take an equation setup, and an answer and determine if the answer is correct or not.

### Input

Your program needs to handle positive and negative numbers, and care should be taken to translate integer math to decimal output.
Your program needs to be able to read in a up to five lines of data in the format of:

    A# B# operation answer#

    Examples:

    100 7 DIVIDE 5.0
    7 7 MULTIPLY 49.0
    -6 3 POWER 216.0
    3 7 SUBTRACT 6.0
    3 7 ADD 12.0

Your program needs to be able to handle the following operations:

    POWER
    MULTIPLY
    DIVIDE
    ADD
    SUBTRACT

Operations should be carried out left to right A# to B# as follows:

    A# ^ B# (A raised to the power of B)
    A# * B# (A multiplied by B)
    A# / B# (A divided by B; note the teacher does not give divide by zero problems)
    A# + B# (A added to B)
    A# - B# (B subtracted from A)

    Note: either the value for A or B can be negative, except for power (A^B) equations, where B will always be non-negative.

### Output

Output all numbers rounded to 1 decimal place.
If the student's answer is correct, output:

    answer# is correct for A# operation B#

If the student's answer is incorrect, output:

    A# operation B# = correct answer, not answer#

    Examples:

    100.0 / 7.0 = 14.3, not 5.0
    49.0 is correct for 7.0 * 7.0
    -6.0 ^ 3.0 = -216.0, not 216.0
    3.0 - 7.0 = -4.0, not 6.0
    3.0 + 7.0 = 10.0, not 12.0

 * 	
 * */
public class prob16 {
	private static final String DEBUG_PROB_ID = "probAS";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	private static DecimalFormat df = new DecimalFormat("0.0");//global constant for rounding decimals
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Tests: division, exponents, subtraction, and addition
	 * 3.) Tests: division, multiplication, exponents, subtraction, and addition
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Tests: division, multiplication, exponents, subtraction, and addition
	 * 2.) Tests: division (twice), multiplication and exponents
	 * 3.) Tests: exponents (twice), subtraction, and addition
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * This problem shouldn't be too difficult for most students to solve. It simply requires the
	 * student to implement 5 basic math operations (and it is even structured so they will be
	 * able to solve it if they don't know about, or have access to a language provided power/exponent
	 * function), and to then check their answer against the dataset's answer, and output in
	 * one of two ways depending on if the answers match or not. Only other sticking point will be
	 * negative numbers.
	 * 
	 * This is another problem I chose to solve in a manner as similar as possible to the toolset
	 * a beginning student might use. Only the Scanner class, simple variable primitive parsing, 
	 * and simple loops and calculations are used. No additional classes are used but I did split up 
	 * the various "stages" of the data handling into sub-methods to make the main "cleaner", 
	 * and follow best practices.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run(false);
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run(boolean debugging) throws FileNotFoundException{
		//PARSE THE DATA IN
		//production
		//List<String> lines = readFromFileInputByCommandLine();
		//debugging
		Scanner lines=null;
		if (debugging){
			File file=new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt");
			lines=new Scanner(file);
		}
		else{
			//will NOT work on the command line (unless the student knows to terminate the input with CTRL+C)
			//expecting to pipe in a file path
			lines=new Scanner(System.in);
		}
		while(lines.hasNextLine()){
			String scanLine = lines.nextLine();
			Scanner line = new Scanner(scanLine).useDelimiter(" ");
			/* For beginning students:
			 * If you see a compiler warning saying: 'unassigned closeable value is never closed'
			 * on the above line, you can safely ignore it. That is just the compiler not correctly
			 * detecting piping instantiaion of the new Scanner class object to calling the 
			 * useDelimiter method. If you split the line up to 2 lines as:
			 * Scanner line = new Scanner(scanLine);
			 * line.useDelimiter(" ");
			 * you'll see the "warning" go away ;)
			 */
			ParseLine(line);
		}
		lines.close();
	}
	/**
	 * Takes a line from the dataset, and parses each space delimited part
	 * of the line into temporary variables so the calculations represented
	 * in the line can be run, and answers compared. Outputs the results
	 * as per the logic of the problem.
	 * */
	private static void ParseLine(Scanner line){
		int counter = 0;
		double A = 0.0;
		double B = 1.0;
		String op = "";
		double ANS = 0.0;
		while (line.hasNext()){
			if (counter==0){
				A = Double.parseDouble(line.next());
			}
			else if (counter==1){
				B = Double.parseDouble(line.next());
			}
			else if (counter==2){
				op = line.next();
			}
			else if (counter==3){
				ANS = Double.parseDouble(line.next());
			}
			counter++;
		}
		line.close();
		double CHECK = 0.0;
		String opSign = "";
		if (op.trim().equalsIgnoreCase("POWER")){
			//implementing powers this way specifically assuming a beginner student 
			//who doesn't know about the built-in Math library (note, this only works for exponents >= 0)
			//CHECK = Math.pow(A, B);
			int power = 1;
			CHECK = A;
			while (power < B){
				CHECK *= A;
				power++;
			}
			if (B == 0){
				CHECK = 1;//handle special case of exponential math
			}
			opSign = " ^ ";
		}
		else if (op.trim().equalsIgnoreCase("MULTIPLY")){
			CHECK = A*B;
			opSign = " * ";
		}
		else if (op.trim().equalsIgnoreCase("DIVIDE")){
			CHECK = A/B;
			opSign = " / ";
		}
		else if (op.trim().equalsIgnoreCase("ADD")){
			CHECK = A+B;
			opSign = " + ";
		}
		else if (op.trim().equalsIgnoreCase("SUBTRACT")){
			CHECK = A-B;
			opSign = " - ";
		}
		//casting our given answer and our calculated answer to same decimal length for comparison (only other way to do this is to use the java.text.DecimalFormat library, round to the desired decimal as a string, then cast that back to a number)
		//The problem (in Java, isn't so much a problem in other languages) is the rather strict/broken way Java implements integer division.
		//What I am forcing the compiler to do below is to convert all of the numbers involved to doubles, then do the division and rounding
		//on the output.
		CHECK = (double)Math.round((CHECK) * 10.0) / 10.0;
		ANS = (double)Math.round((ANS) * 10.0) / 10.0;
		if (CHECK==ANS){
			System.out.println(ANS+" is correct for "+A+opSign+B);
		}
		else{
			System.out.println(A+opSign+B+" = "+CHECK+", not "+ANS);
		}
	}
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUF 1024
#define PEPPERONI 0
#define REDPEPPERS 1
#define PINEAPPLE 2
#define OLIVES 3
#define SARDINES 4
#define ONION 5
#define SAUSAGE 6
#define HAM 7

#define ING 8
#define COMBOS 5
char *ingName[ING] = { "Pepperoni", "Red Peppers", "Pineapple", "Olives", "Sardines", "Onion", "Sausage", "Ham" };

int ingAmt[ING] = { 32, 16, 84, 20, 12, 28, 40, 36 };

#define HAWAIIAN 0
#define COMBO 1
#define FISHASTER 2
#define MEATLOVER 3
#define CHEESE 4

char *comboName[COMBOS] = { "Hawaiian", "Combo", "Fishaster", "Meat-Lovers", "Cheese"};

int comboAmt[COMBOS][ING];
int totals[ING];

void setup() {
int c,i;


for(i=0;i<ING;i++) totals[i]=0;

for(c=0;c<COMBOS;c++) for(i=0;i<ING;i++) comboAmt[c][i]=0;

comboAmt[HAWAIIAN][PINEAPPLE]=ingAmt[PINEAPPLE];
comboAmt[HAWAIIAN][HAM]=ingAmt[HAM];

comboAmt[COMBO][REDPEPPERS]=ingAmt[REDPEPPERS];
comboAmt[COMBO][OLIVES]=ingAmt[OLIVES];
comboAmt[COMBO][ONION]=ingAmt[ONION];
comboAmt[COMBO][SAUSAGE]=ingAmt[SAUSAGE];

comboAmt[FISHASTER][SARDINES]=ingAmt[SARDINES];
comboAmt[FISHASTER][ONION]=ingAmt[ONION];

comboAmt[MEATLOVER][PEPPERONI]=ingAmt[PEPPERONI];
comboAmt[MEATLOVER][SAUSAGE]=ingAmt[SAUSAGE];
comboAmt[MEATLOVER][HAM]=ingAmt[HAM];
}


int main(argc,argv) int argc; char **argv; {
int pizzas;
char buf[BUF];
char cmd[BUF];
char *s;
int done,i,j,k;
int d;
int steps;
int r;
char c;

setup();
while(scanf("%d ",&pizzas)!=EOF) {
 fgets(buf,BUF-1,stdin);
// printf("%d pizzas : %s\n",pizzas,buf);
 for(steps=1,i=0;buf[i];i++)
  if(buf[i]=='&') steps++;
 s=buf; 
 for(i=0;i<steps;i++) {
  d=1;
  sscanf(s,"%s%n",cmd,&r); s+=r;
  if(strcmp("1/2",cmd)==0) { d=2; sscanf(s,"%s%n",cmd,&r);s+=r; }
  if(strcmp("1/4",cmd)==0) { d=4; sscanf(s,"%s%n",cmd,&r);s+=r; }
  if(strcmp("Red",cmd)==0) { sscanf(s,"%s%n",cmd,&r);s+=r; strcpy(cmd,ingName[REDPEPPERS]);}

// printf("CMD=%s\n",cmd);

  for(j=0;j<COMBOS;j++)
   if(strcmp(cmd,comboName[j])==0) {
//    printf("Adding 1/%d of a %s X %d pizzas\n",d,cmd,pizzas);
    for(k=0;k<ING;k++)
     totals[k]+=pizzas*comboAmt[j][k]/d;
     }

  for(j=0;j<ING;j++)
   if(strcmp(cmd,ingName[j])==0) {
//    printf("Adding 1/%d of a %s X %d pizzas\n",d,cmd,pizzas);
    totals[j]+=pizzas*ingAmt[j]/d;
    }

  sscanf(s,"%s%n",cmd,&r); s+=r;
}
}

for(i=0;i<ING;i++)
 printf("%s: %d\n",ingName[i],totals[i]);
}

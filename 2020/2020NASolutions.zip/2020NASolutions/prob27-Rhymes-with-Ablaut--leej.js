// Rhymes with Ablaut
// Code Wars program written in JavaScript for the RingoJS environment
//
// The MIT License (MIT)
//
// Copyright (c) 2020 Lee Jenkins
//

var stdin = require('system').stdin;
var stdout = require('system').stdout;

function readInputLine() {
    let wordList = stdin.readLine().trim().split(/\s/);
    wordList.shift();
    return wordList;
}

function isCopy( wordList ) {
    return wordList.every( function(w) {
        return wordList[0] === w;
    });
}

function isRhyme( wordList ) {
    let patterns = [ ];
    wordList.forEach( function(w) {
        w = w.replace(/^[BCDFGHJKLMNPQRSTVWXYZ]+/,"")
        patterns.push("{K}"+w);
    });
    return isCopy(patterns);
}

function isShm( wordList ) {
    return ( wordList.length === 2 &&
             wordList[1].substr(0,3) == "SHM" &&
             isRhyme( wordList ) );
}

function isAblaut( wordList ) {
    let firstVowel = [ ];
    let lastVowel = [ ];
    wordList.forEach( function(w) {
        firstVowel.push(w.replace(/[AEIOU]/, "{V}"));
        lastVowel.push(w.replace(/[AEIOU]([^AEIOU]*)$/, "{V}$1"));
    });
    return isCopy(firstVowel) || isCopy(lastVowel);
}

function arraysEqual(a, b) {
    if (a === b) return true;
    if (a == null || b == null) return false;
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; ++i) {
        if (a[i] !== b[i]) return false;
    }
    return true;
}

function isProgressive( wordList ) {
    let transforms = [ ];
    // replace/exchange vowels in such a way that:
    //    1. each transformed word has a one-to-one
    //       correspondence to the original word
    //    2. sorting the transformed words will put
    //       them into the progressive sequence of
    //       the original words.
    // basically, if the transformed list matches
    // the sorted transform list, then the original
    // word list is progressive ablaut reduplication.
    wordList.forEach( function(w) {
        w = w.replace(/I/g, "#");
        w = w.replace(/E/g, "I");
        w = w.replace(/A/g, "E");
        w = w.replace(/#/g, "A");
        transforms.push(w);
    });
    let sorted = transforms.slice(0).sort();
    return arraysEqual(transforms,sorted) && isAblaut(wordList);
}

function printResult( wordList, result ) {
    console.log( wordList.toString().replace(/,/g,' ') + "  " + result );
}

function analyze( wordList ) {
    let checkers = [
        { name: "COPY",          f: isCopy },
        { name: "SHM",           f: isShm },
        { name: "RHYMING",       f: isRhyme },
        { name: "PROGRESSIVE",   f: isProgressive },
        { name: "ABLAUT",        f: isAblaut },
    ];
    function runChecker(checker) {
        return !( checker.f(wordList) && printResult( wordList, checker.name ) );
    }
    if( checkers.every( runChecker ) ) {
        printResult( wordList, "UNKNOWN" );
    }
}

function main() {
    let wordList = readInputLine();
    while( wordList.length ) {
        analyze( wordList );
        wordList = readInputLine();
    }
}

main();

/* Equal Sum Numbers
   Solution Author: jeffg, 2020

   For speed, this approach uses two techniques:
   - first, filter the search space to numbers in range that are divisible by eleven
   - second, calculate the net result of adding, then subtracting, each digit

   For example, given the problem start=120, end=123:
   - step one filters to just one number to test, 121
   - step two calculates +1 -2 + 1 = 0
   - the sum (net result) is 0, so the sums of alternating digit positions are equal

   For a number that satisfies the first critiera but fails the second, check 308
*/
package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

const (
	msgEmptyResult = "No Numbers found with Equal Sum in the given range!!"
)

type Result struct {
	numbers []int
}

// main
func main() {
	start, end := readRange()
	result := Search(start, end)
	fmt.Println(result)
}

// Search range (start, end] for integers satisfying problem criteria
func Search(start, end int) *Result {
	result := &Result{}
	for _, num := range getDivisibleEleven(start, end) {
		if EvenOddDigitSumsEqual(num) {
			result.Add(num)
		}
	}
	return result
}

// EvenOddDigitSumsEqual returns true if sums of even and odd digits of i are equal
// note, this reports "0" as satisfying criteria, because the sum of 0 + nothing == nothing
func EvenOddDigitSumsEqual(num int) bool {
	sum := 0
	sign := 1
	for n := num; n > 0; n = n / 10 {
		sum += (n % 10) * sign
		sign = -sign
	}
	return sum == 0
}

// getDivisibleEleven returns integers between (start, end] evenly divisible by 11,
// as numbers satisfying the problem criteria are a subset of these numbers
func getDivisibleEleven(start, end int) []int {
	nums := []int{}
	for i := start; i < end; i++ {
		if i%11 == 0 {
			nums = append(nums, i)
			break
		}
	}
	if len(nums) == 0 {
		return nums
	}
	for i := nums[0] + 11; i < end; i += 11 {
		nums = append(nums, i)
	}
	return nums
}

// readRange reads exactly 2 integers from stdin, one number per line
func readRange() (int, int) {
	scanner := bufio.NewScanner(os.Stdin)
	var result [2]int
	for i := 0; i < 2; i++ {
		scanner.Scan()
		result[i], _ = strconv.Atoi(scanner.Text())
	}
	return result[0], result[1]
}

// Add number to results, syntactic sugar
func (r *Result) Add(i int) {
	r.numbers = append(r.numbers, i)
}

// String converts Result to human-readable string
func (r *Result) String() string {
	if len(r.numbers) == 0 {
		return msgEmptyResult
	}
	return strings.Trim(fmt.Sprint(r.numbers), "[]")
}

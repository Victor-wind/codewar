import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required for Array parsing of List generics
import java.util.List;//required for List generics
import java.util.LinkedHashMap;//required for LinkedHashMap (order guaranteed on iteration)
import java.util.Map;//required to iterate over LinkedHashMap
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Guitar Scale Hero
 * DIFFICULTY LEVEL: Intermediate
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 15 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 18-20 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-27
 * WHAT IT TESTS: 
 * 	1.) Ability to loop data upon itself in order to "circle back" as needed with a never-ending series
 * 	2.) Ability to find the "next" item in a series when the series can loop
 * 	3.) Ability to convert units in a series
 * 	4.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# Guitar Scale Hero
## (8 pts.)

Quick, your lead guitarist for your band has forgotten her scales. Write a program that will either output the NEXT note given a fret and a string, or (if given a Note name) will output all fret+string combination that will produce that note. Luckily for you, your punk band's setlist for your next gig only uses the E and A strings.

### Input

You will receive either a fret number and a string name (separated by a space) or you will receive a Note name. If you receive a fret and a string, output the NEXT note in the scale (working from fret zero (open) towards fret 12; if the next fret would go past 12, return to the "open string" /zero fret).
If you receive a Note name, output the fret and string (on both strings, list the E string first) the note can be played.
Note 1: 0 is used to represent the "open string", e.g. the top of the fret board.
Note 2: for those of you with musical backgrounds, we're ignoring the sharps and flats, skip over them like they aren't there.
Note 3: If the "next" note called for is past fret 12, you will need to "return" to the zero/"Open" fret, but the note will stay the same. E.G. A on fret twelve will also be A on fret zero.

    0 E
    2 A
    8 E
    12 A
    D
    C

### Output

    F
    C
    D
    A
    10 E 5 A
    8 E 3 A


 * 	
 * */
public class prob22 {
	private static final String DEBUG_PROB_ID = "probAP";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Standard inputs, nothing tricky
	 * 3.) Standard inputs, nothing tricky
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1-3.) Standard inputs, nothing tricky
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * The problem can ALMOST be treated as a hard-coded blackbox input X get Y type of thing,
	 * but the problem is that it has to loop depending on where in the sequence the input calls
	 * for. Additionally it requires the students to look at the musical scale on multiple levels
	 * by calling for either notes or frets and strings, which requires a better plan than "hard
	 * code EVERYTHING!" :D
	 * 
	 * I chose to solve it using a single hashmap which provides for an easy lookup for notes
	 * when given a fret and a string. I could have done a separate hashmap that reversed it
	 * to provide an easy lookup going the other way, but instead I chose to implement the
	 * reverse lookup with a loop. Linked lists and arrays could also be used to solve this
	 * they would just require a bit more setup and coding to use.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt").toPath());
		LinkedHashMap<String,String> notes=new LinkedHashMap<String,String>();
		notes.put("0 E","E");
		notes.put("1 E","F");
		//notes.put("2 E","F#/Gb");//ignored
		notes.put("3 E","G");
		//notes.put("4 E","G#/Ab");//ignored
		notes.put("5 E","A");
		//notes.put("6 E","A#/Bb");//ignored
		notes.put("7 E","B");
		notes.put("8 E","C");
		//notes.put("9 E","C#/Db");//ignored
		notes.put("10 E","D");
		//notes.put("11 E","D#/Eb");//ignored
		notes.put("12 E","E");
		notes.put("0 A","A");
		//notes.put("1 A","A#/Bb");//ignored
		notes.put("2 A","B");
		notes.put("3 A","C");
		//notes.put("4 A","C#/Db");//ignored
		notes.put("5 A","D");
		//notes.put("6 A","D#/Eb");//ignored
		notes.put("7 A","E");
		notes.put("8 A","F");
		//notes.put("9 A","F#/Gb");//ignored
		notes.put("10 A","G");
		//notes.put("11 A","G#/Ab");//ignored
		notes.put("12 A","A");
		for(String line:lines){
			List<String> parts = Arrays.asList(line.trim().split(" "));
			if (parts.size() > 1){
				//need to output next note
				if (line.trim().equalsIgnoreCase("12 E")){
					System.out.println("E");//circle back around
				}
				else if (line.trim().equalsIgnoreCase("12 A")){
					System.out.println("A");//circle back around
				}
				else{
					//System.out.println(notes.get(line.trim()));
					boolean outputNext = false;
					for(Map.Entry<String,String> note : notes.entrySet()) {
						if (outputNext == true){
							System.out.println(note.getValue());
							break;
						}
						else if (note.getKey().equalsIgnoreCase(line.trim())){
							outputNext = true;
						}
					}
				}
			}
			else{
				//need to output where note can be played.
				for(Map.Entry<String,String> note : notes.entrySet()) {
					if (note.getValue().equalsIgnoreCase(line.trim())){
						System.out.print(note.getKey()+" ");
					}
				}
				System.out.println();
			}
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

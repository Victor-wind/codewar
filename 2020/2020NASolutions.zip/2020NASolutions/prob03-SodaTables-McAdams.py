import sys
import math
#PROBLEM: Soda Tables
#DIFFICULTY LEVEL: Easy
#TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 2 minutes
#ESTIMATED STUDENT COMPLETION TIME NEEDED: < 5 minutes
#PROBLEM AUTHOR: Anil Mishra & Nittin Aggarwal
#SOLUTION AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
#LAST MODIFIED: 2020-01-22
#WHAT IT TESTS: 
#	1.) Understanding what a greatest common factor is
#	2.) Understanding how to factor a number
#	3.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
# 
#PROBLEM DESCRIPTION: 
# 
# # Soda Tables
# ## (2 pts.)
# Taylor has X cans of regular soda and Y cans of diet soda. He wants to create some identical refreshment tables for a party at his school. He also doesn't want to have any sodas left over. Write a program to find the greatest number of refreshment tables that Taylor can stock.
# You will receive 2 lines of input, the first will be "X" and the second will be "Y". Double zeros (00) indicates the end of the file. Use "X" and "Y" to find the greatest number of tables which can be arranged with identical amounts of cans of soda.
# ### Input
#   6
# 	15
# 	00
# ### Output
#     3
# ### Discussion
# 	The goal is to set out the largest number of tables with identical sets of refreshments, using all of the available cans of soda. To do that, look for the largest number which divides evenly into both X and Y. In this case, X=6 can be divided by 1, 2 and 3 evenly. And Y=15 can be divided by 1, 3, and 5 evenly. So 3 is the largest divisor they both share.
#
debugging = False
problemID = "BH"
#SOLUTION:
#-----------------------------------------------------------------------------------------
#STUDENT DATA:
#-----------------------------------------------------------------------------------------
#1.) Data from problem example, simple case
#2.) Standard set of numbers, nothing tricky
#3.) Standard set of numbers, nothing tricky
#-----------------------------------------------------------------------------------------
#JUDGE DATA:
#-----------------------------------------------------------------------------------------
#1.) Standard set of numbers, nothing tricky
#2.) Standard set of numbers, nothing tricky
#3.) Standard set of numbers, nothing tricky
#-----------------------------------------------------------------------------------------
#NOTES:
#
# This is intended as a problem of beginner difficulty. The only tricky aspect will be 
# finding the factors of a number, comparing them shouldn't take very long (provided the
# student knows how to work with lists/arrays). The problem IS a math problem, but it
# gives all of the needed information to solve it, because we are testing code knowledge
# not math knowledge :)
#
#The solution provided only uses libraries found in the standard Python installation,
#no external modules or 3rd party libraries are used.
#*/
#----------------------------------------------------------------------------------------
try:
    #------------------------------------------------------------------------------------
    # FUNCTION: getFactors
    # PURPOSE: returns all factors of a given integer from 1 to itself
    # INPUT PARAMETER: n (int): the number to find the factors of
    # PRECONDITIONS: none
    # POSTCONDITIONS: returns a list of factors for the number
    # AUTHOR: Robert McAdams, mcadams@hpe.com
    # LAST MODIFIED: 2020-01-22
    def getFactors(n):
        factors = []
        for x in range(1,n):
            if (n % x == 0):
                factors.append(x)
        return factors
    #------------------------------------------------------------------------------------
    # FUNCTION: main
    # PURPOSE: main program, gets the data and runs the operations
    # PRECONDITIONS: none
    # POSTCONDITIONS: program has executed
    # AUTHOR: Robert McAdams, mcadams@hpe.com
    # LAST MODIFIED: 2020-01-22
    def main():
    	#--------------------------------------------------------------------------------
		#LOAD THE DATA
        lines = []
        if (debugging):
            #r"" instructs the linter to treat the string as a literal, and not to parse it
            f = open(r"data\prob"+problemID+"-student-3-in.txt", "r")
            for line in f:
                lines.append(line.rstrip().strip())
        else:
            for line in sys.stdin:
                lines.append(line.rstrip().strip())
		#--------------------------------------------------------------------------------
        if (len(lines) >= 2):
            XFactors = getFactors(int(lines[0].strip()))
            YFactors = getFactors(int(lines[1].strip()))
            greatestCommonFactor = 0
            for x in XFactors:
                if (x in YFactors and x > greatestCommonFactor):
                    greatestCommonFactor = x
        print(greatestCommonFactor)
	#------------------------------------------------------------------------------------
    main()
except:
	e = sys.exc_info()[0]
	print("bad things happened: "+str(e))

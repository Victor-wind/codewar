import java.util.Scanner;//required for I/O from stdin
import java.util.TreeMap;//required for hashmap lookups
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required for Array parsing of List generics
import java.util.List;//required for List generics
import java.util.Map;//required for hashmap lookups
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Martian Numerals
 * DIFFICULTY LEVEL: Very Easy
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 9 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 12-15 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-26
 * WHAT IT TESTS: 
 * 	1.) Ability to work with numbers as units (ones, tens, hundreds, etc.)
 *  2.) Ability to understand working with numbers as symbols, and reusing symbols to mean different values
 * 	2.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# 'Martian' Numerals

How many X's did a Roman Centurion make a day in cold hard Lira? About a C's worth!
Turns out, Martians gave Rome the idea for their number system. Use the conversion
charts below to help translate some Martian numbers!

Note, that unlike the Roman Numerals, Martian Numerals reuse symbols to mean different values. B can either mean '1'
or '100' depending on where it appears in the number sequence.

## B's and W's and Z's, oh my!

|Arabic|1 |2 |3 |4 |5 |6 |7 |8 |9 |10|20|30|40|50|60|70|
|------|--|--|--|---|--|--|--|---|--|--|--|---|--|--|--|--|
|Martian |B |BB|BBB|BW|W|WB|WBB|WBBB|BK|Z|ZZ|ZZZ|ZP|P|PZ|PZZ|

|Arabic|80  |90|100|200|300|400|500|600|700|800 |900|1000|
|------|----|--|---|---|---|---|---|---|---|----|---|----|
|Martian |PZZZ|ZB|B  |BB |BBB|BG |G  |GB |GBB|GBBB|BR |R   |

## Input
You will receive a list of numbers in a data file, one number per line, up to 5 lines at a time (with a minimum of 1 line). 
No number will exceed 1000, or be less than 1.

	26
	67
	186
	408
	500

## Output
You will need to convert the numbers from Arabic (1,2,3...10...500...1000) to Martian (B,BB,BBB...Z...G...R) numerals.

	ZZWB
	PZWBB
	BPZZZWB
	BGWBBB
	G

 * 	
 * */
public class prob06 {
	private static final String DEBUG_PROB_ID = "probAF";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Tests outputs that will produce large "roman/martian" number outputs 
	 * 3.) Tests outputs which will produce single "letter" "roman/martian" number outputs
	 * 4.) Random tests of random numbers
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Tests random number output
	 * 2.) Mix of large number and small number outputs
	 * 3.) Another mix of large number and small number outputs
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * All of those W's and K's and Z's, etc. LOOK intimidating, but once the student realizes
	 * that all they have to do is hardcode a list of symbols for the 1's place, the 10's place
	 * and the 100's place, and then simply split up the number given into those places, and
	 * do the conversion as a simple lookup, then the problem basically solves itself.
	 * 
	 * The only other tricky thing to note is that Roman/Martial numerals didn't write out 
	 * place-holder zeros. Much like the Japanese counting system, if there is no number to 
	 * write for that place, they simply omit it ;)
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run() throws Exception {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readLinesFromFile(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt");
		Map<Integer,String> romanH = new TreeMap<Integer,String>();
		romanH.put(100,"B");
		romanH.put(200,"BB");
		romanH.put(300,"BBB");
		romanH.put(400,"BG");
		romanH.put(500,"G");
		romanH.put(600,"GB");
		romanH.put(700,"GBB");
		romanH.put(800,"GBBB");
		romanH.put(900,"BR");
		romanH.put(1000,"R");
		Map<Integer,String> romanT = new TreeMap<Integer,String>();
		romanT.put(10,"Z");
		romanT.put(20,"ZZ");
		romanT.put(30,"ZZZ");
		romanT.put(40,"ZP");
		romanT.put(50,"P");
		romanT.put(60,"PZ");
		romanT.put(70,"PZZ");
		romanT.put(80,"PZZZ");
		romanT.put(90,"ZB");
		Map<Integer,String> romanO = new TreeMap<Integer,String>();
		romanO.put(1,"B");
		romanO.put(2,"BB");
		romanO.put(3,"BBB");
		romanO.put(4,"BW");
		romanO.put(5,"W");
		romanO.put(6,"WB");
		romanO.put(7,"WBB");
		romanO.put(8,"WBBB");
		romanO.put(9,"BK");
		for(String line:lines){
			List<String> parts = Arrays.asList(line.trim().split("|"));
			int hundreds = 0;
			int tens = 0;
			int ones = 0;
			if (parts.size() > 2){
				hundreds = Integer.parseInt(parts.get(0))*100;
				tens = Integer.parseInt(parts.get(1))*10;
				ones = Integer.parseInt(parts.get(2));
			}
			else if (parts.size() > 1){
				tens = Integer.parseInt(parts.get(0))*10;
				ones = Integer.parseInt(parts.get(1));
			}
			else{
				ones = Integer.parseInt(parts.get(0));
			}
			if (hundreds != 0){
				System.out.print(romanH.get(hundreds));
			}			
			if (tens != 0){
				System.out.print(romanT.get(tens));
			}
			if (ones != 0){
				System.out.print(romanO.get(ones));
			}
			System.out.println();
		}
	}
	private static List<String> readLinesFromFile(String filePath) throws IOException{
		//short way to quickly read all lines from a file into an ArrayList
		return(Files.readAllLines(new File(filePath).toPath()));
		////longer way to read all lines from a file into an ArrayList (with more fine grain control)
		//List<String> lines = new ArrayList<String>();
		//Files.lines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+fileName).toPath())
        //.map(s -> s.trim())
        //.filter(s -> !s.isEmpty())
        //.forEach(s -> lines.add(s));
		//return lines;
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

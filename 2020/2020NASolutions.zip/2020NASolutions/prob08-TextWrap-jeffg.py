#!/usr/bin/python3
# jeffgreenca
# Solution time: About 10 miutes
import sys

MAX_CHARS = 80
BREAK_CHAR = " "


def reflow(s):
    """Inject line breaks in `s` as needed to limit line length"""
    short_lines = []

    line = s.strip()
    while len(line) > MAX_CHARS + 1:
        # find a valid place to break the long line,
        # by working backwards from max line length
        for i in range(MAX_CHARS, 0, -1):
            if line[i] == BREAK_CHAR:
                # line up to break is now a new short line
                short_lines.append(line[:i])
                # line after the break is still to be processed
                line = line[i + 1 :]
                break

    # add remaining portion of line (that is less than max chars)
    short_lines.append(line)

    # final reformatting - remove surrounding whitespace,
    # add line breaks between each list item (line)
    return "\n".join((r.strip() for r in short_lines))


if __name__ == "__main__":
    # since instructions say to preserve line breaks,
    # only need to consider one input line at a time.
    for line in sys.stdin.readlines():
        result = reflow(line)
        print(result)

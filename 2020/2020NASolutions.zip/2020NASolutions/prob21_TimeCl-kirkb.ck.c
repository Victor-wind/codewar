#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BUF 64
#define EMPS 1000

char NAMES[EMPS][BUF];
double PAY[EMPS];
int c=0;

int main(argc,argv) int argc; char **argv; {
char arg[2][BUF];
double rate;
int in,out;
int i;

for(i=0;i<EMPS;i++) PAY[i]=0;
while(scanf("%s %s",arg[0],arg[1])!=EOF) {
// printf("%s %s\n",arg[0],arg[1]); 
 for(i=0;i<c;i++)
  if(strcmp(arg[1],NAMES[i])==0) break;
 if(i==c) {
  strcpy(NAMES[i],arg[1]);
  c++;
 }

 scanf("%s %s",arg[0],arg[1]); rate=atof(arg[1]);
 scanf("%s %s",arg[0],arg[1]); in=atoi(arg[1]);
 scanf("%s %s",arg[0],arg[1]); out=atoi(arg[1]);
 in=(in%100)+(in/100)*60;
 out=(out%100)+(out/100)*60;
 PAY[i]+=rate*((double)(out-in))/60.0;

 scanf("%s %s",arg[0],arg[1]); in=atoi(arg[1]);
 scanf("%s %s",arg[0],arg[1]); out=atoi(arg[1]);
 in=(in%100)+(in/100)*60;
 out=(out%100)+(out/100)*60;
 PAY[i]+=rate*((double)(out-in))/60.0;

}

for(i=0;i<c;i++)
 printf("%s earned $%.2lf\n",NAMES[i],PAY[i]);

exit(0);
}

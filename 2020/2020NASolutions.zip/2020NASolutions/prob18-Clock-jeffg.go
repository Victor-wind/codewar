/* probBF Clock
   Find distance between hour hand and minute hand, in degrees.
   Solution Author: jeffg, 2020
*/
package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
)

func main() {
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		s := scanner.Text()
		answer := solve(s)
		fmt.Println(answer)
	}
}

func solve(time string) string {
	hour, minute := parseTime(time)

	degreesHour := HourToDegree(hour, minute)
	degreesMinute := MinuteToDegree(minute)
	ans := math.Abs(degreesHour - degreesMinute)

	// problem states "find the shortest angle", we may have found the large angle
	if ans > 180 {
		ans = 360 - ans
	}
	return fmt.Sprintf("The angle between the Hour hand and Minute hand is %0.2f degrees.", ans)
}

// parseInput converts string time HH:MM or H:M to integer parts
func parseTime(s string) (hour int, minute int) {
	parts := strings.SplitN(s, ":", 2)
	hour, err := strconv.Atoi(parts[0])
	if err != nil {
		panic(err)
	}
	minute, err = strconv.Atoi(parts[1])
	if err != nil {
		panic(err)
	}
	return
}

// HourToDegree returns position of clock hand in degrees for given hour
func HourToDegree(hour int, minute int) float64 {
	hour = normalizeHour(hour)
	baseDeg := posToDegree(hour, 12)
	// the tricky part of this problem: the hour hand advances slightly
	// with passing minutes, so it's not *really* on the "hour" position. I
	// got this wrong until I looked at a clock image.
	// (there are 12 * 60 "micro positions" for the hour hand)
	advDeg := posToDegree(minute, 12*60)
	return baseDeg + advDeg
}

// MinuteToDegree returns position of clock hand in degrees for given minute
func MinuteToDegree(minute int) float64 {
	return posToDegree(minute, 60)
}

// posToDegree converts a clock position to degrees, given the count of possible positions
// for example, posToDegree(5, 12) returns degrees for 5 o'clock (12 hour markings)
func posToDegree(pos, posCount int) float64 {
	return float64(pos) * (360 / float64(posCount))
}

// normalizeHour converts 24-hour value to clock face time in range 0-11
func normalizeHour(hour int) int {
	if hour > 12 {
		hour -= 12
	}
	if hour == 12 {
		return 0
	}
	return hour
}

#include <stdio.h>
#include <stdlib.h>
#define MAX 6
#define LEN 64

char name[MAX][LEN];
int price[MAX];
int afford[MAX];
int yen;
int items;
int count=0;

int main(argc,argv) int argc; char **argv; {
int i,j;
scanf("%d %d",&yen,&items);
for(i=0;i<items;i++) {
 afford[i]=0;
 scanf("%s %d",name[i],&price[i]);
}

for(i=1;i<=yen;i++)
 for(j=0;j<items;j++)
  if(!afford[j]&&(price[j]==i)&&(price[j]<=yen)) {
   afford[j]=1;
   count++;
   yen-=price[j];
   }

for(i=0;i<items;i++)
 printf("I can%s afford %s\n",afford[i]?"":"'t",name[i]);
if(!count)
 printf("I need more Yen!\n");
else
 printf("%d\n",yen);
exit(0);
}

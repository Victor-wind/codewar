import sys
for line in sys.stdin.readlines():
    hour = (int)(line.split(':')[0].strip())
    minute = (int)(line.split(':')[1].strip())
    if hour > 12:
        hour = hour - 12
    distance_hr = hour*30 + minute*0.5
    distance_minute = minute*6
    ans = abs(distance_hr - distance_minute)
    if (ans > 180):
        ans = 360 - ans
    print('The angle between Hour and Minute hand is {:.2f} degrees'.format(round(ans,2)))

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#define BUF 128



char rot(a) char a; {
if(a==' ') return a;
if(a=='o') return('o');
if(a=='s') return('s');
if(a=='x') return('x');
if(a=='z') return('z');
if(a=='a') return('e');
if(a=='e') return('a');
if(a=='b') return('q');
if(a=='q') return('b');
if(a=='d') return('p');
if(a=='p') return('d');
if(a=='h') return('y');
if(a=='y') return('h');
if(a=='m') return('w');
if(a=='w') return('m');
if(a=='n') return('u');
if(a=='u') return('n');

return a;
}

int legal(a,b) char a,b; {

if((a=='o') && (b=='o')) return 1;
if((a=='s') && (b=='s')) return 1;
if((a=='x') && (b=='x')) return 1;
if((a=='z') && (b=='z')) return 1;
if((a=='a') && (b=='e')) return 1;
if((a=='e') && (b=='a')) return 1;
if((a=='b') && (b=='q')) return 1;
if((a=='q') && (b=='b')) return 1;
if((a=='d') && (b=='p')) return 1;
if((a=='p') && (b=='d')) return 1;
if((a=='h') && (b=='y')) return 1;
if((a=='y') && (b=='h')) return 1;
if((a=='m') && (b=='w')) return 1;
if((a=='w') && (b=='m')) return 1;
if((a=='n') && (b=='u')) return 1;
if((a=='u') && (b=='n')) return 1;

return 0;
}

int clean(from,to) char from[],to[]; {
int i,j;

for(i=j=0;from[i];i++)
 if(isalpha(from[i]))  {
  to[j++]=from[i]+((from[i]<'a')?('a'-'A'):0);
}
to[j]='\0';
return(j);
}

int main(argc,argv) int argc; char **argv; {
int n;
int i,j;
int f;
char buf[BUF];
char in[BUF];
scanf("%d\n",&n);
while(fgets(buf,BUF-1,stdin)) {
j=clean(buf,in);


for(f=1,i=0;in[i]&&f;i++)
 f=f&&legal(in[i],in[j-i-1]);

for(i=0;buf[i];i++) {
 if(!((buf[i]==' ')||isalpha(buf[i]))) continue;
 if(buf[i]==' ') putchar(buf[i]);
 else printf("%c",((buf[i]<'a')?(buf[i]-'A'+'a'):buf[i]));
}

printf(" (%s) ",f?"is":"not");
j=i-1;
for(i=0;i<j;i++) {
 if(!((buf[j-i-1]==' ')||isalpha(buf[j-i-1]))) continue;
 if(buf[j-i-1]==' ') putchar(buf[j-i-1]);
 else printf("%c",((buf[j-i-1]<'a')?(rot(buf[j-i-1]-'A'+'a')):rot(buf[j-i-1])));

}
printf("\n");

}
exit(0);
}

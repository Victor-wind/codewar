import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required to parse split from array into List
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Mad Libs
 * DIFFICULTY LEVEL: Easy
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 12 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 15-20 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-27
 * WHAT IT TESTS: 
 * 	1.) Ability to sort and order multiple sets of data concurrently, where order is important
 * 	2.) Ability to parse and interpolate a string
 * 	3.) Ability to iterate through a set of data (array or list) keeping track of multiple position markers at the same time
 * 	4.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# Mad Libs
## (5 pts.)

Your first job out of college is for a children's book publisher. They are currently publishing a line of "mad libs" books, and they need you to check their print-copy. Write a program that will take a sentence with placeholders in it, and substitute in for those placeholders words from the lists of example words the publisher has provided.

### Input

Line one will always be the line with the story. The order of the Nouns, Adverbs, Verbs and Adjectives will always be the same. Input stops when it reaches the word END alone on a line. You are guaranteed to always have enough words to substitute into the sentence TWICE (not repeating any words). The number of words given under each section will be random. The data file you receive will always be in the format of:

    Story sentence
    NOUNS
    noun
    ADVERBS
    adverb
    VERBS
    verb
    ADJECTIVES
    adjective
    END

Your goal will be to substitute the appropriate words into the sentence from the list of provided words TWICE (keeping track of the words you have used) where:

    [N] = nouns
    [AV] = adverbs
    [V] = verbs
    [AJ] = adjectives

    Example:

    There once was a [AJ] [N] from [N] who [AV] [V] all day.
    NOUNS
    squirrel
    London
    tree
    lettuce
    ADVERBS
    silently
    quickly
    happily
    VERBS
    skipped
    ran
    climbs
    ADJECTIVES
    delightful
    homely
    quaint
    END

### Output

Always take the TOP-most UNUSED word from a group when substituting. E.G. from the example Nouns list, use: "squirrel," then "London," then "tree," etc. Output the final sentence when all substitutions are done.

    There once was a delightful squirrel from London who silently skipped all day.
    There once was a homely tree from lettuce who quickly ran all day.

 * 	
 * */
public class prob10 {
	private static final String DEBUG_PROB_ID = "probAG";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Standard puzzle input words list, nothing tricky
	 * 3.) Standard puzzle input words list, nothing tricky
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1-3.) Standard puzzle input words list, nothing tricky. The output should be exact though, including cAsE 
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * This problem's biggest difficulty will be keeping track of the various lists of data
	 * and also keeping track of where in those lists you "are" when using the data off the list.
	 * That will be especially problematic for students using arrays instead of generic lists.
	 * Even a linked-list would be better, as you can simply append to those, and even remove items
	 * no longer needed in the collection.
	 * 
	 * The rest of the problem is just pattern matching and string interpolation, and shouldn't
	 * cause any major difficulties.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt").toPath());
		String story = "";
		List<String> nouns = new ArrayList<String>();
		List<String> adverbs = new ArrayList<String>();
		List<String> verbs = new ArrayList<String>();
		List<String> adjectives = new ArrayList<String>();
		
		boolean onNouns = false;
		boolean onAdverbs = false;
		boolean onVerbs = false;
		boolean onAdj = false;
		for(String line:lines){
			if (story.length()==0){
				story = line.trim();
			}
			else if (line.trim().equalsIgnoreCase("END")){
				//skip
			}
			else if (line.trim().equalsIgnoreCase("NOUNS")){
				onNouns = true;
			}
			else if (line.trim().equalsIgnoreCase("ADVERBS")){
				onNouns = false;
				onAdverbs = true;
			}
			else if (line.trim().equalsIgnoreCase("VERBS")){
				onAdverbs = false;
				onVerbs = true;
			}
			else if (line.trim().equalsIgnoreCase("ADJECTIVES")){
				onVerbs = false;
				onAdj = true;
			}
			else if (onNouns){
				nouns.add(line.trim());
			}
			else if (onAdverbs){
				adverbs.add(line.trim());
			}
			else if (onVerbs){
				verbs.add(line.trim());
			}
			else if (onAdj){
				adjectives.add(line.trim());
			}
		}
		for (int i=1;i<=2;i++){
			int counter = 0;
			List<String> words = Arrays.asList(story.split(" "));
			for(String word:words){
				if (word.equalsIgnoreCase("[N]")){
					words.set(counter, nouns.get(0));
					nouns.remove(0);
				}
				else if (word.equalsIgnoreCase("[AV]")){
					words.set(counter, adverbs.get(0));
					adverbs.remove(0);
				}
				else if (word.equalsIgnoreCase("[V]")){
					words.set(counter, verbs.get(0));
					verbs.remove(0);
				}
				else if (word.equalsIgnoreCase("[AJ]")){
					words.set(counter, adjectives.get(0));
					adjectives.remove(0);
				}
				counter++;
			}
			int j=0;
			for(String word:words){
				if (j>0){
					System.out.print(" ");
				}
				System.out.print(word);
				j++;
			}
			System.out.println();
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

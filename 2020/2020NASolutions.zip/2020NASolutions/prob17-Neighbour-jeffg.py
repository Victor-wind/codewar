#!/usr/bin/python3
# Who is my neighbour
# Solution author: jeffg, 2020
import sys
import re


def parse(lines):
    """parse raw input from stdin into cities and edges list"""
    # parse raw input lines
    lines = list(map(str.strip, lines))
    count, lines = int(lines[0]), lines[1:]
    cities, connections = lines[:count], lines[count:]
    edges = _build_edges(connections)
    return cities, edges


def _build_edges(connections):
    """Build edges from raw connections list, excluding air travel"""
    edges = set()
    for conn in connections:
        # this uses two capture groups to grab the city names
        m = re.search("City (.+) is connected to City (.+) by (?!air)", conn)
        if not m:
            continue
        a, b = m.group(1), m.group(2)
        # add edge bidirectionally for easier use later
        edges.add((a, b))
        edges.add((b, a))
    return edges


def find_neighbours(city, edges):
    """Return a set of all directly and indirectly connected neighbours of city"""
    n = set()
    _find_neighbours(city, edges, n)
    n.discard(city)
    return n


def _find_neighbours(city, edges, n):
    """Recursively search for neighbours of city, adding them to n"""
    for e in edges:
        if e[0] == city and e[1] not in n:
            n.add(e[1])
            _find_neighbours(e[1], edges, n)


def solve(cities, edges):
    """Solve and print output per problem instructions"""
    for c in cities:
        n = find_neighbours(c, edges)
        if len(n) == 0:
            print(f"City {c} is remote and has no neighbours!")
        else:
            # sets are unsorted, so put in order cities originally presented
            neighbours = sorted(n, key=lambda city: cities.index(city))
            print(f"City {c} is neighbour to Cities", ",".join(neighbours))


if __name__ == "__main__":
    cities, edges = parse(sys.stdin.readlines())
    solve(cities, edges)


#include <stdio.h>
#include <stdlib.h>
#define LEN 256

int main(argc,argv) int argc; char **argv; {
int y,f,i;
char buf[LEN];
int r;
char *s;
while(fgets(buf,LEN-1,stdin)) {
y=f=i=0;
s=buf;
sscanf(s,"%d%n",&y,&r); s+=r;
sscanf(s,"%d%n",&f,&r); s+=r;
sscanf(s,"%d%n",&i,&r);
printf("%.2lf\n",(y*36.0+f*12.0+i)*2.54);
}
}

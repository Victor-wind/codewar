import sys

def findOddSum(Num):
    sum = 0
    Num = int(Num / 10)
    while(Num > 0):
        sum = sum + (Num % 10)
        Num =int(Num/10)
        Num = int(Num/10)
    return sum

def findEvenSum(Num):
    sum = 0
    while(Num >0):
        sum = sum + (Num % 10)
        Num = int(Num/10)
        Num = int(Num/10)
    return sum


lines = sys.stdin.readlines()
N1 = int(lines[0])
N2 = int(lines[1])
ans_list = []
for index in range(N1,N2):
    if((index%11) == 0):
        if (findOddSum(index) == findEvenSum(index)):
            ans_list.append(index)
            break
index = index + 11
while (index < N2):
    if (findOddSum(index) == findEvenSum(index)):
        ans_list.append(index)
    index = index + 11
ans = " ".join(str(i) for i in ans_list)
if len(ans_list) == 0 or ans == "0":
    print("No Numbers found with Equal Sum in the given range!!")
else:
    print(ans)

import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.Collections;//required to reverse Generic Lists
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Hidden Hex Message
 * DIFFICULTY LEVEL: Easy-Intermediate
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 11 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 15-20 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-27
 * WHAT IT TESTS: 
 * 	1.) Ability to understand Hexidecimal data
 * 	2.) Ability to generate dexidecimal strings/characters
 * 	3.) Ability to convert between characters and hexidecimal values
 *  4.) Ability to work with substrings
 *  5.) Ability to order arrays or lists or to work backwards through an array or List
 * 	6.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 *
# Hidden Hex Message

Steganography is the science of hiding messages in pictures or text. You have been hired to write a program which will decode words hidden in a popular daily word game, to help a freedom fighter smuggle information out of their oppressive homeland. The steganographic code you have agreed on is that every 4th character of the hex code of the letters in the puzzle will be part of the secret message.

## Letter Hex Codes

|ASCII|a |b |c |...|i |j |k |...|o |p |q |...|w |x |y |z |
|-----|--|--|--|---|--|--|--|---|--|--|--|---|--|--|--|--|
|Hex  |61|62|63|...|69|6A|6B|...|6F|70|71|...|77|78|79|7A|

|ASCII|A |B |C |...|I |J |K |...|O |P |Q |...|W |X |Y |Z |
|-----|--|--|--|---|--|--|--|---|--|--|--|---|--|--|--|--|
|Hex  |41|42|43|...|49|4A|4B|...|4F|50|51|...|57|58|59|5A|

## Input
You will receive two lines in your data file. The first will be the puzzle sentence. The second will be the question or prompt which the secret message will answer.

	bump ow fun waps wept guy
	What fixes everything?

## Decoding

|e |x |a |m |p |l |e |
|--|--|--|--|--|--|--|
|65|78|61|6D|70|6C|65|


	Every 4th character starting from the right:
	5105
	(You can also approach the problem from the left, but if you do that, you need to take into account odd vs. even in your algorithm)

## Output
Convert the puzzle sentence into hex code for each letter (leave the spaces as spaces).
Then output the rightmost character from the hex code, then output every 4th character after that (ignoring spaces), working left.
Then combine those characters in groups of 2, and output the cooresponding ASCII letter to see the secret message.

	62 75 6d 70 6f 77 66 75 6e 77 61 70 73 77 65 70 74 67 75 79
	5075707079
	Puppy

 * 	
 * */
public class prob19 {
	private static final String DEBUG_PROB_ID = "probAB";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1-5.) Standard puzzle, nothing tricky (output is case CaSe SeNsItIvE though, need to decide correct character)
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1-3.) Standard puzzle, nothing tricky (output is case CaSe SeNsItIvE though, need to decide correct character)
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * The biggest problem a novice programmer might have with this problem is working with 
	 * hexidecimal characters, if they have never done so before. That's why the range for a-z
	 * and A-Z are given, so they can hardcode the conversions if needed, if they don't know how
	 * to work with hex in the language of their choice.
	 * 
	 * Everything else is straight forward, convert each character in the input string to its
	 * hex equivalent, then, counting from the right (which requires either a descending sort
	 * on a list/array or a down-counting loop) pull out every 4th character from the hex characters
	 * and then group them in pairs representing new hex character, and then output the word
	 * from that grouping, by converting back into alpha characters (via an integer to char conversion).
	 * 
	 * In case the students are wondering, the reason for counting from the right is that sometimes
	 * there may be a "hanging character" or two trailing off the left hand side which aren't part
	 * of the message, but were needed to make the sentence work. E.G. The output may look like:
	 * 
	 * 								XCXXXCXXXCXXXC
	 * 
	 * Where C are the characters you want and X are ignored. If you started from the left
	 * the entire character set would be off by one, and would output gibberish. 
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
		System.exit(0);
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt").toPath());
		if (lines.size() > 0){
			Decode(lines.get(0));
		}
	}
	/**
	 * takes the string to decode, and applies the logic to split it up
	 * into single characters, convert each character to hex (using
	 * integer parsing), then pull out the secret message pieces,
	 * arrange them, pair them, and output the secret message
	 * */
	private static void Decode(String encoded){
		String[] letters = encoded.split("|");
		List<String> output = new ArrayList<String>();
		for(String letter:letters){
			int c = letter.charAt(0);
			if (c!= 32){
				String hex = Integer.toHexString(c);
				output.add(hex);
				System.out.print(hex+" ");
			}
		}
		System.out.println();
		List<String> secretMessage = new ArrayList<String>();
		Collections.reverse(output);
		for(int i=0; i<output.size(); i+=2){
			secretMessage.add(output.get(i).substring(1,2));
			//secretMessage.add();
		}
		Collections.reverse(secretMessage);
		for(String secret:secretMessage){
			System.out.print(secret);
		}
		System.out.println();
		for(int i=0;i<(secretMessage.size()-1);i +=2){
			String tmp = secretMessage.get(i) + secretMessage.get(i+1);
			int value = Integer.parseInt(tmp, 16);
			System.out.print((char)value);
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required to parse split from array into List
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Is it a Cyclops number? "Nobody" knows!
 * DIFFICULTY LEVEL: Easy-Intermediate
 * TIME TAKEN TO CODE SOLUTION: 10 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 12-15 minutes
 * PROBLEM AUTHOR: Lee Jenkins
 * SOLUTION AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2020-02-15
 * WHAT IT TESTS: 
 * 	1.) Ability to transform integers to binary
 * 	2.) Ability to parse string data
 * 	3.) Ability to manipulate characters in a string
 *  4.) (Also might test student's knowledge of binary data patterns, if they choose to solve via calculations of binary numbers, instead of with string manipulation)
 * 	5.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 * */
public class prob11 {
	private static final String DEBUG_PROB_ID = "probAK";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Test set with no valid cyclops numbers
	 * 3.) Test set with 2 valid cyclops numbers, and 2 invalid
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) mix of mostly cyclops numbers ranging from zero to 536854527, and a few non-cyclops number
	 * 2.) mostly decimal numbers (which LOOK like binary numbers) which are not cyclops numbers + 1 real cyclops number
	 * 3.) all odd numbers from, skipping 27, with only one cyclops number in the set (5)
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * It took me a couples minutes to figure out that ONLY ONE zero (total) was allowed (because
	 * I skimmed the instructions ^_^) and that it wasn't just if the CENTER digit was a zero or
	 * not was the deciding factor. The original instructions weren't 100% clear on that.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		//List<String> lines = readFromFileInputByCommandLine();
		//debugging
		List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt").toPath());
		try{
			for(String line:lines){
				int num = Integer.parseInt(line.trim());
				String bin = Integer.toBinaryString(num);
				//System.out.println("DEBUG: "+num+"=>"+bin);
				if (bin.length() % 2 != 0){
					List<String> digits =Arrays.asList(bin.trim().split("|"));
					int zeroes = 0;
					for(String d:digits){
						if (d.equals("0")){
							zeroes++;
						}
					}
					if (zeroes == 1){				
						double center = Math.floor(bin.length()/2);
						//System.out.println("DEBUG: center: "+center + " pulled: "+bin.substring((int)center, ((int)center+1)));
						if (bin.substring((int)center, ((int)center+1)).equals("0")){
							System.out.println(line + " yes");
						}
						else{
							System.out.println(line + " no");
						}
					}
					else{
						System.out.println(line + " no");
					}
				}
				else{
					System.out.println(line + " no");
				}
			}
		} 
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

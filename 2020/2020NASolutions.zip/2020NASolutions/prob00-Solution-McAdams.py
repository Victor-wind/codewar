import sys
#PROBLEM: Problem 0
#DIFFICULTY LEVEL: Very Easy
#TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: < 1 minutes
#ESTIMATED STUDENT COMPLETION TIME NEEDED: < 1 minutes
#PROBLEM AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
#LAST MODIFIED: 2020-05-06
#WHAT IT TESTS: 
#	1.) Basic 'hello world' coding ability, e.g. "can you get any kind of program at all to run on your environment?"
# 
#PROBLEM DESCRIPTION: 
# 
# all you need to do is print to the screen the first words ever transmitted by telephone: 
# "Mr. Watson, come here!"
#
print("Mr. Watson, come here!")

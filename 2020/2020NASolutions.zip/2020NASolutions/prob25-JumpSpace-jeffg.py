#!/usr/bin/python3
# Jump Space solution
# jeffg, 2020
import sys
import logging

# change this from INFO to DEBUG for tracing
logging.basicConfig(level=logging.INFO, format='%(message)s')

# hexagonal coordinates definitions
# XXYY where XX = column (range 1..99)
#            YY = row    (range 1..99)

# movement costs in this coordinate system
# can always move (1 row) OR (1 column)
# if column == even can move (+1 row AND 1 column)
# if column == odd can move (-1 row AND 1 column)

ADJ_BASE = [(1,0),(-1,0),(0,1),(0,-1)]
ADJ_EVEN = ADJ_BASE + [(1,1),(-1,1)]
ADJ_ODD  = ADJ_BASE + [(1,-1),(-1,-1)]

def adjacencies(pos):
    moves = ADJ_EVEN if pos[0] % 2 == 0 else ADJ_ODD
    return [(pos[0] + m[0], pos[1] + m[1]) for m in moves]

def calc_cost(a, b):
    '''
    "cost" is not exactly the distance from a to b, but an approximation that
    is good enough for our algorithm.
    '''
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def find_distance(position, destination):
    '''
    Finds shortest path from position to destination, by moving one step at a
    time, each time choosing the step that minimizes "cost"
    '''
    traveled = 0
    while position != destination:
        cost = calc_cost(position, destination)
        logging.debug(f"cost from {position} to {destination}: {cost}")
        for adj in adjacencies(position):
            cost_from_adj = calc_cost(adj, destination)
            logging.debug(f"cost from adj {adj} to {destination}: {cost_from_adj}")
            if cost_from_adj < cost:
                logging.debug("...best move so far")
                cost = cost_from_adj
                best_move = adj
        logging.debug(f"...moving to {best_move}!")
        position = best_move
        traveled += 1
    return traveled

def read_data():
    locations = {}
    trips = []
    lines = sys.stdin.readlines()

    # parse first line
    counts = tuple(map(int, lines[0].strip().split(" ")))

    # parse list of locations into dict
    lines = lines[1:]
    for line in lines[:counts[0]]:
        coords, name = line.strip().split(" ")
        x = int(coords[0:2])
        y = int(coords[2:4])
        locations[name] = (x,y)

    # parse list trips into list data
    lines = lines[counts[0]:]
    for line in lines[:counts[1]]:
        parts = line.strip().split(" ")
        trips.append((parts[0], parts[1]))
    return locations, trips

if __name__ == "__main__":
    locations, trips = read_data()
    for trip in trips:
        dist = find_distance(locations[trip[0]], locations[trip[1]])
        print(f"{trip[0]} {trip[1]} {dist}")

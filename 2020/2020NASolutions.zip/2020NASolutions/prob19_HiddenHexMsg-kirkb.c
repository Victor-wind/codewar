#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#define BUF 1024

char buf[BUF];
char crypt[BUF];
char out[BUF];

int main(argc,argv) int argc; char **argv; {
int i,j;
fgets(buf,BUF-1,stdin);
for(i=j=0;buf[i];i++)
 if(isalpha(buf[i])) 
  printf("%02x ", crypt[j++]=buf[i]);
printf("\n");
for(i=(j%2==0);i<j;i+=4) 
 printf("%02x",out[i/4]=(crypt[i]%16)*16+crypt[i+2]%16);
printf("\n");
out[i+1]=0;
printf("%s\n",out);
}

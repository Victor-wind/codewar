import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required to parse split from array into List
import java.util.List;//required for List generics
import java.util.TreeMap;//required for hashmap lookups
import java.util.Map;//required for hashmap lookups
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Color Mixer
 * DIFFICULTY LEVEL: Very Easy
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 10 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 11-12 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-27
 * WHAT IT TESTS: 
 * 	1.) Ability to either setup a hash key lookup for a set of key/value pairs, or a way to "multiply" strings according to the logic of the problem
 * 	2.) Ability to iterature through the dataset and output the results according the algorithm's logic
 * 	3.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# Color Mixer
## (4 pts.)

ROYGBIV isn't just an acronym, it's a way of life for your paint company. The owner is considering modernizing her paint mixing equipment with a computerized model. She's hired you to code the prototype. Your simple program will need to correctly output the right color based on the blends she's given you.

### Input

You will receive one to five lines of color combinations consisting of primary colors and secondary colors as well as black and white to make "dark" and "light" colors. The full science of colorization and pigments will be implemented next, if your prototype is successful.

    RED YELLOW
    BLUE WHITE
    YELLOW YELLOW
    ORANGE BLACK

### Output

Your program should output the correct color depending on what two colors were "mixed" on the line. Primary colors should mix together to create secondary colors. Anything mixed with "WHITE" or "BLACK" should be output as either "LIGHT X" or "DARK X" where X is the color "WHITE" or "BLACK" were mixed with. Anything mixed with itself won't change colors. You are guaranteed not to receive incompatible colors, or colors not listed in the color wheels shown above (aside from "WHITE" and "BLACK").

    ORANGE
    LIGHT BLUE
    YELLOW
    DARK ORANGE


 * 	
 * */
public class prob07 {
	private static final String DEBUG_PROB_ID = "probAH";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Mix of secondary colors plus one color not mixing with anything else (should stay the same)
	 * 3.) Shows that a color can be mixed "light" or "dark" in any order, a secondary color, and a color staying the same again
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1-3.) Same type of mix as the student problems, testing for colors not changing, secondary and tertiary colors, etc.
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * The "correct" way to implement something like this would be as a RGB gradient scale, or
	 * even HTML/CSS 000000 to FFFFFF scales for colors. If you wanted to get fancy, you could
	 * even implement an HSL (hue, saturation, lightness) color scale.
	 * 
	 * But that would be for professional work to do something like this for real. This is for
	 * a timed contest, and we're only dealing with 6 named colors plus "black" and "white" to
	 * lighten/darken those colors.
	 * 
	 * Simpliest (and fastest) solution is to hardcode all possible combinations of those colors
	 * (forwards and backwards) in a hashmap (or 2-dim array) with the resulting color mixing 
	 * result as the value of the hashmap (or 2-dim array). Anything other than that will take 
	 * more time than needed. The problem tells the student they are coding a prototype. Don't 
	 * get fancy with prototypes, just make them work ;) 
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt").toPath());
		Map<String,String> colors = new TreeMap<String,String>();
		colors.put("RED YELLOW","ORANGE");
		colors.put("YELLOW RED","ORANGE");
		colors.put("RED BLUE","PURPLE");
		colors.put("BLUE RED","PURPLE");
		colors.put("BLUE YELLOW","GREEN");
		colors.put("YELLOW BLUE","GREEN");
		colors.put("RED WHITE","LIGHT RED");
		colors.put("WHITE RED","LIGHT RED");
		colors.put("RED BLACK","DARK RED");
		colors.put("BLACK RED","DARK RED");
		colors.put("YELLOW WHITE","LIGHT YELLOW");
		colors.put("WHITE YELLOW","LIGHT YELLOW");
		colors.put("YELLOW BLACK","DARK YELLOW");
		colors.put("BLACK YELLOW","DARK YELLOW");
		colors.put("BLUE WHITE","LIGHT BLUE");
		colors.put("WHITE BLUE","LIGHT BLUE");
		colors.put("BLUE BLACK","DARK BLUE");
		colors.put("BLACK BLUE","DARK BLUE");
		colors.put("ORANGE WHITE","LIGHT ORANGE");
		colors.put("WHITE ORANGE","LIGHT ORANGE");
		colors.put("ORANGE BLACK","DARK ORANGE");
		colors.put("BLACK ORANGE","DARK ORANGE");
		colors.put("PURPLE WHITE","LIGHT PURPLE");
		colors.put("WHITE PURPLE","LIGHT PURPLE");
		colors.put("PURPLE BLACK","DARK PURPLE");
		colors.put("BLACK PURPLE","DARK PURPLE");
		colors.put("GREEN WHITE","LIGHT GREEN");
		colors.put("WHITE GREEN","LIGHT GREEN");
		colors.put("GREEN BLACK","DARK GREEN");
		colors.put("BLACK GREEN","DARK GREEN");
		for(String line:lines){
			List<String> parts = Arrays.asList(line.trim().split(" "));
			if (parts.size() > 1){
				if (parts.get(0).trim().equalsIgnoreCase(parts.get(1).trim())){
					System.out.println(parts.get(0).trim());
				}
				else{
					System.out.println(colors.get(line.trim()));
				}
			}
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

#!/usr/bin/python3
# Cyclops Number
# Solution author: jeffg, 2020
# Using bit masking approach.
import sys

def binLen(num):
    length = 1
    while num >> length > 0:
        length += 1
    return length

def isCyclops(num):
    # special case
    if num == 0:
        return True
    # general solution
    length = binLen(num)
    if length % 2 == 0:
        return False
    fill = (2**length) - 1
    inverted = num ^ fill
    return  inverted == 1 << length // 2

if __name__ == "__main__":
    for num in map(int, sys.stdin):
        ans = "yes" if isCyclops(num) else "no"
        print(num, ans)

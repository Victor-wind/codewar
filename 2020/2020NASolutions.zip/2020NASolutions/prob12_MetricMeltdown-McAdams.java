import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required for Array parsing of List generics
import java.util.List;//required for List generics
import java.text.DecimalFormat;//required for rounding
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Metric Meltdown
 * DIFFICULTY LEVEL: Intermediate
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 15 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 20-22 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-27
 * WHAT IT TESTS: 
 * 	1.) Ability to work with integers and decimals, and to not lose precision when converting data types
 * 	2.) Ability to format and round decimal math outputs
 * 	3.) Ability to convert units between wildly different standards
 * 	4.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# Metric Meltdown
## (5 pts.)

You're building a ramp to practice your mad skating skills, but your local lumber yard only takes measurements in metric units!
All of the measurements you took were in US-Imperial units.
Quick! You need to convert those measurements before the store closes!

### Input

You will receive up to 3 numbers, separated by spaces. The left-most number is yards.
A second number on the line will be feet.
A third number on the same line will be inches.

    1 1 1
    5
    1 2
    0 7
    0 0 9

### Output

Convert the yards (+ feet + inches) to centimeters. Round answers to 2 decimal places.
One foot (ft) is equal to 0.3048 meters (m)  
One inch (in) is equal to 2.54 centimeters (cm)  

    124.46
    457.20
    152.40
    213.36
    22.86

 * 	
 * */
public class prob12 {
	private static final String DEBUG_PROB_ID = "probAO";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	private static final double ftToM = 0.3048;//conversion value from feet to meters
	private static final double inToCm = 2.54;//conversion value from inches to centimeter
	private static DecimalFormat df = new DecimalFormat("0.00");//global constant for rounding decimals
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Tests having only a single number in each number column, plus a zero value
	 * 3.) Standard mix of numbers, nothing tricky
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1-3.) Standard mix of numbers, nothing tricky
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * This problem involves unit-changing, mathematics, and dealing with integer to decimal
	 * conversions, as well as rounding decimals, and handling some edge cases. All of which are
	 * things beginning students may struggle with.
	 * 
	 * Once the student figures out to put everything into the same units, then run the calcs
	 * and THEN output the formatting, things will go smoothly.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt").toPath());
		for(String line:lines){
			//System.out.println("DEBUG "+line);
			List<String> parts = Arrays.asList(line.trim().split(" "));
			double yards = 0;
			if (parts.size() > 0){
				yards = convertFeetToCentimeters(parts.get(0).trim(),true);
				//System.out.println("DEBUG yards: "+df.format(yards));
			}
			double feet = 0;
			if (parts.size() > 1){
				feet = convertFeetToCentimeters(parts.get(1).trim(),false);
				//System.out.println("DEBUG feet: "+df.format(feet));
			}
			double inches = 0;
			if (parts.size() > 2){
				inches = convertInchesToCentimeters(parts.get(2).trim());
				//System.out.println("DEBUG inches: "+df.format(inches));
			}
			System.out.println(df.format(yards+feet+inches));
		}
	}
	/**
	 * Takes a string representing feet, with a flag to convert from yards to feet
	 * (eg if 2 is passed in for "feet" but isYards is true, then 2 will be multiplied
	 * by 3 (there are 3 feet in a yard) to get 6 feet.
	 * Output uses the global constant ftToM to convert the feet to centimeters.
	 * */
	private static double convertFeetToCentimeters(String feet, boolean isYards){
		double result = 0;
		double input = Double.parseDouble(feet);
		if (isYards){
			input *= 3;
		}
		double m = input * ftToM;
		result = m*100;
		return result;
	}
	/**
	 * Takes a string representing inches and outputs centimeters.
	 * Output uses the global constant inToCm to convert the inches to centimeters.
	 * */
	private static double convertInchesToCentimeters(String inches){
		double result = 0;
		double input = Double.parseDouble(inches);
		result = input * inToCm;
		return result;
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define SECOND (1)
#define MINUTE (60*SECOND)
#define HOUR (60*MINUTE)
#define DAY (24*HOUR)

#define CMD 32
#define BUF 1024
//
//       struct tm {
//               int tm_sec;    /* Seconds (0-60) */
//               int tm_min;    /* Minutes (0-59) */
//               int tm_hour;   /* Hours (0-23) */
//               int tm_mday;   /* Day of the month (1-31) */
//               int tm_mon;    /* Month (0-11) */
//               int tm_year;   /* Year - 1900 */
//               int tm_wday;   /* Day of the week (0-6, Sunday = 0) */
//               int tm_yday;   /* Day in the year (0-365, 1 Jan = 0) */
//               int tm_isdst;  /* Daylight saving time */
//           };
//
struct tm start,stop;
time_t from,to;
long long int delta;
char cmd[CMD];
char out[BUF];

void decode(delta) long long int delta; {
char t[BUF];
long long int days,hours,minutes,seconds;

out[0]='\0';

if(strstr(cmd,"D")) {
 days=delta/DAY;
 delta%=DAY;
 sprintf(t," %lld days",days);
 strcat(out,t);
 }

if(strstr(cmd,"H")) {
 hours=delta/HOUR;
 delta%=HOUR;
 sprintf(t," %lld hours",hours);
 strcat(out,t);
 }

if(strstr(cmd,"M")) {
 minutes=delta/MINUTE;
 delta%=MINUTE;
 sprintf(t," %lld minutes",minutes);
 strcat(out,t);
 }

if(strstr(cmd,"S")) {
 seconds=delta;
 delta=0;
 sprintf(t," %lld seconds",seconds);
 strcat(out,t);
 }


}

int main(argc,argv) int argc; char **argv; {
while(scanf("%d-%d-%d %d:%d:%d %d-%d-%d %d:%d:%d %s\n",
&start.tm_year,
&start.tm_mon,
&start.tm_mday,
&start.tm_hour,
&start.tm_min,
&start.tm_sec,

&stop.tm_year,
&stop.tm_mon,
&stop.tm_mday,
&stop.tm_hour,
&stop.tm_min,
&stop.tm_sec,
 cmd)!=EOF) {

start.tm_year -= 1900; start.tm_mon -= 1;
stop.tm_year -= 1900; stop.tm_mon-= 1;

from=mktime(&start);
to=mktime(&stop);
delta=(long long int)difftime(to,from);
decode(delta);
printf("there are%s remaining until %4d-%02d-%02d %02d:%02d:%02d\n", 
 out,
 stop.tm_year+1900,
 stop.tm_mon+1,
 stop.tm_mday,
 stop.tm_hour,
 stop.tm_min,
 stop.tm_sec);

}
}

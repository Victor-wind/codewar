#include <stdio.h>
#include <string.h>

char colors[8][32] = { "RED", "YELLOW", "BLUE", "GREEN", "ORANGE", "PURPLE", "BLACK", "WHITE" };
char mixes[8][8][32] = {
/* R */ { "RED", "ORANGE", "PURPLE", "N/A", "M/A", "N/A", "DARK RED", "LIGHT RED" },
/* Y */ { "ORANGE", "YELLOW", "GREEN", "N/A", "N/A", "N/A", "DARK YELLOW", "LIGHT YELLOW" },
/* B */ { "PURPLE", "GREEN", "BLUE", "N/A", "N/A", "N/A", "DARK BLUE", "LIGHT BLUE" },
/* G */ { "N/A", "N/A", "N/A", "GREEN", "N/A", "N/A", "DARK GREEN", "LIGHT GREEN" },
/* O */ { "N/A", "N/A", "N/A", "N/A", "ORANGE", "N/A", "DARK ORANGE", "LIGHT ORANGE" },
/* P */ { "N/A", "N/A", "N/A", "N/A", "N/A", "PURPLE", "DARK PURPLE", "LIGHT PURPLE" },
/* Bl*/ { "DARK RED", "DARK YELLOW", "DARK BLUE", "DARK GREEN", "DARK ORANGE", "DARK PURPLE", "BLACK", "GREY" },
/* Wh*/ { "LIGHT RED", "LIGHT YELLOW", "LIGHT BLUE", "LIGHT GREEN", "LIGHT ORANGE", "LIGHT PURPLE", "GREY", "WHITE" }
};

int lookup(c) char *c; {
int i;
for(i=0;i<8;i++)
 if(strcmp(c,colors[i])==0) break;
return(i);
}

int main(argc, argv) int argc; char **argv; {
char a[32],b[32];
char buf[64];

while(fgets(buf,63,stdin)) {
 sscanf(buf,"%s %s",a,b);
 printf("%s\n",mixes[lookup(a)][lookup(b)]);
 }
 }

import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required to parse split from array into List
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Down, Oh You Mop!
 * DIFFICULTY LEVEL: Intermediate
 * TIME TAKEN TO CODE SOLUTION: 19 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 21-25 minutes
 * PROBLEM AUTHOR: Lee Jenkins
 * SOLUTION AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2020-02-20
 * WHAT IT TESTS: 
 * 	1.) Ability to remove/filter & change characters in/from a string
 * 	2.) Ability to change the case of a string
 * 	3.) Ability to reverse a string (not exactly fun if all one has to work with is arrays in languages such as C)
 *  4.) Ability to compare sets of string data without spaces, while preserving the originals for output
 * 	5.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 * */
public class prob23 {
	private static final String DEBUG_PROB_ID = "probAT";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Random words/nonsense with 1 'down-oh-you-mop' sentence
	 * 3.) Random words/nonsense with 2 'down-oh-you-mop' sentences
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Random words/nonsense with 3 'down-oh-you-mop' sentences
	 * 2.) Random words/nonsense with 1 'down-oh-you-mop' sentence
	 * 3.) Random words/nonsense with 2 'down-oh-you-mop' sentences
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * Just list the punctuation to exclude. Else, the only way to be safe is to eliminate all
	 * non-alphabet characters, which requires the students to either find/replace all of them,
	 * or know how to do a regex. If they go down that path, it will add a lot of time to their
	 * solution attempt.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt").toPath());
		try{
			int lineNum = 1;
			for(String line:lines){
				if (lineNum != 1)
				{
					line = line.toLowerCase().replace(".", "").replace(",", "").replace("!", "").replace("'", "");
					//to rotate the string "180 degress",  we need to reverse it, then "mirror" it, which we will do
					//by swapping all "mirrorable" characters: e=>a, a=>e, b=>q, q=>b, etc.
					
					//Reverse the string:
					//(If a library function doesn't exist to do this, simply create 2 arrays
					//with the same size, the first containing each character of the string to reverse, then
					//iterate through the original, and output each character to array.size()-counter (counting in reverse)
					//so that you put the characters into the second array, starting at the end of the second array.
					//
					//Note: It is stuff like this that prompted the creation of additional languages after C ^_-)
					StringBuilder sb=new StringBuilder(line);
					sb.reverse();
					String reversed = sb.toString();
					
					//Flip/mirror the string:
					String transformed = "";
					List<String> chars =Arrays.asList(reversed.split("|"));
					for(String c:chars){
						//Have to account for each possibility, and have to do them individually like this
						//if you try to do this on a string level, you are either going to flip, and then
						//upflip the characters, or only flip half of the characters that should be flipped
						//depending on how you do it. Doing it on the character level ensures each character
						//is changed as per the algorithm
						if (c.equals("e")){c="a";}
						else if(c.equals("a")){c="e";}

						if (c.equals("b")){c="q";}
						else if(c.equals("q")){c="b";}

						if (c.equals("p")){c="d";}
						else if(c.equals("d")){c="p";}

						if (c.equals("h")){c="y";}
						else if(c.equals("y")){c="h";}

						if (c.equals("m")){c="w";}
						else if(c.equals("w")){c="m";}

						if (c.equals("n")){c="u";}
						else if(c.equals("u")){c="n";}
						transformed +=c;
					}

					System.out.print(line+" ");
					String originalNoSpaces = line.replace(" ", "");
					String transformedNoSpaces = transformed.replace(" ", "");
					if (originalNoSpaces.equals(transformedNoSpaces)){
						System.out.print("(is) ");
					}
					else{
						System.out.print("(not) ");
					}
					System.out.println(transformed);
				}
				lineNum++;
			}
		} 
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

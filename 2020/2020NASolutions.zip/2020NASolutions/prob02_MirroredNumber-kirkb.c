#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(argc,argv) int argc; char **argv; {
char buf[1024];
int i;
while(fgets(buf,1024,stdin)) {
 for(i=strlen(buf)-1;i>=0;i--)
  putchar(buf[i]);
 printf("\n");
 }
exit(0);
}

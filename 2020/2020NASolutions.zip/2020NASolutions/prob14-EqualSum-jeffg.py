#!/usr/bin/python3
# Equal Sum
# Solution author: jeffg, 2020
import sys

def checkEqualSum(n):
    net_sum = 0
    sign = 1
    while n > 0:
        net_sum += sign * int(n % 10)
        n = n // 10
        sign = -sign
    return net_sum == 0

def checkRange(start, end):
    found = False
    # find the first number divisible by 11 in this range
    for i in range(start, end):
        if i % 11 == 0:
            start = i
            break
    # check every divisible-by-11 number for satisfying problem criteria
    for i in range(start, end, 11):
        if checkEqualSum(i):
            print(i, end=" ")
            found = True
    return found

if __name__ == "__main__":
    start, end = map(int, sys.stdin.readlines())
    found = checkRange(start, end)
    if not found:
        print("No Numbers found with Equal Sum in the given range!!")

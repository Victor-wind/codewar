import java.util.Scanner;//required for I/O from stdin
import java.util.TreeMap;//required to store the items in a hashmap
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required for Array parsing of List generics
import java.util.Comparator;//required to sort the prices List
import java.util.List;//required for List generics
import java.util.Map;//required for hashmap lookups
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Do I Have Enough?
 * DIFFICULTY LEVEL: Very Easy
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 8 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 10-12 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2020-02-24
 * WHAT IT TESTS: 
 * 	1.) Ability to keep track of a number which is being operated on in a loop
 * 	2.) Ability to keep track of data items which will be affected by the loop
 * 	3.) Ability to evaluate if the loop has produced desired results
 * 	4.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# Do I Have Enough?

Great news! You get to go to Japan on a class trip! Bad news, you don't know how to use the Yen which is the name of the Japanese cash system. 
Japan uses coins for cash a lot more than the United States does. Yen comes in coins for values of: 1, 2, 10, 50, 100, & 500
To practice your Yen skills, you have selected random items from Amazon.co.jp and put them into a list along with their prices in Yen. 
You now want to create a program to check your Yen math.

Your goal is to maximize your buying power to buy AS MANY items as you can with your available Yen.

## Input
You will receive a datset file listing 2 to 6 items in the format of:

  	ITEM YYYYY
 
Where:

  	ITEM = the name of the item you want to buy
  	YYYYY = the price of the item (in Yen)

The very first line of the dataset file will be the amount of Yen you have in your "pocket," and a space followed by the number of items in the list. Full example dataset file:

### Example: Affordable

  	6000 3
  	Phone-case 1486
  	Candybar 863
  	Sunglasses 5529

### Example: Unaffordable

  	2100 3
  	Camera 69555
  	TV 76439
  	iPhone 90000

## Output
List the items you can afford to buy. Each item on its own line. Your goal is to buy as many items as possible. If you can only afford the 
one expensive item, or 2 less expensive items on a list, but not all three, then list the less expensive items as affordable. 
If you cannot afford anything in the list, output "I need more Yen!" after the items. The final line you output should be the remaining Yen you will have left over after you make your purchases.

### Output: Affordable
	I can afford Phone-case
	I can afford Canybar
	I can't afford Sunglasses
	3651
  
### Output: Unaffordable
	I can't afford Camera
	I can't afford TV
	I can't afford iPhone
	I need more Yen!
	2100

 * 	
 * */
public class prob13 {
	private static final String DEBUG_PROB_ID = "probAU";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Same input as in the problem (second example)
	 * 3.) Simple test, have JUST enough money for all of the items
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Testing only being able to afford one item
	 * 2.) Testing not being able to afford anything
	 * 3.) Testing being able to afford all of the items
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * This is a simple number comparison problem with a sorting element and a directive for 
	 * "greedy" grouping (prefer to take more than less according to the algorithm logic).
	 * The only main sticking points will be the multiple conditions on exit points for the
	 * output and keeping track of the data. Japanese Yen was just thrown in as a means of
	 * confusion :D The same thing could have been done with nickles dimes and quarters with
	 * prices given in dollars -- but that's no fun ;)
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-student-2-in.txt").toPath());
		int wallet = 0;
		int counter = 0;
		Map<Integer,String> items = new TreeMap<Integer,String>();
		List<Integer> prices = new ArrayList<Integer>();
		for(String line:lines){
			if (counter==0){
				List<String> firstLine = Arrays.asList(line.trim().split(" "));
				if (firstLine.size() > 1)
				{
					wallet = Integer.parseInt(firstLine.get(0));
				}
			}
			else{
				List<String> parts = Arrays.asList(line.trim().split(" "));
				if (parts.size() > 1){
					int price = Integer.parseInt(parts.get(1));
					items.put(price,parts.get(0));
					prices.add(price);
				}
			}
			counter++;
		}
		prices.sort(Comparator.naturalOrder());
		int bought = 0;
		for(Integer price: prices){
			if (price <= wallet){
				System.out.println("I can afford "+items.get(price));
				wallet -= price;
				bought++;
			}
			else{
				System.out.println("I can't afford "+items.get(price));
			}
		}
		if (bought < 1){
			System.out.println("I need more Yen!");
		}
		System.out.println(""+wallet);
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

import java.util.Scanner;//required for I/O from stdin
import java.util.TreeMap;
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required to parse split from array into List
import java.util.List;//required for List generics
import java.util.Map;
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
/**
 * PROBLEM: Series Identifier
 * DIFFICULTY LEVEL: Difficult
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 32 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 35-40 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-27
 * WHAT IT TESTS: 
 * 	1.) Ability to setup a test for a set of numbers to determine if that set of numbers came from a Geometric, Exponential or Fibonacci series (requires understanding the rules for said series)
 * 	2.) Ability to work with negative, positive, increasing and decreasing numbers 
 * 	3.) Ability to setup a logical construct (if then else) which will output the correct determination based on the tests for the logic of the problem
 *  4.) Ability to "catch" a problem data line and handle it gracefully as an error message
 * 	5.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# Series Identifier
## (20 pts.)

What type of series are you looking at? Geometric? Exponential? TV? Who knows? That's the question your program needs to solve.

## Geometric Series
A series is geometric if the items in the series set are increasing (or decreasing) at the same rate. For instance, a geometric series which multiplies every term by 10 would be: 1 10 100 1000, etc. 
NOTE: you may encounter items from a geometric series which contains gaps! In those cases you will need to "fill in the gaps" to test if it is a valid geometric series or not. If you find a geometric series with gaps in it, add "(With Gaps)" to your output.

## Exponential
A series is exponential if the next item in the series set is a result of raising the prior item to a set power. For instance, X^2 exponential series raises each term to the power of 2, example: 2 4 16 32, etc. (Note, your program will only need to identify X^2 and X^3 exponential series)

## Fibonacci
A series is a Fibonacci series if the next term in the series set is a result of adding the prior two terms together (with term 0 not really factoring in except as a seed to start the series). For example: 1 1 2 3 5, etc.

### Input

You will receive a dataset with 1-5 lines consisting of numbers in a series. Numbers can be negative, and they can either increase or decrease, depending on their series. You will not receive any fraction or decimal numbers, and you are guaranteed to receive at least one data line.

    4 40 400 4000
    8 64 4096 16777216
    -3 -27 -19683 -7625597484987
    5 8 13 21
    300000 3000 300 3
    8 3 82 17 9

    (Note, you may encounter items from a series which are not contiguous (as in the second Geometric series above in the sample input). In those cases you will need to "fill in the gaps" to determine what series you are dealing with)

### Output

For each line, simply name the series the line is using for its number progression. (For exponential, either output X^2 or X^3 depending on the exponent you have determined the series is using). If you CANNOT determine the series the line represents, output the line + "is an Unknown series"

    Geometric
    X^2
    X^3
    Fibonacci
    Geometric (With Gaps)
    8 3 82 17 9 is an Unknown series

 * 	
 * */
public class prob28 {
	private static final String DEBUG_PROB_ID = "probAI";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Same input as in the problem
	 * 2.) Tests for Geometric, X-squared, and Fibonacci series
	 * 3.) Tests for X-cubed, Geometric (with gaps), and unknown series
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Tests for Fibonacci, Geometric, and X-squared series
	 * 2.) Tests for X-cubed, Geometric and unknown series, and Geometric series with gaps
	 * 3.) Tests for Fibonacci, X-squared series, and Geometric series, also with gaps
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * This problem is easy to understand, but slightly time-consuming to implement. It's easy to
	 * say "test to see if a set of numbers could be part of mathematical series X" -- it isn't
	 * so easy to actually programmatically test for that. Some mathematical series also test
	 * easier than others.
	 * 
	 * I was able to code a test for Fibonacci in 7 lines of code, & 9 for Geometric. But it took
	 * 13 lines of code to test for exponential. Part of that was because the test allows for
	 * any base and power, instead of testing for a specific exponential operation, but writing
	 * (and testing) the coding for those tests still takes time, hence the higher time cost for
	 * attempting this problem, and hence the higher difficulty.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run() throws IOException {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = Files.readAllLines(new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt").toPath());
		for(String line:lines){
			List<String> parts = Arrays.asList(line.trim().split(" "));
			List<Long> numbers = new ArrayList<Long>();
			for(String n:parts){
				numbers.add(Long.parseLong(n));
			}
			boolean found = false;
			if (isExponential(numbers, 2)){
				System.out.println("X^2");
				found = true;
			}
			else if (isExponential(numbers, 3)){
				System.out.println("X^3");
				found = true;
			}
			else if (isFibonacci(numbers)){
				System.out.println("Fibonacci");
				found = true;
			}
			//splitting logic out like this to avoid running the calculations more than once
			//"correct" way to do this would be to pass back an object of a class that can send back more than
			//once piece information -- but that takes more time ^_-
			if (!found){
				int testGeo = isGeometric(numbers);
				if (testGeo == 1){
					System.out.println("Geometric");
					found = true;
				}
				if (testGeo == 2){
					System.out.println("Geometric (With Gaps)");
					found = true;
				}
			}
			if(!found){
				System.out.println(line+" is an Unknown series");
			}
		}
	}
	/**
	 * Tests a set of numbers (passed in as a list) to determine if the
	 * numbers are being raised to the n power in sequence.
	 * */
	private static boolean isExponential(List<Long> numbers, double n){
		boolean result = true;
		List<Long> calcs = new ArrayList<Long>();
		calcs.add(numbers.get(0));
		for (int i =0; i <(numbers.size()-1); i++){
			calcs.add((long)Math.pow(numbers.get(i),n));
		}
		for (int i =0; i <calcs.size(); i++){
			if (i < numbers.size()){
				if (!numbers.get(i).equals(calcs.get(i))){
					result = false;
					break;
				}
			}
		}
		return result;
	}
	/**
	 * Tests a set of numbers (passed in as a list) to determine if the
	 * numbers are in sequence are a result of adding the prior 2 numbers
	 * together.
	 * */
	private static boolean isFibonacci(List<Long> numbers){
		boolean result = false;
		if (numbers.size() >= 4){
			long third = numbers.get(2);
			long fourth = numbers.get(3);
			if ((third == numbers.get(0) + numbers.get(1)) && (fourth == numbers.get(1) + numbers.get(2))){
				result = true;
			}
		}
		return result;
	}
	/**
	 * Tests a set of numbers (passed in as a list) to determine if the
	 * numbers in sequence are a result of multiplying by the same ratio
	 * repeatedly
	 * */
	private static int isGeometric(List<Long> numbers){
		int result = 0;//0 == false, 1== true, 2 == true with gaps
		boolean isGeo = true;
		List<Double> ratios = new ArrayList<Double>();
		if (numbers.size() >= 4){
			for (int i=(numbers.size()-1); i>0; i--){
				ratios.add((double)numbers.get(i)/(double)numbers.get(i-1));
			}
			for (int j=0; j<(ratios.size()-1); j++){
				isGeo = (isGeo && (ratios.get(j).equals(ratios.get(j+1))));
			}
			if (isGeo){
				result = 1;//using integer so we can simply send back yes/no/yes-with-gap signal
			}
			if (!isGeo){
				//determine lowest/highest set terms
				long lowest = Long.MAX_VALUE;
				long highest = Long.MIN_VALUE;
				for (int i=0; i<=(numbers.size()-1); i++){
					if (numbers.get(i) < lowest){
						lowest =numbers.get(i); 
					}
					if (numbers.get(i) > highest){
						highest =numbers.get(i); 
					}
				}
				//count the ratio frequency
				Map<Double,Integer> ratioCounts = new TreeMap<Double,Integer>();
				for(Double ratio:ratios){
					if (ratioCounts.containsKey(ratio)){
						ratioCounts.replace(ratio, ratioCounts.get(ratio)+1);
					}
					else{
						ratioCounts.put(ratio,1);
					}
				}
				//determine the most common ratio
				double mostCommonRatio = Double.MIN_VALUE;
				int ratioFrequency = Integer.MIN_VALUE;
				for(Map.Entry<Double,Integer> ratio : ratioCounts.entrySet()) {
					if (ratio.getValue() > ratioFrequency){
						mostCommonRatio = ratio.getKey();
						ratioFrequency = ratio.getValue();
					}
				}
				if (mostCommonRatio != 1){
					//if the ratio is 1, skip it, it isn't geometric
					//apply the most frequent ratio to the lowest-> highest terms and create a
					//new set, and see if the new set contains all of the terms from the given set
					List<Long> newSet = new ArrayList<Long>();
					if (mostCommonRatio < 1){
						//apply ratio from highest to lowest
						long calc = highest;
						while (calc >= lowest){
							newSet.add(calc);
							calc *= mostCommonRatio;
						}
					}
					else{
						//apply ratio from lowest to highest
						long calc = lowest;
						while (calc <= highest){
							newSet.add(calc);
							calc *= mostCommonRatio;
						}
					}
					//if the new set contains ALL of the numbers from the given set, then we found a geometric set with a gap!
					if (newSet.containsAll(numbers)){
						result = 2;
					}
				}
			}
		}
		return result;
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LEN 1024

int main(argc,argv) int argc; char **argv; {
char buf[LEN];
char word[LEN];
char *s;
int r;
int w;
int l;
int f;
while(fgets(buf,LEN-1,stdin)) {
 for(f=w=0,s=buf;;s+=r) {
  if(sscanf(s,"%s%n",word,&r)>0)   {
     l=strlen(word);
     if((w+l+1)<=80) {
      printf("%s%s",w?" ":"",word);
      w+=l+(w>0);
      f=1;
      }
     else {
      printf("\n%s",word);
      w=l;
      f=1;
      }
      }
  else {
   if(f) printf("\n");
   break;
   }
}
}
  printf("\n");
}

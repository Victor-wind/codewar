#include <stdio.h>
#include <stdlib.h>
#define MAX 26
#define BUF 1024

char name[MAX];
int adj[MAX][MAX];
int visited[MAX];

int connected(a,b,h) int a,b; char *h; {
int i;
int f=0;
char hist[BUF];

if(a==b) return 0;

if(adj[a][b]) {
// printf("route: %s %c\n",h,b+'A');
 return 1;
}

visited[a]=1;
for(i=0;i<MAX;i++) {
 if(a==i) continue;
 if(adj[a][i]&&!visited[i]) {
  visited[i]=1;
  sprintf(hist,"%s %c",h,i+'A');
  f=f||connected(i,b,hist);
  visited[i]=0;
  }
}
visited[a]=0;
return(f);
}

int main(argc,argv) int argc; char **argv; {
int i,j,k;
int cities;
int c;
char a,b;
char buf[BUF];
char mode[BUF];
char ignore[BUF];
for(i=0;i<MAX;i++)
 for(j=0;j<MAX;j++)
  visited[i]=adj[i][j]=0;
scanf("%d",&cities);
for(i=0;i<cities;i++) {
 scanf("%s",buf); name[i]=buf[0];
 }
while(fgets(buf,BUF-1,stdin)) {
 if((buf[0]=='\r')||(buf[0]=='\n')) continue;
 sscanf(buf,"%s %c %s %s %s %s %c %s %s",ignore,&a,ignore,ignore,ignore,ignore,&b,ignore,mode);
 if(mode[0]!='a')
 {
//  printf("connecing %c %c via %s\n",a,b,mode);
  adj[a-'A'][b-'A']++;
  adj[b-'A'][a-'A']++;
 }
// else
//  printf("%s connection between %c %c, not marking adj\n",mode,a,b);
}

for(i=0;i<cities;i++) {
 for(c=j=0;j<cities;j++) {
//  c+=(adj[name[i]-'A'][name[j]-'A']>0);
  sprintf(buf,"%c",name[i]);
  c+=connected(name[i]-'A',name[j]-'A',buf);
 }
 if(c) {
  printf("City %c is neighbor to Cities ",name[i]);
  for(k=j=0;j<cities;j++)
//   if(adj[name[i]-'A'][name[j]-'A'])
   if(connected(name[i]-'A',name[j]-'A',buf))
    printf("%c%s",name[j],(k++==(c-1))?"\n":",");
 } else
  printf("City %c is remote and has no neighbors!\n",name[i]);
  }

exit(0);
}

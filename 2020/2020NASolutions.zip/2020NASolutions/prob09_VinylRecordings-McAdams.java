import java.io.FileNotFoundException;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.io.File;//required for I/O from file
/**
 * PROBLEM: Vinyl Recordings
 * DIFFICULTY LEVEL: Very Easy
 * TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 8 minutes
 * ESTIMATED STUDENT COMPLETION TIME NEEDED: 10-15 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
 * LAST MODIFIED: 2019-11-27
 * WHAT IT TESTS: 
 * 	1.) Ability to carry about basic math operations (subtraction and addition)
 * 	2.) Ability to convert units on mathematical units
 * 	3.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
# Vinyl Records
## (5 pts)

With vinyl records making a comeback, industry executives need to hire a programmer to tell their factory machines when to flip the record, as all of their original equipment was destroyed during the rise of the CD. Help your company turn the tables on the industry!

### Input

The factory machine will receive a single data line composed of two integers. The first integer is the total number of minutes for the recording. The second integer is the total number of seconds. You are guaranteed to only get one line of data per file, and that line is guaranteed to always have two, and only two, integers on it. When you reach the line with double zeros on it, stop reading more inputs.

    EXAMPLES:

    17 5
    26 33
    51 1
    0 0

### Output

The vinyl records your company presses can hold 25 minutes of audio on one side. Output to the data operator's screen the remaining time on the record as follows:

    Time remaining 32 minutes and 55 seconds
    Time remaining 23 minutes and 27 seconds (we'll need both sides)
    Time remaining -1 minutes and -1 seconds (we're gonna need a bigger record)

If the recording will exceed the amount of time one side can contain, add " (we'll need both sides)" to the output for the operator to see.
However, if the recording will exceed the total amount of time an entire record can contain, add "(we're gonna need a bigger record)" to the output instead.

 * 	
 * */
public class prob09 {
	private static final String DEBUG_PROB_ID = "probAD";//global constant used with debugging
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";//global constant used with debugging
	private static final int totalTimeAvailable = 3000;//global constant, 50 minutes (25/side) * 60 seconds/minute
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) tests condition: overflow (1 minute and 1 second too long)
	 * 2.) tests condition: ALMOST too big input, +2 more seconds and would overflow
	 * 3.) tests condition: very tiny input, smallest possible value
	 * 4.) tests condition: exact fit
	 * 5.) tests condition: overflow by 1 second (won't fit on a record at all)
	 * 6.) tests condition: HUGE time cost, won't fit on a record at all
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Testing condition where only one side of the record is needed
	 * 2.) Testing overflow condition (only 25 minutes available per side, will be 1 minute and 59 seconds short of space)
	 * 3.) Testing both sides condition (will use up first 25 minutes on one side, and need to use part of next side)
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * This is a simple subtraction problem with a caveat for the programmer to handle an 'error
	 * state' gracefully, if needed. And to also mark specific conditions which have been met
	 * to make it slightly more challenging. I wouldn't expect even beginning students to have
	 * much trouble with it.
	 * 
	 * I chose to solve this one in a manner as similar a possible to the toolset a beginning 
	 * student might be familiar with. Only arrays and the scanner class, along with simple 
	 * loops and calculations are used. No additional classes, methods or complicated data 
	 * structures are used. This was done to show beginning students that the fancier stuff
	 * available to a programmer are time-savers, but they don't magically make solving the
	 * problem any "easier" ^_-
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run(false);
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results. If the problem to solve is small enough, no additional
	 * functions or methods are called
	 * */
	private static void run(boolean debugging) throws FileNotFoundException{
		//PARSE THE DATA IN
		//production
		//List<String> lines = readFromFileInputByCommandLine();
		//debugging
		Scanner scan=null;
		if (debugging){
			File file=new File(DEBUG_PATH+"\\"+DEBUG_PROB_ID+"\\"+DEBUG_PROB_ID+"-judge-3-in.txt");
			scan=new Scanner(file);
		}
		else{
			//will NOT work on the command line (unless the student knows to terminate the input with CTRL+C)
			//expecting to pipe in a file path
			scan=new Scanner(System.in);
		}
		int[] times = new int[2];
		int counter = 0;
		while (scan.hasNext() && counter < 2){
			times[counter] = scan.nextInt();
			counter++;
		}
		scan.close();
		int timeNeeded = (times[0] * 60) + times[1];
		int timeRemaining = (totalTimeAvailable - timeNeeded);
		//have to account for negative numbers.
		//yes, this can be done by taking absolute value and then re-applying negative after calculations are done,
		//I chose not to do that though, as beginning students may not know about the Math.abs function
		int seconds = timeRemaining;
		int mins = 0;
		if (seconds < 0){
			while (seconds <= -60){
				mins--;
				seconds +=60;
			}
		}
		else{
			while (seconds >= 60){
				mins++;
				seconds -=60;
			}
		}
		System.out.print("Time remaining "+mins +" minutes and "+seconds + " seconds");
		if (timeRemaining <0){
			System.out.print(" (we're gonna need a bigger record)");
		}
		else if (timeNeeded > 1500){
			//1500 == 25 minutes available on one side * 60 seconds
			System.out.print(" (we'll need both sides)");
		}
	}
}

import sys
#PROBLEM: Mirrored Number
#DIFFICULTY LEVEL: Easy
#TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 2 minutes
#ESTIMATED STUDENT COMPLETION TIME NEEDED: < 5 minutes
#PROBLEM AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
#LAST MODIFIED: 2020-01-22
#WHAT IT TESTS: 
#	1.) Ability to recognize a string vs. number problem
#	2.) Ability to reverse/invert a string
#	3.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
# 
#PROBLEM DESCRIPTION: 
# 
# # Mirrored Number
# ## (2 pts.)
# You are working on special effects for a movie, and the director wants to see a scene where numbers on a screen are reflected in a mirror. Your task is to program a function that will "mirror" a number.
# Given an integer, such as 1234, reverse the number to 4321 so it is the mirror reflection of itself.
# ### Input
#     7946
# ### Output
#     6497
#
debugging = False
problemID = "BG"
#SOLUTION:
#----------------------------------------------------------------------------------------
#STUDENT DATA:
#----------------------------------------------------------------------------------------
#1.) Data from problem example, simple case
#2.) Large "number" to reverse, will overflow a standard 32-bit integer if try to treat it as an int-32 (need to treat it as a string)
#3.) Large "number" to reverse, will overflow even a 64-bit integer if try to treat it as an int-64 (need to treat it as a string)
#not final, may change this in contest datasets
#----------------------------------------------------------------------------------------
#JUDGE DATA:
#----------------------------------------------------------------------------------------
#1.) Simple case number to reverse/mirror (won't overflow anything)
#2.) Simple case number to reverse/mirror (won't overflow anything)
#3.) Simple case number to reverse/mirror (won't overflow anything)
#----------------------------------------------------------------------------------------
#NOTES:
#
#This is intended as a problem of beginner difficulty. It is a string manipulation problem
# masquerading as a math problem. The solution is actually rather straight forward, simply
# treat the number as a string, and then reverse/invert it. Almost every language has an
# easy way to do that. Even those which don't still have substring functions to do it
# manually, and/or arrays which can take a string of characters and then be walked through
# backwards to get the reversed string.
#
#The solution provided only uses libraries found in the standard Python installation,
#no external modules or 3rd party libraries are used.
#*/
#----------------------------------------------------------------------------------------
try:
    #------------------------------------------------------------------------------------
    # FUNCTION: mirrorNumber
    # PURPOSE: take a number, treat it as a string, and reverse it
    # INPUT PARAMETER: n (string/number): the input value (can be passed in as a number or string)
    # PRECONDITIONS: none
    # POSTCONDITIONS: returns the input value as a string, with the characters in the string reversed
    # AUTHOR: Robert McAdams, mcadams@hpe.com
    # LAST MODIFIED: 2020-01-22
    def mirrorNumber(n):
        number = str(n)#treat the number as a string (or a string as a string)
        mirrored = number[::-1] #uses Python's built-in substring function's (which Python calls 'slicing') "step" parameter to walk backwards through the string
        return mirrored
    #------------------------------------------------------------------------------------
    # FUNCTION: main
    # PURPOSE: main program, gets the data and runs the operations
    # PRECONDITIONS: none
    # POSTCONDITIONS: program has executed
    # AUTHOR: Robert McAdams, mcadams@hpe.com
    # LAST MODIFIED: 2020-01-22
    def main():
    	#--------------------------------------------------------------------------------
		#LOAD THE DATA
        lines = []
        if (debugging):
            #r"" instructs the linter to treat the string as a literal, and not to parse it
            f = open(r"data\prob"+problemID+"-judge-3-in.txt", "r")
            for line in f:
                lines.append(line.rstrip().strip())
        else:
            for line in sys.stdin:
                lines.append(line.rstrip().strip())
		#--------------------------------------------------------------------------------
        if (len(lines) >= 1):
            print(mirrorNumber(lines[0].strip()))
        else:
            print('error, data missing')
	#------------------------------------------------------------------------------------
    main()
except:
	e = sys.exc_info()[0]
	print("bad things happened: "+str(e))

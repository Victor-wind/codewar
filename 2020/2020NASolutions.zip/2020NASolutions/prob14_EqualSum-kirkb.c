#include <stdio.h>
#include <stdlib.h>
int N1,N2;

int eq(n) int n; {
int e,o;
int i;

if(n<10) return 0;

for(i=e=o=0;n;i++,n/=10)
 if(i%2)
  o+=n%10;
 else
  e+=n%10;
return e==o;
}

int main(argc,argv) int argc; char **argv; {
int i;
int count=0;

scanf("%d",&N1);
scanf("%d",&N2);
for(i=N1;i<N2;i++)
 if(eq(i)) {
  printf("%d ",i);
  count++;
  }
printf("%s\n",count?"":"No Numbers found with Equal Sum in the given range!!");
exit(0);
}

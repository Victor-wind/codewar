#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define BUF 32

int main(argc,argv) int argc; char **argv; {
int H,M;
double h,m;
double d;
char buf[32];
while(scanf("%d:%d",&H,&M)!=EOF) {
 if(H>=12) H-=12;
 h = (H * 30.0 + M * 0.5);
 m = M * 6.0;
 
 d=(h>m)?(h-m):(m-h);
 d=(d>=360.0)?(d-360.0):d;
 d=(d>180.0)?(360.0-d):d;

 printf("The angle between the Hour hand and Minute hand is %.2lf degrees.\n",d);
 }
exit(0);
}

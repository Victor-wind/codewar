#include <stdio.h>
#include <stdlib.h>

int main(argc,argv) int argc; char **argv; {
printf("Mr. Watson, come here!\n");
exit(0);
}

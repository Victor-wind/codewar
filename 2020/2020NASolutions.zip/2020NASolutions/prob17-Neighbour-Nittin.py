import sys

def dfs(city):
    visited = []
    dfs_q = []
    dfs_q.append(city)
    while(dfs_q):
        c = dfs_q.pop(0)
        if c not in visited:
            visited.append(c)
            for city in a_grph[c]:
                if city not in visited:
                    dfs_q.append(city)
    return visited



lines = sys.stdin.readlines()
num_cities = (int)(lines[0].strip())
a_grph = {}
cities = []
for index, line in enumerate(lines):
    line = line.strip()
    if (index == 0) :
        continue
    elif(index <=num_cities):
        cities.append(line)
        if (line not in a_grph.keys()):
            a_grph[line] = []
    else:
        city_src = line.split()[1]
        city_dst = line.split()[6]
        method = line.split()[-1]
        if (method != 'air'):
                a_grph[city_src].append(city_dst)
                a_grph[city_dst].append(city_src)
neighbours = {}
for city in cities:
    neighbours[city] = []

for city in cities:
    neighbours[city] = dfs(city)
    neighbours[city].remove(city)
    if len(neighbours[city])> 0:
        neigh_list =[]
        for c in cities:
            if c in neighbours[city]:
                neigh_list.append(c)
        c_str = ",".join(c for c in neigh_list)
        print("City {} is neighbour to Cities {}".format(city, c_str))
    else:
        print("City {} is remote and has no neighbours!".format(city))

#include <stdio.h>
#include <stdlib.h>
int main(argc,argv) int argc; char **argv; {
int X,Y;
int i;

scanf("%d",&X);
scanf("%d",&Y);
for(i=1;i<=X*Y;i++)
 if(!(i%X) && !(i%Y)) {
  printf("%d\n",i);
  exit(0);
  }
}
  

# Pizza Toppings
# 
# 0 Pepperoni: 32 pieces for a whole pizza
# 1 Red Peppers: 16 pieces for a whole pizza
# 2 Pineapple: 84 pieces for a whole pizza
# 3 Olives: 20 pieces for a whole pizza
# 4 Sardines: 12 pieces for a whole pizza
# 5 Onion: 28 pieces for a whole pizza
# 6 Sausage: 40 pieces for a whole pizza
# 7 Ham: 36 pieces for a whole pizza
# Additionally, several named 'types' of pizzas can also be ordered. Any toppings listed for named 'type' of pizza will use the full count as listed above:
# Hawaiian: pineapple & ham
# Combo: red peppers & olives & onion & sausage
# Fishaster: sardines & onion
# Meat-Lovers: pepperoni & sausage & ham
# Cheese: no toppings


import sys

debugPrint = False


toppings = [(0) for x in range(11)]  # Initialize Topping count


def countToppings(c, d, t):
    global toppings
    if debugPrint:
        print("Counting ",c," of 1/",d," of ",t,sep='')
    # Split up special pizzas
    if t=="Hawaiian":
        countToppings(c, d, "Pineapple")
        countToppings(c, d, "Ham")
        return
    elif t=="Combo":
        countToppings(c, d, "Peppers")
        countToppings(c, d, "Olives")
        countToppings(c, d, "Onion")
        countToppings(c, d, "Sausage")
        return
    elif t=="Fishaster":
        countToppings(c, d, "Sardines")
        countToppings(c, d, "Onion")
        return
    elif t=="Meat-Lovers":
        countToppings(c, d, "Pepperoni")
        countToppings(c, d, "Sausage")
        countToppings(c, d, "Ham")
        return
    # Single Toppings
    elif t=="Pepperoni":
        i = 0
        top = 32; # 32 Pepperoni
    elif t=="Peppers":
        i = 1
        top = 16; # 16 Peppers
    elif t=="Pineapple":
        i = 2
        top = 84; # 84 Pineapple
    elif t=="Olives":
        i = 3
        top = 20; # 20 Olives
    elif t=="Sardines":
        i = 4
        top = 12; # 12 Sardines
    elif t=="Onion":
        i = 5
        top = 28; # 28 Onion
    elif t=="Sausage":
        i = 6
        top = 40; # 40 Sausage
    elif t=="Ham":
        i = 7
        top = 36; # 36 Ham 
    else:
        i=8
        top=4444
    top = int(top * c / d) # Force to integer
    if debugPrint:
        print("Adding ",top," of ",t,sep='')
    toppings[i] = toppings[i] + top 

    return

#------------------------------------------------------------------------
# Main program starts here.

line = sys.stdin.readline().rstrip('\n').rstrip(' ')
while (line):
    words = line.split(' ')
    pizzaCount = int(words[0])
    wc = len(words)
    i = 1
    while i<wc:
        # Get Data for pizza section
        if words[i][0] == '&':
            i=i+1
            divisor=1
            continue
        if words[i][0] == '1':  #Do we have a fraction?
            divisor = int(words[i][2])
            i = i+1
        else:
            divisor = 1
        if words[i][0] == 'R':  # Skip "Red" to get to "Peppers"
            i=i+1
        pizzaType = words[i]
        countToppings(pizzaCount, divisor, pizzaType)
        i=i+1
    line = sys.stdin.readline().rstrip('\n').rstrip(' ')

# Now print the final counts
print("Pepperoni: ",   toppings[0],sep='')
print("Red Peppers: ", toppings[1],sep='')
print("Pineapple: ",   toppings[2],sep='')
print("Olives: ",      toppings[3],sep='')
print("Sardines: ",    toppings[4],sep='')
print("Onion: ",       toppings[5],sep='')
print("Sausage: ",     toppings[6],sep='')
print("Ham: ",         toppings[7],sep='')

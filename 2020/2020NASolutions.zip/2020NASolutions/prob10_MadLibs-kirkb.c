#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LEN 1024
#define MAXWORDS 32

#define TOKENS 4
char *tokens[TOKENS] = { "[N]","[AV]","[V]", "[AJ]" };
int tl[TOKENS] = { 3,4,3,4 };

#define CMDS 5
char *cmds[CMDS] = { "NOUNS","ADVERBS","VERBS","ADJECTIVES","END" };
int cl[CMDS]= {5,7,4,10,3};

char *lists[CMDS][MAXWORDS];
int ll[CMDS] = {0,0,0,0,0};
int nl[CMDS] = {0,0,0,0,0};

char target[LEN];

int cmd(c) char *c; {
int i;
for(i=0;i<CMDS;i++)
 if(strncmp(c,cmds[i],cl[i])==0) return i;
return CMDS;
}

int token(c) char *c; {
int i;
for(i=0;i<TOKENS;i++)
 if(strncmp(c,tokens[i],tl[i])==0) 
  return i;
return TOKENS;
}


int main(argc,argv) int argc; char **argv; {
char buf[LEN];
int i,j,l,t;

fgets(target,LEN-1,stdin);
//printf("Target: %s\n",target);
l=0;
while(fgets(buf,LEN-1,stdin)>0) {
if((t=cmd(buf))==CMDS) {
 for(i=0;buf[i];i++) 
  if((buf[i]=='\n')||(buf[i]=='\r')) buf[i]='\0';
 lists[l][ll[l]++]=strdup(buf);
 }
else
 l=t;
}
/*
for(i=0;i<CMDS-1;i++) {
 printf("%s[%d]:",cmds[i],ll[i]);
 for(j=0;j<ll[i];j++)
  printf(" %s",lists[i][j]);
 printf("\n");
}
*/
for(l=0;l<2;l++) 
for(i=0;target[i];i++)
 if(target[i]!='[')
  putchar(target[i]);
 else
  if((j=token(target+i))==TOKENS)
   putchar(target[i]);
  else {
   printf("%s",lists[j][(nl[j]++)%ll[j]]);
   i+=tl[j]-1;
   }

}
 

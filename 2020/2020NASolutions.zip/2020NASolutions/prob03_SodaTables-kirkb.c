#include <stdio.h>
#include <stdlib.h>

int GCD(x,y)
int x,y;

{
 int a,b;
 int t;
 a=(x>y)?x:y;
 b=(x>y)?y:x;

 while(b>0LL) {
  t=b;
  b=a%b;
  a=t;
  }
  return(a);
}

int main(argc,argv) int argc; char **argv;{
int X,Y;
scanf("%d",&X);
scanf("%d",&Y);
printf("%d\n",GCD(X,Y));

}


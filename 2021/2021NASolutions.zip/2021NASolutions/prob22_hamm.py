import re, math, fractions, glob

# Convert all into the smallest conversion possible
conversion_table = {
    'wet': {
        'gallon': 768,
        'quart': 192,
        'pint': 96,
        'cup': 48, 
        'ounce': 6,
        'tablespoon': 3,
        'teaspoon': 1
    },
    'dry': {
        'cup': 48,
        'tablespoon': 3,
        'teaspoon': 1,
    },
    'weight': {
        'pound': 16,
        'ounce': 1,
    }
}

measurement_list_dict = {
    'wet': ['gallon', 'quart', 'pint', 'cup', 'ounce', 'tablespoon', 'teaspoon'],
    'dry': ['cup', 'tablespoon', 'teaspoon'],
    'weight': ['pound', 'ounce']
}

datasets = [
    # '__dataset_1', 
    # '__dataset_2', 
    # '__dataset_3', 
    # '__dataset_4'
]

def main(input_val):
    '''
    calls all datasets, verifying data
    '''

    # Grab each dataset
    # i = 1
    # for dataset in datasets:
    #     input_val = eval(dataset)()

    solution_out = solution(input_val)

    # print('Solution for dataset #{}'.format(i))
    for line in solution_out:
        print(line)

    # i += 1

    # print('\n')

def solution(input_val) -> list:
    '''
    simplistic solution for solving this
    '''
    current_type = ''

    types = [
        'wet',
        'dry',
        'weight'
    ]

    # Fence Post the serving size value
    serving_size = int(re.search('\d+', input_val[0]).group(0))
    new_lines = []

    count = 0
    # Loop through the input to simulate users experience
    for line in input_val[1:]:
        count += 1
        # Check if the line is changing measurement type
        if line in types:
            current_type = line
            new_line = line

        else:

            # Parse line for value and measurements
            try:
                (value, measurement, item) = re.search(r'([\w.]+)\s+(\w+)\s+(.*)', line).groups()
            except:
                continue

            # Remove s
            # if measurement[-1:] == 's':
            #     measurement = measurement[:-1]

            # Start conversions
            # Get the table used for conversion as well as the order of the conversions
            table = conversion_table[current_type]
            measurement_list = measurement_list_dict[current_type]

            if measurement not in table:
                new_value = float(value) * serving_size
                new_measurement = measurement
            elif value == 0:
                new_value = 0
                new_measurement = measurement
            else:
                # Convert to lowest measurement possible and multiply by serving size
                smallest = float(table[measurement] * serving_size * float(value))
                new_value = 0
                new_measurement = ''

                # Go through from the highest value
                # Loop through measurement_list in order, this just removed redundent code
                for current in measurement_list:
                    if smallest >= table[current]:

                        new_value = round(float(smallest/table[current]), 2)
                        if not new_value % 1:
                            new_value = int(new_value)
                        # new_value = round(smallest/table[current], 2)
                        new_measurement = current

                        # # if new_value >= 2:
                        # #     new_measurement += 's'

                        # # leftover = int(smallest - new_value*table[current])
                        
                        # if leftover:
                        #     fraction_val = fractions.Fraction(leftover, table[current])
                        #     new_value = "{} {}".format(new_value, fraction_val)

                        break
            new_line = '{} {} {}'.format(new_value, new_measurement, item)

        new_lines.append(new_line)

    return new_lines

if __name__ == "__main__":
    print("---- JUDGE ----")  
    for file in glob.glob("*judge*in*.txt"):
        print(file)
        data_set = open(file, 'r').read().split('\n')
        print('---------')
        main(data_set)

    print("---- STUDENT ----")    
    for file in glob.glob("*student*in*.txt"):
        print(file)
        data_set = open(file, 'r').read().split('\n')
        print('---------')
        main(data_set)
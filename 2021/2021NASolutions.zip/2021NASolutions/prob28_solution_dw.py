#**********************************************************************************************************
# Donnie Wahlquist
#**********************************************************************************************************
import sys
import os


#***********************************************************
#  Elmo's Rectangle
#***********************************************************
def myMain():
    numbers = [ 0 ]

    input_file = "input.txt"

    try:
        # Read numbers file
        with open("numbers.txt", "r") as fp:                # created my own "numbers.txt", since it wasn't in the student dataset yet.
            line_no = 0
            for line in fp:
                line_no += 1
                if line_no <= 99:
                    num, numstring = line.strip().split(" ")
                    numbers.append(numstring)
                else:
                    break                                   # finished parsing all the lines we need.
            fp.close()

        # Read input file
        with open(input_file, "r") as fp:
            for line in fp:
                start_str, end_str = line.strip().split()
                start = int(start_str)
                end = int(end_str)
                break                                   # finished parsing all the lines we need.
            fp.close()

        width = ((end - start) * 2) + len(numbers[start])
        height = ((end - start) * 2) + 1
        board = [[" "] * (width+1)  for j in range(height+1)]  # create/init "board[height+1][width+1]"

        top_row = 1                                         # for the current number being processed
        bottom_row = height                     
        left_row = 1
        right_row = width
        for num in range(end, start-1, -1):                 # process rectangles from outside to inside
            max_str_ndx = len(numbers[num]) - 1
            if num == start:                                # end case: writing first number once.
                for str_ndx in range(0, max_str_ndx+1):
                    board[top_row][left_row] = numbers[num][str_ndx]
                    left_row += 1
                break                                       # Complete
            # right
            str_ndx = 0
            for col in range(left_row+1, right_row+1):
                board[top_row][col] = numbers[num][str_ndx]
                str_ndx += 1
                if str_ndx > max_str_ndx:
                    str_ndx = 0
            #down
            for row in range(top_row+1, bottom_row+1):
                board[row][col] = numbers[num][str_ndx]
                str_ndx += 1
                if str_ndx > max_str_ndx:
                    str_ndx = 0            
            #left
            for col in range(right_row-1, left_row-1, -1):
                board[bottom_row][col] = numbers[num][str_ndx]
                str_ndx += 1
                if str_ndx > max_str_ndx:
                    str_ndx = 0
            #up
            for row in range(bottom_row-1, top_row-1, -1):
                board[row][col] = numbers[num][str_ndx]
                str_ndx += 1
                if str_ndx > max_str_ndx:
                    str_ndx = 0                
            # update indexes
            top_row += 1
            bottom_row -= 1
            left_row += 1
            right_row -= 1

        # output the solution
        for b_row in board:
            print("".join(b_row[1:]))

              
    except e:
        print("\n    ## ERROR \n" + e)
        return 3
        




if __name__ == '__main__':
    ec = myMain()
    sys.exit(ec)

def main(dataset):
    
    largest_value = 0
    for line in dataset:
        curr_val = int(line)
        if curr_val > largest_value:
            largest_value = curr_val

    for line in dataset[1:]:
        curr_val = int(line)
        if curr_val == 0:
            continue
        offset = int(largest_value - curr_val/2)

        print(' ' * offset, '#' * curr_val)
        i = 1

        for i in range(1, int(curr_val/2)+1):
            print(' ' * (offset - i+1), '#', ' ' * (curr_val + (i-1)*2), '#', sep = '')
        if curr_val % 2 == 1:
            if curr_val == 1:
                print(' ' * (offset - i+1), '#', ' ' * 1, '#', sep = '')
            else:
                print(' ' * (offset - i), '#', ' ' * (curr_val + (i)*2), '#', sep = '')

        for i in reversed(range(1, int(curr_val/2)+1)):
            print(' ' * (offset - i+1), '#', ' ' * (curr_val + (i-1)*2), '#', sep = '')
        print(' ' * offset, '#' * curr_val)
        


dataset = open('probBB-judge-2-in.txt', 'r').read().splitlines()
main(dataset)
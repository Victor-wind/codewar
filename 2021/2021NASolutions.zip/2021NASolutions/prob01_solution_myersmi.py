#Easy to understand. 30 seconds - 1 minute.

import sys

if __name__ == "__main__":
    if (len(sys.argv) <= 1):
        print("No name has been given. You get no welcome")
    else:
        for name in sys.argv[1:]:
            print("{}, the needs of the many outweigh the needs of the few, or the one; live long and prosper.".format(name))
#include <stdio.h>
#define BUF 64
int main(argc,argv) int argc; char **argv;{

int convert(c) char *c; {
 return ((c[0]-'0')*10+(c[1]-'0'))*3600 + ((c[3]-'0')*10+(c[4]-'0'))*60 + 
        ((c[6]-'0')*10+(c[7]-'0'));
	}

char buf[BUF];
int start,call;
int walls=500;
int i,j;

scanf("%s",buf); start=convert(buf);
scanf("%s",buf); call=convert(buf);

walls = walls - (call-start) - 40;

printf("%.2f\n",(walls>0)?((double)walls)/100.0:0);
for(i=0;i<5;i++) {
 printf("|");
 for(j=0;j<walls/20;j++) printf(" ");
 printf("|\n");
}
printf("|");
for(j=0;j<walls/20;j++) printf(".");
 printf("|\n");
if(walls==20) printf("THIS IS SOME RESCUE!\n");
if(walls>20) printf("THE FORCE WAS WITH YOU\n");
if(walls<20) printf("CURSE MY METAL BODY, I WASN'T FAST ENOUGH!\n");
}





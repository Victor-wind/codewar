# Fairly simple. 20ish minutes. Instructions are very clear.

import sys
import math

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()

    vehicle = inputText[0]
    length = int(inputText[1])
    acceleration = float(inputText[2])
    width = float(inputText[3])

    time = math.sqrt(2 * length / acceleration)

    speed = time * acceleration

    distance = speed * speed / 9.805

    if distance < width - 5:
        result = "SPLASH!"
    elif distance > width:
        result = "LIKE A BOSS!"
    else:
        result = "BARELY MADE IT!"

    print("{} will reach a speed of {:.2f} m/s on a {} meter ramp, crossing {:.1f} of {} meters, {}".format(vehicle, speed, length, distance, width, result))
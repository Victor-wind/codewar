#include <stdio.h>
#define LEN 8
#define VAR_F 0
#define VAR_k 1
#define VAR_x 2 

int main(argc,argv) int argc; char **argv; {
char var[3][LEN];
char inp[3][LEN];
double val[3];

double F,k,x;

scanf("%s %s",var[VAR_F],inp[VAR_F]);
scanf("%s %s",var[VAR_k],inp[VAR_k]);
scanf("%s %s",var[VAR_x],inp[VAR_x]);

if(inp[VAR_F][0]=='?') {
 sscanf(inp[VAR_k],"%lf",&val[VAR_k]);
 sscanf(inp[VAR_x],"%lf",&val[VAR_x]);
 val[VAR_F]=-1.0 * val[VAR_k] * val[VAR_x];
 printf("F %.2f\n",val[VAR_F]);
}

if(inp[VAR_k][0]=='?') {
 sscanf(inp[VAR_F],"%lf",&val[VAR_F]);
 sscanf(inp[VAR_x],"%lf",&val[VAR_x]);
 val[VAR_k]=-1.0 * val[VAR_F] / val[VAR_x];
 printf("k %.2f\n",val[VAR_k]);
}

if(inp[VAR_x][0]=='?') {
 sscanf(inp[VAR_F],"%lf",&val[VAR_F]);
 sscanf(inp[VAR_k],"%lf",&val[VAR_k]);
 val[VAR_x]=-1.0 * val[VAR_F] / val[VAR_k];
 printf("x %.2f\n",val[VAR_x]);
}

}

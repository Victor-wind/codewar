def get_dataset(problem):
    #read and get input file
    with open(r'.\student_datasets\prob'+problem+'-in.txt') as fi:
        input_file=[]
        for line in fi:
            input_file.append(line.rstrip('\n'))
    
    #read output file
    with open(r'.\student_datasets\prob'+problem+'-out.txt') as fo:
        output_file=[]
        for line in fo:
            output_file.append(line.rstrip('\n'))
    
    #display example output
    print('Example output: ')
    for line in output_file:
        print(line)
    
    return input_file


for example in ['AS-1','AS-2', 'AS-3']:
    input_file=get_dataset(example)
    x=None
    y=None
    for i, line in enumerate(input_file):
        if 'P' in line:
            x= line.index('P')
            y=i
    
    print('Solution output: ')
    if x!=None and y!=None:
        print("Ace, move fast, pigeon is at ({}, {})\n".format(x,y))
    else:
        print('No pigeon, try another map, Ace\n')
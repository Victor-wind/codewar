import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAB' #prob26
# ------------------------------------------------------------------------

'''
PROBLEM: Fly, You Fools!
DIFFICULTY LEVEL: Advanced
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 76 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 80 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-16
WHAT IT TESTS: 
-Note: this problem is NOT the same as the NP-complete "traveling salesman" problem
as there is only ONE correct solution, and it IS possible to simply "walk the path"
to determine the correct route. Trying to solve this with recursive permeations of all
possible lines connecting all possible points will lead to tear, weeping, and gnashing of teeth {•̃_•̃}
    1.) Ability to think in 2-dimensions
    2.) Ability to come up with an algorithm to "walk" through a maze
    3.) Ability to keep track of "time" while "walking" through a maze
    4.) Ability to keep track of "doors", as "special" points in the maze
    5.) Ability to apply special rules to path finding with regard to time and special points/doors
    6.) Ability to backtrack a "path" when/if it dead-ends
    7.) Ability to walk through a determined route and keep track of direction changes and "steps" taken
    8.) Ability to parse several sets of data, some numeric, others string, out of a text file, and treat them as separate sets of data
    9.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 3):
        # ----------------------------------------------------------------
        #SETUP
        dimensions = lines[0].strip().split(' ')
        width = int(dimensions[0])
        height = int(dimensions[1])
        begin = Point(0,0,0,0)
        finish = Point(0,0,0,0)
        points = []
        doorsGreen = []
        doorsRed = []
        # ----------------------------------------------------------------
        #PARSE THE DOORS IN THEIR OWN LISTS
        for i in range((height+1),len(lines)):
            parts = str(lines[i]).strip().split(' ')
            action = int(parts[1])
            x = int(parts[2])
            y = int(parts[3])
            if (parts[0].strip() == 'G'):
                doorsGreen.append(Point(x,y,width,height,0,action))
            else:
                doorsRed.append(Point(x,y,width,height,action,0))
        # ----------------------------------------------------------------
        #PARSE THE LINES OF THE MAZE AND PULL OUT THE NAVIGABLE POINTS
        for i in range(1,(height+1)):
            x = -1
            for c in lines[i]:
                x += 1
                if c == 'B': #begin point
                    begin = Point(x,i-1,width,height)
                elif c == 'F': #finish point
                    finish = Point(x,i-1,width,height)
                    points.append(finish)
                elif c == 'G': #green door
                    find = Point(x,i-1,width,height)
                    idx = doorsGreen.index(find)
                    points.append(doorsGreen[idx])
                elif c == 'R': #red door
                    find = Point(x,i-1,width,height)
                    idx = doorsRed.index(find)
                    points.append(doorsRed[idx])
                elif c == '.': #open space
                    points.append(Point(x,i-1,width,height))
        # ----------------------------------------------------------------
        # START AT THE BEGINNING, AND ASSEMBLE A ROUTE OUT OF THE MAZE
        # We can do this because the problem guarantees there is only one
        # correct path out, and that there IS a correct path out (otherwise 
        # we'd have to take a different approach). In this approach, we simply
        # check to see which points we could move to N/S/E/W of where we 
        # currently are, check to see that those are valid points, and we can
        # move to them. If so, if we have only one choice, we simply move to it
        # if we have more than one choice we record that point as a "decision
        # point," and try all of them until we are not blocked. If we reach a
        # dead-end we back up to the last decision point, marking the points
        # we are backing up into as 
        route = []
        current = begin
        decision = None
        deadends = []
        route.append(begin)
        t = 0
        ## DEBUGGING
        # trouble = Point(1,10,width,height)
        # red = Point(3,10,0,0,0,0)
        # green = Point(1,9,0,0,0,0)
        # red1 = Point(4,10,0,0,0,0)
        # red2 = Point(4,8,0,0,0,0)
        # grn1 = Point(1,8,0,0,0,0)
        while (current != finish):
            moves = current.CanMoveTo(points,route,t,doorsGreen,doorsRed)
            ## DEBUGGING
            # if (red in moves or green in moves or red1 in moves or grn1 in moves or red2 in moves):
            #     print('door check')
            if (len(moves) == 0):
                #dead end, backtrack to last decision point
                while (route[len(route)-1] != decision):
                    deadends.append(route[len(route)-1])
                    route.pop()
                    current = route[len(route)-1]
                    ## DEBUGGING
                    # print('backing to: '+str(current))
                    t -= 2
            elif (len(moves) == 1):
                route.append(moves[0])
                current = moves[0]
                ## DEBUGGING
                # if (current == trouble):
                #     print('trouble')
                # print('moving to: '+str(current))
                t += 2
            else:
                #try all of the routes
                decision = current
                ## DEBUGGING
                # if (decision == trouble):
                #     print('trouble')
                moved = False
                ## DEBUGGING
                ## test for all possible routes
                # for i in range((len(moves)-1),-1,-1):
                #     move = moves[i]
                for move in moves:
                    if (move not in deadends):
                        route.append(move)
                        ## DEBUGGING
                        # print('moving to: '+str(move))
                        current = move
                        t += 2
                        moved = True
                        break
                if (not moved):
                    route.pop()
                    current = route[len(route)-1]
                    ## DEBUGGING
                    # print('backing to: '+str(current))
                    t -= 2
        # ----------------------------------------------------------------
        # Now that we have our route, only thing left to do is count the 
        # "steps" we take for each "direction." We do that with the "DirFrom"
        # method in the Point class I created for this solution
        direction = ''
        total = 0
        last = route[0]
        # steps are output when we change directions, and the totals are then reset
        for point in route:
            if (point != last):
                if (direction == ''):
                    direction = point.DirFrom(last)
                    total +=1
                else:
                    newDir = point.DirFrom(last)
                    if (newDir == direction):
                        total +=1
                    else:
                        print(f'{direction} {total}')
                        direction = newDir
                        total = 1
                last = point
        # Have to output the last direction total (since we won't have a 
        # final change in direction once we reach the end)
        print(f'{direction} {total}')
    else:
        print('** ERROR ** data file is malformed')

class Point:
    'X,Y 2D Point on a grid'
    x = 0
    y = 0
    w = 0
    h = 0
    closesAt = 0
    opensAt = 0
    def __init__(self, _x, _y,width,height,closes=0,opens=0):
        '''There are other ways to handle tracking this data. I could have
        used globals for the grid wxh for instance, but I like having it
        all self-contained. X and Y should be self explanatory for this
        class. Same for width and height. closesAt and opensAt are used
        exclusively by points which are also doors.'''
        self.x = _x
        self.y = _y
        self.w = width
        self.h = height
        self.closesAt = closes
        self.opensAt = opens
    def __eq__(self, that):
        '''This is critically important. Overriding the equality test here
        is what allows this class to do checks like (x in list) and to see
        if one point equals another, etc.'''
        return (self.x == that.x and self.y == that.y)
    def __str__(self):
        '''Convenience feature, mostly used for debugging so it prints
        the X & Y coordinates to the screen as (X,Y) instead of the
        object hash code'''
        return f'({self.x},{self.y})'
    def copy(self):
        '''Deep copy function is used with all of the movement functions'''
        return Point(self.x,self.y,self.w,self.h,self.closesAt,self.opensAt)
    def MoveN(self):
        '''The MoveX functions are used to test where a point could possibly
        move along the N|S and E|W axes. Same login in all of the functions,
        only thing which changes is which location point is being changed
        and in which "direction"'''
        tmp = self.copy()
        tmp.y -= 1
        return tmp
    def MoveS(self):
        tmp = self.copy()
        tmp.y += 1
        return tmp
    def MoveE(self):
        tmp = self.copy()
        tmp.x += 1
        return tmp
    def MoveW(self):
        tmp = self.copy()
        tmp.x -= 1
        return tmp
    def DirFrom(self,that):
        '''This is used for the output at the end of the solution. 
        Given a point from where this current point would have 
        moved from, determine the opposite direction as the 
        origin source. E.G. if "that" matches this point's location
        to the North, then this point is South of that prior point. Etc.'''
        N = self.MoveN()
        S = self.MoveS()
        E = self.MoveE()
        W = self.MoveW()
        if (that == N):
            return 'S'
        elif (that == S):
            return 'N'
        elif (that == E):
            return 'W'
        elif (that == W):
            return 'E'
        else:
            return 'error'
    def CanMoveTo(self,points,route,t,doorsGreen,doorsRed):
        '''Calculates the N/S/E/W possible points a given
        point could possibly move toward. Then checks those
        points to make sure they are still inside the grid
        with the CanJoin function. Also checks to make sure
        the point is not already in the in-progress route.
        Finally, checks to make sure that if the calculated
        next point is a door, that it can be passed through
        using the DoorPassable function.'''
        moves = []
        N = self.MoveN()
        S = self.MoveS()
        E = self.MoveE()
        W = self.MoveW()
        if (self.CanJoin(N) and N in points and N not in route and self.DoorPassable(N,t,doorsGreen,doorsRed)):
            moves.append(N)
        if (self.CanJoin(S) and S in points and S not in route and self.DoorPassable(S,t,doorsGreen,doorsRed)):
            moves.append(S)
        if (self.CanJoin(E) and E in points and E not in route and self.DoorPassable(E,t,doorsGreen,doorsRed)):
            moves.append(E)
        if (self.CanJoin(W) and W in points and W not in route and self.DoorPassable(W,t,doorsGreen,doorsRed)):
            moves.append(W)
        return moves
    def DoorPassable(self,door,t,doorsGreen,doorsRed):
        '''Used to determine if a given point, which is also a door, is 
        "closed" or "open" and thus "passable". Does a lookup of the 
        calculated door point against the doors lists do it can pull out
        the opensAt closesAt attributes for the door'''
        result = True
        if (door in doorsGreen):
            idx = doorsGreen.index(door)
            door = doorsGreen[idx]
        elif (door in doorsRed):
            idx = doorsRed.index(door)
            door = doorsRed[idx]
        if (door.opensAt != 0):
            if (t < door.opensAt):
                result = False
        elif (door.closesAt != 0):
            if (t > door.closesAt):
                result = False
        return result
    def CanJoin(self,p):
        '''Points can only join to other points on the 
        grid to the immediate N/S/E/W of a given point.
        Must make sure the calculated point is still inside
        the WxH of the grid as well.'''
        result = False
        N = self.MoveN()
        S = self.MoveS()
        E = self.MoveE()
        W = self.MoveW()
        if (p == N and N.y >= 0):
            # print(str(self) + " can join with "+ str(p))
            result = True
        elif (p == S and S.y <= (S.h-1)):
            # print(str(self) + " can join with "+ str(p))
            result = True
        elif (p == E and E.x <= (W.w-1)):
            # print(str(self) + " can join with "+ str(p))
            result = True
        elif (p == W and W.x >= 0):
            # print(str(self) + " can join with "+ str(p))
            result = True
        return result
    def Touches(self,p):
        '''(Not Used).
        Mostly useful with regard to a line segment made of 2 points.
        Created when I was toying with the idea of going in that direction
        to solve this, before ultimately deciding against it.'''
        return (self.x == p.x or self.x  == p.y)

# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    # time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    for file in files:
        if ('in.txt' in file):
            print(f'{file}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

import sys
import time
import math
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAI' #prob24
# ------------------------------------------------------------------------

'''
PROBLEM: All Your Base
DIFFICULTY LEVEL: Intermediate
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 20 minutes
ESTIMATED STUDENT COMPLETION TIME NEEDED: 35-40 minutes
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-01-12 (updated to remove necessity for = padding against inputs)
WHAT IT TESTS: 
    1.) Ability to do slightly more advanced math operations (such as modulus division)
    2.) Ability to work with ASCII characters forwards and backwards
    3.) Ability to work with binary and bit data
    4.) Ability to either use arrays or Lists or string indices to organize sets of data
    5.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.

'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))

# ========================================================================
def Encode(line,base74):
    'For judges-use only, used to create the data sets ^_-'
    result = ''
    binaryString = ''
    #have to right-pad the string with '=' character if the binary bit total for the string isn't evenly divisible by 6
    #won't be needed for this problem though, because inputs are being crafted to avoid the issue
    while (((len(line)*8) % 6) != 0):
        line += '='
    #convert the characters in the string to their binary ASCII values, and left pad to enforce 8 characters (for a full byte)
    for c in line:
        binaryString += format(ord(c),'b').zfill(8)
    #parse through the string 6 bits at a time, pull those parts out and put them into a list
    #(could have done this as a single step, but I want new students to be able to debug this thing ^_-)
    sixBitParts = []
    for i in range(0,len(binaryString),6):
        sixBitParts.append(binaryString[i:i+6].zfill(8)) #this may be wrong, why are we left padding again?
    # treat the 6-bit parts a new binary numbers, 
    # convert those back to decimal, 
    # then add 8 to that value, 
    # then use that as an index to lookup an output character
    for bnry in sixBitParts:
        result += base74[(int(bnry,2)+8)]
    return result
# ========================================================================
def Decode(line,base74):
    "Decodes Johnny's base-74 encoding algorithm (reversing what is done in the Encode algorithm above)"
    result = ''
    # parse through the encoded string, get the index of each character,
    # then subtract 8 from it, then convert it to binary and left-pad it to 
    # 6 bits, then append that value to a decoding characters string
    chars = ''
    for c in line:
        idx = base74.index(c)-8
        chars += format(idx,'b').zfill(6)
    # walk through the bits in the character string, taking 8 at a time, convert the 8 bits to decimal integer
    # (ignore it if the character is 61, which is the '=' symbol used to pad input strings which aren't evenly
    # divisible by 6) then output the ASCII character that matches the ordinal value we just reverse calculated
    # to out output string
    for i in range(0,len(chars),8):
        c = int(chars[i:i+8],2)
        if (c != 61):
            result += chr(c)
    return result

# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 1):
        print(Decode(lines[0].strip(),lines[1].strip()))
    else:
        print('** ERROR ** data file is malformed')

# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    for file in files:
        if ('in.txt' in file):
            print(f'{file}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')


# print(str((len("It is often easier to ask for forgiveness than to ask for permission.")*8) % 6))
# student = ['The Quick Brown Fox Jumps Over the Lazy Dog','I am the very model of a modern Major-General','ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz','An electronic pulse is sent a refuge is found This is it this is where I belong']
# for s in student:
#     encoded = Encode(s,'1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz~!@#$%^&*(){}[]<>,./?"')
#     print(encoded)
#     print(Decode(encoded,'1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz~!@#$%^&*(){}[]<>,./?"'))

# judge = [That's one small step for man one giant leap for mankind"
# ,"Fortune favors the bold you'll never know what you're capable of if you don'ttry"
# ,'It is often easier to ask for forgiveness than to ask for permission']
# for j in judge:
#     encoded = Encode(j)
#     print(encoded)
#     print(Decode(encoded))

'''
PROBLEM: Welcome, to the Triwizard Tournament!
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 1 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 1 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-16
WHAT IT TESTS: 
    1.) Ability to submit code which runs :D
'''
# ========================================================================
# Literally all you have to do is print a hard coded string to the screen :)
# No datasets, no loops, nothing. Just print a string ;)
print('We bid welcome to the ladies of Beauxbaton and our friends from the north, the sons of Durmstrang.')
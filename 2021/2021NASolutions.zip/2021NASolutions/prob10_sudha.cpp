// ProbAT_sudha.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <stdio.h>      /* printf */
#include <vector>
#include <fstream>
#include <string>
using namespace std;

vector<string> FoundV;
vector<string> NFoundV;

// Time computation
//
int GetRestTime(string TimeVal)
{
    // return number of minutes before 17:00
    int nLen = TimeVal.length();
    int RetHourVal = 0;
    int RetMinVal = 0;
    bool bMinFound = false;
    for (int i = 0; i < nLen; i++)
    {
        if ((TimeVal[i] != ':') && (!bMinFound))
        {
            int nVal = TimeVal[i] - '0';
            RetHourVal = RetHourVal * 10 + nVal;
        }
        else
        {
            bMinFound = true;
            if (TimeVal[i] != ':')
            {
                int nVal = TimeVal[i] - '0';
                RetMinVal = RetMinVal * 10 + nVal;
            }
        }
    }
    int RetVal = RetHourVal * 60 + RetMinVal;
    int LastTime = 17 * 60;
    return LastTime-RetVal;
}

void GetValues(string filename)
{
    ifstream b_file(filename); // "probAT-2-in.txt");
    string str;
    while (getline(b_file, str)) {
      // cout << str << endl;
        if (str == "END")
            return;
        int nLen = str.length();
        bool bNameFound = false;
        string Name = "";
        string Rest = "";
        string TimeVal = "";
        string Total = "";
        int Total_Val;
        int Total_Min_Val=0;
        for (int i = 0; i < nLen; i++)
        {
            if ((str[i] != ' ') && (!bNameFound))
            {
                Name = Name + str[i];
            }
            else
            {
                if ((str[i] == ' ') && (!bNameFound))
                    i++;
                bNameFound = true;
                Rest = Rest + str[i];
            }
        }
        nLen = Rest.length();
        bool bTime = false;
        for (int i = 0; i < nLen; i++)
        {
            if ((Rest[i] != ' ') && (!bTime))
            {
                TimeVal = TimeVal + Rest[i];
            }
            else
            {
                if ((Rest[i] == ' ') && (!bTime))
                    i++;
                bTime = true;
                Total = Total + Rest[i];
                std::string::size_type sz;
                Total_Val = std::stoi(Total, &sz);
                Total_Min_Val = Total_Val * 10;
            }
        }
        int RetVal = GetRestTime(TimeVal);
        
        if (RetVal < Total_Min_Val)
        {
            NFoundV.push_back("Blah, blah, blah, time to order delivery");
          //  cout << " Blah, blah, blah, time to order delivery" << endl;
        }
        else
        {
            FoundV.push_back(Name);
;           // cout << Name << "look tasty" << endl;
        }
    }
}

int main(int argc, char* argv[])
{
    GetValues(argv[1]);
    if (FoundV.size() == 0)
        cout << " Blah, blah, blah, time to order delivery" << endl;
    else
    {
        string LastName = "";
        int nLen = FoundV.size();
        for (int i = 0; i < nLen; i++)
        {
            int len = FoundV[i].size();
            if (LastName == "")
                LastName = LastName + FoundV[i].substr(len-2);
            else
            {
                LastName = LastName + ",";
                LastName = LastName + FoundV[i].substr(len - 2);
            }
        }
        string retstr = "Villagers (" + LastName;
        retstr = retstr + ") look tasty";
        cout << retstr << endl;
    }
    std::cout << "Hello World!\n";
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file

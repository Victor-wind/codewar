# Needs Of the Many - CodeWars 2021
import sys
name = sys.stdin.readline().rstrip('\n').rstrip(' ');
print(name,", the needs of the many outweigh the needs of the few, or the one; live long and prosper.",sep='')

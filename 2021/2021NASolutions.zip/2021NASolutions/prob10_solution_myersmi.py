# 25ish minutes. 
# This would have taken me a LOT longer if not for python datetime if I wanted to test for every possibility

import sys
from datetime import date, datetime, time, timedelta

def get_vulnerable_time(applied_time, vpf_strength):
    vpf_strength = int(vpf_strength) * 10
    start_hour = int(applied_time[:2])
    start_min = int(applied_time[3:])

    final_time = datetime.combine(date.today(), time(start_hour, start_min)) + timedelta(minutes = vpf_strength)

    return final_time

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()[:-1]  # skip end

    villagers_tasty = ""

    for villager_line in inputText:
        villager_entry = villager_line.split()
        final_time = get_vulnerable_time(villager_entry[1], villager_entry[2])

        if final_time < datetime.combine(date.today(), time(17,00)):
            if villagers_tasty == "":
                villagers_tasty += villager_entry[0][-2:]
            else:
                villagers_tasty += ", " + villager_entry[0][-2:]

    if len(villagers_tasty) > 0:
        print("Villagers ({}) look tasty".format(villagers_tasty))
    else:
        print("Blah, blah, blah, time to order delivery")


# Welcome - CodeWars 2021
print("We bid welcome to the ladies of Beauxbaton and our friends from the north, the sons of Durmstrang.")

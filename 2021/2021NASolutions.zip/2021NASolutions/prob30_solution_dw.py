#**********************************************************************************************************
# Donnie Wahlquist
#**********************************************************************************************************
import sys
import os

size = 0
num_garbage = 0

solutions = []
solution_found = False


#***********************************************************
#***********************************************************
def myMain():
    global size
    global num_garbage
    global solution_found

    map = []
    #map_orig = []
    input_file = "input.txt"

    try:
        # Read input file
        with open(input_file, "r") as fp:
            line_no = 0
            for line in fp:
                line_no += 1
                if line_no == 1:
                    size = int(line.strip())
                elif line_no <= (size + 1):
                    # set up an array for this row.  -1 = garbage; 0 = empty
                    row = line.strip().split(" ")
                    binrow = []
                    for r in row:
                        val = 0
                        if r == "<>" :
                            val = -1       # garbage
                            num_garbage += 1
                        binrow.append(val)
                    #print(row)
                    map.append(binrow)
                else:
                    break                                   # finished parsing all the lines we need.
            fp.close()
            #print(map)
            #print("Number of garbage squares: %d" % (num_garbage))

            # find the start and end locations
            for row in range(0, size):
                for col in range(0, size):
                    if map[row][col] == -1  and  number_of_paths(map, row, col) == 1:
                        #print("Possible start point: (%d, %d)" % (col, row) )
                        stepno = 1           # Set starting point
                        solution_found = False
                        next_step(map, col, row, stepno, "")    # recursive.  Print solution if found.
                        if solution_found == True:
                            #print("Solution from %d, %d" % (col, row))
                            return          #All done - get out
                        #else:
                            #print("Solution no good: %d, %d" % (col, row))  # Try next start point



              
    except e:
        print("\n    ## ERROR \n" + e)
        return 3
        



#***********************************************************
#   number_of_paths(...)
#       - used to find the 2 potential starting points.
#       - returns the number of possible moves from this location.
#         If there is only 1 move, then this is either a start
#         or end position.
#***********************************************************
def number_of_paths(map, row, col):
    paths = 0
    # check North/South
    north = False
    south = False
    east  = False
    west  = False
    for element in range(0, size):
        if map[element][col] == -1:
            if element < row:
                north = True
            elif element > row:
                south = True
    # check East/West
    for element in range(0, size):
        if map[row][element] == -1:
             if element < col:
                west = True
             elif element > col:
                east = True 
    if north:
        paths += 1
    if south:
        paths += 1    
    if east:
        paths += 1    
    if west:
        paths += 1

    return paths




#***********************************************************
#   next_step(...)
#       - calls itself recursively.
#       - marks the step number at the from_x, from_y location.
#       - looks in appropriate directions for next move (no reverse)
#***********************************************************
def next_step(history, from_x, from_y, step_number, direction):  
    global size
    global num_garbage
    global solution_found

    my_map = []                    
    for i in range(0, size):                # by making a new copy, every move has it own history on the stack
        my_map.append( history[i].copy() )
    my_map[from_y][from_x] = step_number
    
    # NOTE:  map[] is accessed as "map[y, x]";     'Y' is the 1st index;  'X' is second and requires string indexing.

    if step_number == num_garbage:                          # found last garbage square!
        # Success! - found end of path.
        solution_found = True
        for line in my_map:
            buf = ""
            for i in range(0, size):
                buf += "%2d " % (line[i])
            buf = buf.replace(" 0 ", ".. ")
            print(buf)                                      # print the pretty solution
        return 

    if direction != "S":                                    # Not currently going "S"
        dir = "N"  
        next = next_possible(my_map, from_x, from_y, step_number, dir)          # next = [ x ], [ y ]
        if len(next) > 0:
            next_step(my_map, next[0], next[1], step_number+1, dir)   # move
     
    if direction != "N":                                    # Not currently going "N"
        dir = "S"                                           # try "S"
        next = next_possible(my_map, from_x, from_y, step_number, dir)          # next = [ x ], [ y ]
        if len(next) > 0:
            next_step(my_map, next[0], next[1], step_number+1, dir)   # move

    if direction != "W":                                    # Not currently going "W"
        dir = "E"                                           # try "E"
        next = next_possible(my_map, from_x, from_y, step_number, dir)          # next = [ x ], [ y ]
        if len(next) > 0:
            next_step(my_map, next[0], next[1], step_number+1, dir)   # move

    if direction != "E":                                    # Not currently going "E"
        dir = "W"                                           # try "W"
        next = next_possible(my_map, from_x, from_y, step_number, dir)          # next = [ x ], [ y ]
        if len(next) > 0:
            next_step(my_map, next[0], next[1], step_number+1, dir)   # move
    
    return 



#***********************************************************
#   next_possible()
#       - looks in specified direction for next move
#       - returns a list
#           - empty list, if no next move possible
#           - list [x, y] indicating next move.
#***********************************************************
def next_possible(prev_map, from_x, from_y, stepno, direction):
    next_move = []
    if direction == 'N':      
        for element in range(from_y-1, -1, -1):
            if element >= 0:
                val = prev_map[element][from_x]
                if val == -1:
                    # solution for next move
                    next_move.append(from_x)
                    next_move.append(element)
                    break
                elif val < stepno:              # available to cross, but not stop
                    continue           
                else:
                    break                       # no solution this direction.
    elif direction == 'S':      
        for element in range(from_y+1, size):
            if element < size:
                val = prev_map[element][from_x]
                if val == -1:
                    # solution for next move
                    next_move.append(from_x)
                    next_move.append(element)
                    break
                elif val < stepno:              # available to cross, but not stop
                    continue           
                else:
                    break                       # no solution this direction.
    elif direction == 'E':      
        for element in range(from_x+1, size):
            if element < size:
                val = prev_map[from_y][element]
                if val == -1:
                    # solution for next move
                    next_move.append(element)
                    next_move.append(from_y)
                    break
                elif val < stepno:              # available to cross, but not stop
                    continue           
                else:
                    break                       # no solution this direction.
    elif direction == 'W':      
        for element in range(from_x-1, -1, -1):
            if element >= 0:
                val = prev_map[from_y][element]
                if val == -1:
                    # solution for next move
                    next_move.append(element)
                    next_move.append(from_y)
                    break
                elif val < stepno:              # available to cross, but not stop
                    continue           
                else:
                    break                       # no solution this direction.

    return next_move







if __name__ == '__main__':
    ec = myMain()
    sys.exit(ec)


import sys


def read_input_data():
    in_data = sys.stdin.readlines()[1:]
    return in_data
      

def prob_AS(in_data):
    print("".join(in_data[::-1]))
    

if __name__ == "__main__":
    in_data = read_input_data()
    prob_AS(in_data)
    

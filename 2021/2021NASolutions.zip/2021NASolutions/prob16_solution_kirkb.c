#include <stdio.h>
#include <string.h>

int main(argc,argv) int argc; char **argv; {
#define BUF 8
#define PREFIXES 8
double amt;
char unit[BUF];

double siq[PREFIXES],b2q[PREFIXES];

char *si[PREFIXES] = { "B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB" };
char *b2[PREFIXES] = { "B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB", "ZiB" };
int u,i;


siq[0]=b2q[0]=1.0; 
 for(i=1;i<PREFIXES;i++) {
  siq[i]=siq[i-1]*1000.0;
  b2q[i]=b2q[i-1]*1024.0;
 }

scanf("%lf %s", &amt,unit);
for(i=0;i<PREFIXES;i++) if(strcmp(unit,si[i])==0) break;
amt*=siq[i]/b2q[i];
while(amt<1.0) {amt*=1024.0;i--;}
while(amt>1024.0) {amt/=1024.0;i++;}
printf("%.2lf %s\n",amt,b2[i]);
}


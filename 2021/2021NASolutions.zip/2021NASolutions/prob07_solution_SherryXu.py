import math

def get_dataset(problem):
    #read and get input file
    with open(r'.\student_datasets\prob'+problem+'-in.txt') as fi:
        input_file=[]
        for line in fi:
            input_file.append(line.rstrip('\n'))
    
    #read output file
    with open(r'.\student_datasets\prob'+problem+'-out.txt') as fo:
        output_file=[]
        for line in fo:
            output_file.append(line.rstrip('\n'))
    
    #display example output
    print('Example output: ')
    for line in output_file:
        print(line)
    
    return input_file
    

for example in ['AD-1','AD-2', 'AD-3']:
    lookup=[
        [0.90, 0.62, 0.57],
        [0.80, 0.42, 0.30],
        [0.70, 0.30, 0.74],
        [1.15, 0.80, 0.70],
        [0.15, 0.05, 0.03]
    ]
    ski_material=['RUBBER','WOOD','STEEL']
    surface=['CONCRETE','WOOD','STEEL','RUBBER','ICE']
    
    input_file=get_dataset(example)[0].split(' ')
    input_material=input_file[0]
    input_surface=input_file[1]
    
    x=ski_material.index(input_material)
    y=surface.index(input_surface)
    friction_coe=lookup[y][x]
    min_degree=round(math.degrees(math.atan(friction_coe)),1)
    
    print('Solution output: ')
    print('{} {}'.format("{0:.2f}".format(friction_coe), min_degree))
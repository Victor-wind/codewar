import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
import java.text.DecimalFormat;//required for rounding
public class prob12_Solution_McAdams {
/*
PROBLEM: You Flew In What?!
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 15 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 20 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-01
WHAT IT TESTS: 
    1.) Ability to work with floating point decimals
    2.) Ability to convert units of length and time
    3.) Ability to square numbers, multiply, and divide
    4.) Ability to round a number to a desired decimal place
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.

NOTE: This solution was translated from my original solution in Python, into Java. I did that for the first 15 problems in the packet
so students who only code in Java will have solutions to look at in their native coding language. The algorithms are the same. The only
parts which change are language specific things (such as how to access list elements). I also collapsed some functions out of python
back into the main program in Java, just to save time. By comparing these 15 translated Java programs to their original Python
implementations, you should be able to pull out Java coding from the rest of the Python solutions, if you'd like. The techniques and
coding functionality used should (more or less) stay the same for the rest of the Python solutions I did. I tend to stick to basics
when at all possible: lists, dictionaries, loops, and logic structures. The only one which might get a little tricky going from
Python to Java will be Pirate Parlay(#27). If you get that one working, I will be impressed :)
*/
	//------------------------------------------------------------------------
	// CHANGE THIS BEFORE SUBMITTING!
	private static final boolean AM_DEBUGGING = true;
	private static final boolean DATA_STUDENT = false;
	private static final String DEBUG_PROB_ID = "prob12";
	private static final int DEBUG_PROB_IN = 1;
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";
	private static final boolean DEBUG_MODE_ALL = true;
	//------------------------------------------------------------------------
	public static void main(String[] args) {
		try
		{
			GetData();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void MainProgram(List<String> lines) {
		if (lines.size() > 0) {
		    String[] parts = lines.get(0).strip().split(" ");
		    //0 == name, 1 == rate, 2 == unit length, 3 == per, 4 == unit time
		    if (parts.length > 4){
		        double rate = Double.parseDouble(parts[1]);
		        String unit_l = parts[2].strip();
		        String unit_t = parts[4].strip();
		        //need meters per second for formula

		        //IMPERIAL UNITS
		        if (unit_l.equals("MILES")){
		            //1 meter is equal to 3.28 feet
		            //5280 feet in a mile
		            //rate is given in miles, and we want meters, so first convert to feet
		            //then divide by 3.28 to get meters
		            rate = ((rate * 5280)/3.28);
		        }
		        else if (unit_l.equals("YARDS")){
		            //1 meter is equal to 3.28 feet
		            //3 feet in a yard
		            //rate is given in yards, want meters. First convert to feet, 
		            //then divide by 3.28 to get meters
		            rate = ((rate * 3) / 3.28);
		        }
		        else if (unit_l.equals("FEET")){
		            //1 meter is equal to 3.28 feet
		            rate = (rate / 3.28);
		        }
		        else if (unit_l.equals("INCHES")){
		            //1 meter is equal to 3.28 feet
		            //12 inches equals 1 foot
		            rate = ((rate/12)/3.28);
		        }
		        else if (unit_l.equals("KILOMETERS")){
		            //METRIC UNITS
		            //we are already in metric, just need to increase to meters
		            //1000 meters = 1 kilometer
		            rate = (rate * 1000);
		        }
		        else if (unit_l.equals("CENTIMETERS")){
		            //METRIC UNITS
		            //we are already in metric, just need to reduce to meters
		            //100 centimeters = 1 meter
		            rate = (rate / 100);
		        }
		        if (unit_t.equals("HOUR")){
		            rate = ((rate / 60.0)/60.0); //60 seconds in a minute, 60 minutes in an hour, and we want seconds
		        }
		        else if (unit_t.equals("MINUTE")){
		            rate = (rate / 60.0); //60 seconds in a minute, and we want seconds
		        }
		        // ------------------------------------------------------------
		        double vertical_distance = (rate*rate) / (2 * 9.805);
		        DecimalFormat df = new DecimalFormat("0.00");//constant for rounding decimals
		        String distanceOut = df.format(vertical_distance);
		        System.out.print(parts[0].strip()+" will launch the messenger "+distanceOut+" meters high, ");
		        if (vertical_distance < 25.0){
		            print("SPLAT!");
		        }
		        else if (vertical_distance > 50.0){
		            print("OUCH!");
		        }
		        else{
		            print("SUCCESS!");
		        }
		    }
		    else{
		        print("** ERROR ** data file is malformed");
		    }
		}
		else
		{
			print("*****Error Malformed Data");
		}
	}
	private static List<String> inputFromStdIn() {
		List<String> lines =new ArrayList<String>();
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static void GetData() throws IOException {
		String dataset = "student";
		if (!DATA_STUDENT) {
			dataset = "judge";
		}
		if (AM_DEBUGGING) {
			if (DEBUG_MODE_ALL) {
				List<String> datasets =new ArrayList<String>();
				File datasetFolder = new File(DEBUG_PATH+"\\"+dataset+"_datasets\\");
				File[] files = datasetFolder.listFiles();
				for (File f:files) {
					if (f.isFile()) {
						if (f.getName().indexOf(DEBUG_PROB_ID) > -1 && f.getName().indexOf("in") > -1)
						{
							datasets.add(f.getName());
						}
					}
				}
				for (String file: datasets) {
					print("--------------------------------------------------------------------------------------");
					print("DEBUGGING OUTPUT FOR: "+file);
					MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+file).toPath()));
				}
			}
			else {
				MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+DEBUG_PROB_ID+
						"-"+DEBUG_PROB_IN+"-in.txt").toPath()));
			}
		}
		else{
			MainProgram(inputFromStdIn());
		}
	}
	private static void print(String s) {
		//shortcut for moving back and forth between Python (and, also, (and I cannot stress this enough), I hate typing out the full System.out.println() ceremony every time
		System.out.println(s);
	}
}

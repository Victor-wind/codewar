#include <stdio.h>
#define MAX 80

char wave[MAX][MAX+1];
int main(argc,argv) int argc; char **argv; {
int n;
int i;
scanf("%d",&n);
for(i=0;i<=n;i++)    
  fgets(wave[i],MAX+1,stdin);
for(i=n;i>0;i--)
  printf("%s",wave[i]);
}

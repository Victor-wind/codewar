# the important pieces of information aren't immediately obvious but I see them now in the second paragraph (speeds, distances, etc.)
# Overall it explains things ok. 30ish minutes.

from datetime import date, datetime, time, timedelta
import sys

def print_schematic(distance_left):
    spots = int(distance_left/.2)

    for i in range(6):
        line = ""
        line += "|"
        for j in range(spots):
            if i == 5:
                line += "."
            else:
                line += " "
        line += "|"
        print(line)

    return spots

if __name__ == "__main__":
    inputText = sys.stdin.read().split()

    wall_time = inputText[0]
    call_time = inputText[1]

    wall_start = datetime.combine(date.today(), time(int(wall_time[:2]), int(wall_time[3:5]), int(wall_time[6:])))
    call_start = datetime.combine(date.today(), time(int(call_time[:2]), int(call_time[3:5]), int(call_time[6:])))
    wall_end = call_start + timedelta(seconds = 40)
    total_time = (wall_end - wall_start).total_seconds()

    distance_left = 500 - total_time

    if distance_left < 0:
        distance_left = 0.0
    else:
        distance_left = float(distance_left) / 100.0

    print("{:.2f}".format(distance_left))
    spots = print_schematic(distance_left)
    if spots == 1:
        print("THIS IS SOME RESCUE!")
    elif spots > 1:
        print("THE FORCE WAS WITH YOU")
    else:
        print("CURSE MY METAL BODY, I WASN'T FAST ENOUGH!")

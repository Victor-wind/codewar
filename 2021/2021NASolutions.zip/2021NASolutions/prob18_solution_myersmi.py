# 10ish minutes. Kind of straightforward but some parts in the discussion are needed to properly answer

import sys
import math

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()

    method = inputText[0]
    num_people = inputText[1]
    time = inputText[2]
    startup = int(inputText[3])
    output = float(inputText[4])
    people_avail = inputText[5]

    output_sec = output / 3600.0
    time_needed = math.ceil(1210000000.0 / output_sec)


    if num_people > people_avail or startup + time_needed > 3600:
        print("{} can generate {:.2f} watts/second".format(method, 0.0))
        print("WHOA, HEAVY!")
    else:
        print("{} can generate {:.2f} watts/second".format(method, output_sec))
        print("MARTY CAN MAKE IT!")
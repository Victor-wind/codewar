import sys

line = sys.stdin.readline().rstrip('\n').rstrip(' ')

while(line):
    words = line.split(' ')
    height = float(words[0])
    radius = float(words[1])
    volume = 3.1415926536 * height * radius * radius

    num = '{:.2f}'.format(round(volume, 2))
    print(str(num) + " cubic inches")

    line = sys.stdin.readline().rstrip('\n').rstrip(' ')

def get_dataset(problem):
    #read and get input file
    with open(r'.\student_datasets\prob'+problem+'-in.txt') as fi:
        input_file=[]
        for line in fi:
            input_file.append(line.rstrip('\n'))
    
    #read output file
    with open(r'.\student_datasets\prob'+problem+'-out.txt') as fo:
        output_file=[]
        for line in fo:
            output_file.append(line.rstrip('\n'))
    
    #display example output
    print('Example output: ')
    for line in output_file:
        print(line)
    
    return input_file


for example in ['BC-1','BC-2', 'BC-3']:
    input_file=get_dataset(example)
    input_image=input_file[1:]
    
    new_image=[]
    for line in reversed(input_image):
        new_image.append(line)
    
    print('Solution output: ')
    for line in new_image:
        print(line)
    print()
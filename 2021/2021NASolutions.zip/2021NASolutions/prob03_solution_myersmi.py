# Easy. A few minutes. 

import sys

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()
    for y, line in enumerate(inputText):
        x = line.find('P')
        if x > -1:
            print("Ace, move fast, pigeon is at ({},{})".format(x,y))
            break
    else:
        print("No pigeon, try another map, Ace")
    

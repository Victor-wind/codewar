// probAC_Sudha.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdio.h>      /* printf */
#include <math.h>       /* atan */
#include <iomanip>
#include <string.h>
#include <vector>
#include <fstream>
#include <string>
using namespace std;

#define PI 3.14159265

string V[5][3] = {
    {  "0.90", "0.62", "0.57" },
    { "0.80", "0.42", "0.30" },
    { "0.70", "0.30", "0.74" },
    { "1.15", "0.80", "0.70" },
    { "0.15", "0.05", "0.03"}

};

void GetValues(int& Row, int& Col)
{
    ifstream b_file("probAD-3-in.txt");
    string str;
    string firststr=""; 
    string secondstr="";
    while (getline(b_file, str)) {
        int nLen = str.length();
        bool bFound = false;
        for (int i = 0; i < nLen; i++)
        {
            if ((str[i] != ' ') && (!bFound))
            {
                firststr = firststr + string(1, str[i]);
               
            }
            else 
            {
                bFound = true;
                if (str[i] != ' ')
                secondstr = secondstr +string(1, str[i]);
            }

        }
        if (secondstr == "CONCRETE")
            Row = 0;
        else if (secondstr == "WOOD")
            Row = 1;
        else if (secondstr == "STEEL")
            Row = 2;
        else if (secondstr == "RUBBER")
            Row = 3;
        else if (secondstr == "ICE")
            Row = 4;

        if (firststr == "RUBBER")
            Col = 0;
        if (firststr == "WOOD")
            Col = 1;
        if (firststr == "STEEL")
            Col = 2;

    }
}
int main()
{
    int x = 0;
    int y = 0;
    GetValues(x, y);
    
    double param, result;
    string Val = V[x][y];
    char Value[100];
    for (int i = 0; i < Val.length(); i++)
    {
        Value[i] = Val[i];
    }
    param = atof(Value);
    result = atan(param) * 180 / PI;
    char buffer[50];
    sprintf_s(buffer, "%f", result);
    std::string str(buffer);
    string retstr = "";
    int nlen = str.length();
    bool bFound = false;
    int Count = 0;
    bool bAdd = false;
    int nVal = 0;
    for (int i = 0; i < nlen; i++)
    {
        if (str[i] == '.')
            nVal = i;
    }
    int ia = str[nVal+2] - '0';
    if (ia >= 5)
        bAdd = true;
    

    for (int i = 0; i < nlen; i++)
    {
        if (str[i] != '.')
        {
            if ((bFound) && (Count < 1))
            {
               // retstr = retstr + str[i];

                if (bAdd)
                {
                    int ia = str[i] - '0';
                    ia++;
                    char a = ia + '0';
                    if (Count == 0)
                        retstr = retstr + string(1, a);
                    else
                        retstr = retstr + str[i];
                }
                else
                {
                    retstr = retstr + str[i];
                } 
                Count++;
            }
            else if (!bFound)
            {
                retstr = retstr + str[i];
            }
        }
        else
        {
            retstr = retstr + str[i];
            bFound = true;
        }

    }
    string outstr = Val + " ";
    outstr = outstr + retstr;
    std::cout << outstr <<endl;
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file

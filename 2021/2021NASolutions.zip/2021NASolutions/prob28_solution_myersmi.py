# 30-40ish minutes. Pretty interesting problem. Instructions are fairly clear.
import sys

def int_to_en(num):  # from stackoverflow
    d = { 0 : 'zero', 1 : 'one', 2 : 'two', 3 : 'three', 4 : 'four', 5 : 'five',
          6 : 'six', 7 : 'seven', 8 : 'eight', 9 : 'nine', 10 : 'ten',
          11 : 'eleven', 12 : 'twelve', 13 : 'thirteen', 14 : 'fourteen',
          15 : 'fifteen', 16 : 'sixteen', 17 : 'seventeen', 18 : 'eighteen',
          19 : 'nineteen', 20 : 'twenty',
          30 : 'thirty', 40 : 'forty', 50 : 'fifty', 60 : 'sixty',
          70 : 'seventy', 80 : 'eighty', 90 : 'ninety' }
    if (num < 20):
        return d[num]

    if (num < 100):
        if num % 10 == 0: return d[num]
        else: return d[num // 10 * 10] + d[num % 10]

    return "onehundred"


if __name__ == "__main__":
    inputText = sys.stdin.read().split()

    start = int(inputText[0])
    end = int(inputText[1])

    diff = (end - start)

    width = len(int_to_en(start)) + 2 * diff
    height = 1 + 2 * diff

    output = [[" " for i in range(width)] for j in range(height)]
    modifier = 0

    for i in range(end, start-1, -1):
        word = int_to_en(i)

        index = 0
        x, y = 1 + modifier, 0 + modifier
        reached_right, reached_bottom, reached_left = False, False, False
        while output[y][x] == " ":
            output[y][x] = word[index]
            index += 1
            if index == len(word):
                index = 0

            if x == 0 + modifier and y == 0 + modifier:
                break

            if x + 1 == width - modifier:
                reached_right = True
            if y + 1 == height - modifier:
                reached_bottom = True
            if x == 0 + modifier:
                reached_left = True
            if reached_right and reached_bottom and reached_left:
                y -= 1
            elif reached_right and reached_bottom:
                x -= 1
            elif reached_right:
                y += 1
            else:
                x += 1
        
        modifier += 1

    y = int(len(output)/2)
    x = 0
    for char in output[y]:
        if char == " ":
            break
        x += 1


    for char in word:
        output[y][x] = char
        x+= 1

    for line in output:
        string = ""
        for char in line:
            string += char
        print(string)

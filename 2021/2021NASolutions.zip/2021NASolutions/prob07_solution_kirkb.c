#include <stdio.h>
#include <math.h>
#include <string.h>
#define BUF 32
#define SKIS 3
#define MATS 5

char *ski[SKIS] =  {"RUBBER", "WOOD", "STEEL"};
char *mat[MATS] =  {"CONCRETE", "WOOD", "STEEL", "RUBBER", "ICE"}; 

double coef[5][3] = {
{0.90, 0.62, 0.57},
{0.80, 0.42, 0.30},
{0.70, 0.30, 0.74},
{1.15, 0.80, 0.70},
{0.15, 0.05, 0.03}
};

int main(argc,argv) int argc; char **argv; {
char s[BUF],m[BUF];
int si,mi;
scanf("%s %s",s,m);
for(si=0;si<SKIS;si++) if(strcmp(s,ski[si])==0) break;
for(mi=0;mi<MATS;mi++) if(strcmp(m,mat[mi])==0) break;
printf("%.2lf %.1lf\n",coef[mi][si],atan(coef[mi][si])*180.0/3.1415926);
}

#**********************************************************************************************************
# Donnie Wahlquist
#**********************************************************************************************************
import sys
import os

size = 0
solution_found = False
t0_known_blocks = []
t0_known_blocks_count = 0 


#***********************************************************
#  Tiling with Tatamis
#***********************************************************
def myMain():
    global size
    global solution_found
    global t0_known_blocks
    global t0_known_blocks_count

    map = []
    input_file = "input.txt"

    try:
        # Read input file
        with open(input_file, "r") as fp:
            line_no = 0
            for line in fp:
                line_no += 1
                if line_no == 1:
                    size = int(line.strip())
                elif line_no <= (size + 1):
                    # set up an array for this row.
                    row = line.strip()
                    binrow = []
                    for ndx in range(0, len(row)):
                        val = 0
                        if row[ndx] == '.' :
                            val = -1       # unknown value
                        else:
                            val = int(row[ndx])
                            if val > 1:
                                t0_known_blocks.append([ndx, line_no - 2])
                                t0_known_blocks_count += 1
                        binrow.append(val)
                    #print(row)
                    map.append(binrow)
                else:
                    break                           # finished parsing all the lines we need.
            fp.close()
            #print(map)
            #print(t0_known_blocks)
            #print(t0_known_blocks_count)


            solution_found = False
            col = 0
            row = 0
            num = 0
            next_step(map, col, row, num, "", 0)    # recursive.  Print solution if found.
            if solution_found == True:
                return                              # All done - get out
            else:
                print("Didn't find a Solution")



              
    except e:
        print("\n    ## ERROR \n" + e)
        return 3
        





#***********************************************************
#   next_step(...)
#       - calls itself recursively.
#       - marks the tatami tiles starting at the 'from_x', 'from_y'
#         location, in the direction specified ("S" for South or "E" for East).
#       - calls "find_next()" for the next location for a tile search.
#       - calls "next_possible()" for a list of number and x,y, looking 'S'.  
#       - for each one, it calls "next_step()" recursively.
#       - calls "next_possible()" for a list of number and x,y, looking 'E'.  
#       - for each one, it calls "next_step()" recursively.
#***********************************************************
def next_step(history, from_x, from_y, number, direction, known_ndx):  
    global size
    global solution_found

    if solution_found == True:
        #print("Exiting: solution already found.")
        return

    my_map = []   
    # NOTE:  my_map[] is accessed as "my_map[y, x]";     'Y' is the 1st index;  'X' is second and requires string indexing.                 
    for i in range(0, size):                # by making a new copy, every recursive call has it own unique map on the stack
        my_map.append( history[i].copy() )

    #print_map(my_map)
    #print("next_step(): x: %d, y: %d, number: %d, direction: %s" % (from_x, from_y, number, direction))

    # update map with move.
    if number != 0:                                 # if start, num=0; Only change map if non-zero.
        if direction == 'S':                              # 'S' - fill down
            for i in range(0, number):
                my_map[from_y+i][from_x] = number
        else:                                       # 'E' - fill to right
            for i in range(0, number):
                my_map[from_y][from_x+i] = number  

    #print_map(my_map)
    next_empty = find_next(my_map, from_x, from_y, known_ndx)
    #print(next_empty)
    if len(next_empty) == 0:
        # Success! - found end of pat               # Solved puzzle
        solution_found = True
        #print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   Success   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        print_map(my_map)                           # Output the Solution
        return 

    x = next_empty[0]
    y = next_empty[1]
    next_known_ndx = next_empty[2] + 1              # This is where we increment the next known ndx.
    #print(x)
    #print(y)

    direction = "S"                                 # try "S"
    next = next_possible(my_map, x, y, direction, known_ndx)       # next = [ [num1, x, y], [num2, x, y], ... ]
    #print(next)
    if len(next) > 0:
        for el in next:                             # el =  [num, x, y]
            next_step(my_map, el[1], el[2], el[0], direction, next_known_ndx)     # move

    
    direction = "E"                                 # try "E" 
    next = next_possible(my_map, x, y, direction, known_ndx)   # next = [ num1, num4 ]
    if len(next) > 0:
        #print(next)
        for el in next:                             # el =  [num, x, y]
            if el[0] != 1:                          # No need to try 1-East, same as 1-South)
                next_step(my_map, el[1], el[2], el[0], direction, next_known_ndx)   # move

    return 




def print_map(my_map):
    for line in my_map:
        buf = ""
        for i in range(0, size):
            if line[i] == -1:
                buf += '.'
            else:
                buf += "%d" % (line[i])
        print(buf) 
    return




#***********************************************************
#   find_next(...)
#       - start by providing original known blocks > 1 size.
#       - next start providing empty blocks,
#         looking from Left-to-Right, Top-to-Bottom, find
#         the x,y coordinate of the next -1.
#       - returns:
#           - empty list, if no more -1 (completed puzzle)
#           - list [x, y, known_ndx] indicating the next block to
#             start from, and the current index for processing
#             original known blocks.  When we transition
#             from the last known block to the first available
#             open space from the top left, the known_ndx will 
#             be >= t0_known_block_counts.  When we set the first
#             location for an empty space, we will set known_ndx
#             to '9999' from then on.  So the first time we get
#             past the known block list, it will reset x,y = 0,0
#             and proceed from there.
#***********************************************************
def find_next(prev_map, from_x, from_y, known_ndx):
    global size

    global t0_known_blocks
    global t0_known_blocks_count

    if known_ndx < t0_known_blocks_count:
        x = t0_known_blocks[known_ndx][0]
        y = t0_known_blocks[known_ndx][1]    
        return [x, y, known_ndx]

    if known_ndx != 9999:       # if this is the 1st "find_next" after handling known blocks,
        start_x = 0             #    then must ignore from_x and from_y and reset start_x, start_y to 0.
        start_y = 0
    else:
        start_x = from_x        # normal
        start_y = from_y
    for y in range(start_y, size):
        for x in range(start_x, size):
            if prev_map[y][x] == -1:
                return [x, y, 9999]             # 9999 > t0_known_block_counts
        start_x = 0
    return []





#***********************************************************
#   next_possible()
#       - looks in specified direction for next moves of
#         each size block
#       - NOTE that for efficiency, we traverse the table
#         generally South (Down) and East (Right).  For original
#         known tiles, we cover them first (handled by find_next(),
#         and actually look for all possible anchor positions of the tile.
#         For South direction, we look up to find possible anchors
#         for this cell.  Then return possibilities as the number
#         and the x,y coordinate of the anchor cell.
#       - returns a list of possibilities
#           - empty list, if no next move possible
#           - list [[num, x, y]] indicating all possible numbers with
#             the x, y coordinate of the anchor tile, in the 
#             direction specified.
#***********************************************************
def next_possible(prev_map, from_x, from_y, direction, known_ndx):
    global size

    #print("next_possible(): x: %d, y: %d, dir: '%s', known_ndx: %d" % (from_x, from_y, direction, known_ndx))
    #print_map(prev_map)

    num_list = []
    x = from_x
    y = from_y
    if direction == 'S':   
        for num in range(1, 5):                        # numbers 1 to 4
        #for num in range(4, -1, -1):                    # numbers 4 to 1
            if prev_map[y][x] != -1:                    # already have a number in starting block provided
                if prev_map[y][x] != num:               #  So, only consider this number.
                    continue
                elif num == 1:                          # if the begin block is a '1' and looking to place '1', no action needed.
                    continue
            begin_offset = 0
            if known_ndx < t0_known_blocks_count:       # not anchored, must find possible anchors for knowns (looking UP also)
                begin_offset = - (num -1)
                if (begin_offset + from_y) < 0:
                    begin_offset = - from_y
            for offset in range(begin_offset, 1):       # begin_offset (negative) to 0    
                ok_blocks = 0
                for ndx in range(offset, offset + num):
                    ul = up = ur = r = dr = d = dl = l = -1
                    if (y + ndx >= size) or ( (prev_map[y+ndx][x] != -1) and (prev_map[y+ndx][x] != num)):  # check position
                        break                                                                               # Not enough space
                    if (ndx == offset) and (y + ndx - 1 >= 0) and ((up := prev_map[y+ndx-1][x]) == num):    # check UP (ONLY on 1st block)
                        break                                                                               # Butting against upper tatami of same size  
                    if (ndx == (offset + num - 1)) and (y + ndx + 1 < size) and ((dn := prev_map[y+ndx+1][x]) == num):    # check DOWN (ONLY on Last block)
                        break                                                                               # Butting against lower tatami of same size                                 
                    if (x-1 >= 0) and ((l := prev_map[y+ndx][x-1]) == num):                                 # check left  
                        break                                                                               # Already same number on left             
                    if (x+1 < size) and ((r := prev_map[y+ndx][x+1]) == num):                               # check right
                        break                                                                               # Already same number on right

                    # now check 4 corners around block for matching num
                    if (x-1 >= 0) and (y+ndx-1 >= 0) and ((ul := prev_map[y+ndx-1][x-1]) == num):   # check up-left
                        break                                                                       # Already same number on the up left
                    if (x+1 < size) and (y+ndx-1 >= 0) and ((ur := prev_map[y+ndx-1][x+1]) == num): # check up-right
                        break                                                                       # Already same number on the up right               
                    if (x-1 >= 0) and (y+ndx+1 < size) and ((dl := prev_map[y+ndx+1][x-1]) == num): # check down-left
                        break                                                                       # Already same number on the down left
                    if (x+1 < size) and (y+ndx+1 < size) and ((dr := prev_map[y+ndx+1][x+1]) == num): # check down-right
                        break                                                                       # Already same number on the down right

                    # check for shared corner of 1,2,3,4
                    if (ndx == offset) or (ndx == (offset + num - 1)):         # Only need to check for 4 corners on 1st and last block
                        if not ( (l == ul  or ul == up or l == -1  or ul == -1 or up == -1)  and
                                 (up == ur or ur == r  or up == -1 or ur == -1 or r == -1)   and
                                 (r == dr  or dr == d  or r == -1  or dr == -1 or d == -1)   and
                                 (d == dl  or dl == l  or d == -1  or dl == -1 or l == -1)
                                ):
                            #print("Corner test (S): center at '%d, %d'\n  %2d %2d %2d\n  %2d %2d %2d\n  %2d %2d %2d" % (x, y+ndx, ul, up, ur, l, num, r, dl, d, dr))
                            break                                                    
                                                          
                    ok_blocks += 1
                if ok_blocks == num:
                    num_list.append([num, x , y + offset])       
    elif direction == 'E': 
        for num in range(1, 5):                        # numbers 1 to 4
        #for num in range(4, -1, -1):                    # numbers 4 to 1            
            if prev_map[y][x] != -1:                    # already have a number in starting block provided
                if prev_map[y][x] != num:               #  So, only consider this number.
                    continue
                elif num == 1:                          # if the begin block is a '1' and looking to place '1', no action needed.
                    continue                
            begin_offset = 0
            if known_ndx < t0_known_blocks_count:       # not anchored, must find possible anchors for knowns (looking LEFT also)
                begin_offset = - (num -1)
                if (begin_offset + from_x) < 0:
                    begin_offset = - from_x
            for offset in range(begin_offset, 1):       # begin_offset (negative) to 0  
                ok_blocks = 0
                for ndx in range(offset, offset + num):
                    ul = up = ur = r = dr = d = dl = l = -1
                    if x + ndx >= size  or  ( (prev_map[y][x+ndx] != -1) and (prev_map[y][x+ndx] != num) ): # check position
                        break                                                                               # Not enough space
                    if (ndx == offset) and (x + ndx - 1 >= 0) and ((l := prev_map[y][x+ndx-1]) == num):     # check LEFT (ONLY on 1st block)
                        break                                                                               # Butting against LEFT tatami of same size                     
                    if (ndx == (offset + num - 1)) and (x + ndx + 1 < size) and ((r := prev_map[y][x+ndx+1]) == num):    # check RIGHT (ONLY on Last block)
                        break                                                                               # Butting against RIGHT tatami of same size     
                    if (y-1 >= 0) and ((up := prev_map[y-1][x+ndx]) == num):                                # check up
                        break                                                                               # Already same number on the UP side                
                    if (y+1 < size) and ((d := prev_map[y+1][x+ndx]) == num):                               # check down
                        break                                                                               # Already same number on the Down side

                    # now check 4 corners around block for matching num
                    if (y-1 >= 0) and (x+ndx-1 >= 0) and ((ul := prev_map[y-1][x+ndx-1]) == num):           # check up-left
                        break                                                                               # Already same number on the up-left
                    if (y-1 >= 0) and (x+ndx+1 < size) and ((ur := prev_map[y-1][x+ndx+1]) == num):         # check up-right
                        break                                                                               # Already same number on the up-right
                    if (x+ndx-1 >= 0) and (y+1 < size) and ((dl := prev_map[y+1][x+ndx-1]) == num):         # check down-left
                        break                                                                               # Already same number on the down right
                    if (x+ndx+1 < size) and (y+1 < size) and ((dr:= prev_map[y+1][x+ndx+1]) == num):        # check down-right
                        break                                                                               # Already same number on the down right

                    # check for shared corner of 1,2,3,4
                    if (ndx == offset) or (ndx == (offset + num - 1)):         # Only need to check for 4 corners on 1st and last block
                        if not ( (l == ul  or ul == up or l == -1  or ul == -1 or up == -1)  and
                                 (up == ur or ur == r  or up == -1 or ur == -1 or r == -1)   and
                                 (r == dr  or dr == d  or r == -1  or dr == -1 or d == -1)   and
                                 (d == dl  or dl == l  or d == -1  or dl == -1 or l == -1)
                                ):
                            #print("Corner test (E): center at '%d, %d'\n  %2d %2d %2d\n  %2d %2d %2d\n  %2d %2d %2d" % (x+ndx, y, ul, up, ur, l, num, r, dl, d, dr))
                            #print_map(prev_map)
                            break 
                                                                              # Butting against upper tatami of same size  
                    ok_blocks += 1

                    # looks OK
                if ok_blocks == num:
                    num_list.append([num, x + offset, y])       

    return num_list







if __name__ == '__main__':
    ec = myMain()
    sys.exit(ec)

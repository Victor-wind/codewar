# Easy. A few minutes. Fairly straightforward
# I took the bruteforce, expandable method


import sys

cypher = {
    "A":"V",
    "B":"W",
    "C":"X",
    "D":"Y",
    "E":"Z",
    "F":"A",
    "G":"B",
    "H":"C",
    "I":"D",
    "J":"E",
    "K":"F",
    "L":"G",
    "M":"H",
    "N":"I",
    "O":"J",
    "P":"K",
    "Q":"L",
    "R":"M",
    "S":"N",
    "T":"O",
    "U":"P",
    "V":"Q",
    "W":"R",
    "X":"S",
    "Y":"T",
    "Z":"U"
}

def decode(encryptedText):
    plainText = ""
    for char in encryptedText:
        if char in cypher.keys():
            plainText += cypher[char]
        else:
            plainText += char
    return plainText

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()
    plainText = decode(inputText[1])
    print(plainText)
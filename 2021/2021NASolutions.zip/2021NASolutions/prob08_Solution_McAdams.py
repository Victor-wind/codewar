import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAQ' #prob08
# ------------------------------------------------------------------------

'''
PROBLEM: I'm Gonna Wreck It!
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 10 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 15 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-06
WHAT IT TESTS: 
    1.) Ability to work with nested loops
    2.) Ability to force integer calculations
    3.) Ability to handle edge cases and multiple output states
    4.) Ability to handle one-off issues with loops
    5.) Ability to control how text is printed to the screen (end of line terminal character)
    6.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))

# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 0):
        #0 = wall height
        #1 = how high hit
        #2 = Ralph mad 0-9 = no change, 10-19 = +1 distance away, 90-99 = +9 distance
        parts = lines[0].strip().split(' ')
        if (len(parts) > 2):
            height = int(parts[0])
            hit = int(parts[1])
            mad = int(parts[2])
            if ((hit > height) or hit == 0):
                #ralph missed, simply print the wall
                for i in range (0,height):
                    print('#')
            else:
                #Ralph didn't miss
                for i in range (1,hit):
                    # on the last block (at ground level) print the final block
                    # then print the periods to show space from the hit (if any)
                    # and the remainder of the wall pieces now lying on the ground
                    if (i == (hit -1)):
                        print('#',end='')
                        for j in range(0,int(mad/10)):
                            print('.',end='')
                        for k in range((hit-1),height):
                            print('#',end='')
                    else:
                        #print the part of the wall left standing (it will be at least one block)
                        print('#')
        else:
            print('** ERROR ** data file is malformed')
    else:
        print('** ERROR ** data file is malformed')
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)

# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    # counter = -1
    for file in files:
        if ('in.txt' in file):
            # counter +=1
            # print('')
            # print('')
            # print(f'example {counter}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

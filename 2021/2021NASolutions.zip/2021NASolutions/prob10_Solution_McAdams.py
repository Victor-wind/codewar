import sys
import datetime
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAT' #prob10
# ------------------------------------------------------------------------

'''
PROBLEM: Vampire-Block 4000
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 10 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 12 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-08
WHAT IT TESTS: 
    1.) Ability to calculate times (either manually, or using a date/time library)
    2.) Ability to calculate basic multiples of various input integers
    3.) Ability to parse specific parts out of a string given a specific format
    4.) Ability to format an output string that takes into account the "off by one" issue with looping (the commas in the list)
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 0):
        # relevant info from problem:
        # cutoff time is 17:00
        # 1 VPF = 10 minutes
        # data format: Villager-AA 08:00 50
        '''
        Solution for this one is relatively straight forward. Split up the input,
        line by line, and use a date/time library to setup the start time, and
        hard code the end time (which is known) to be 17:00 (Python requires a
        date-part when calculating time deltas, so just using the date of the
        contest, because why not? ¯\_(ツ)_/¯)
        Once we have the start time in a datetime object, all we have to do is
        subtract the start from the end and then check the elapsed seconds/60
        (to get minutes) and compare that to the total number of minutes of
        protection the villager's VPF gave them. If their protection minutes
        is LESS THAN elapsed minutes, Drac gets to snack! Else, skip them.
        Clever students will note the debug else-block below that which prints
        out the time the villager is protected until -- I used that to generate
        just-equal, just-under, and just-over times for the datasets ^_-
        '''
        #hard code the end time. We know Drac wants to snack at 5PM (17:00) so just hard code it
        end = datetime.datetime.fromisoformat('2021-03-06 17:00:00')
        #setup a list of villagers who were careless with their VPF applications
        dracSnaks = []
        #cycle through each line
        for line in lines:
            #split the line into parts on the space character
            parts = line.strip().split(' ')
            #ignore the file terminal line
            if ('END' not in line):
                if (len(parts) > 2):
                    #get the start time
                    start = datetime.datetime.fromisoformat('2021-03-06 '+parts[1].strip())
                    #get the time difference start-to-end
                    elapsed = end - start
                    vpf = int(parts[2])
                    #calculate how many minutes of protection their VPF got them
                    protection = vpf * 10
                    # check to see if their minutes of protections is less than the 
                    # minutes elapsed since they applied it until when Dracula is 
                    # looking to snack
                    if (protection < (elapsed.seconds/60)):
                        #snack time
                        dracSnaks.append(parts[0])
                        # print(f'DEBUG {parts[0]} protection until: {start}')
                    else:
                        start = start + datetime.timedelta(minutes=protection)
                        # print(f'DEBUG {parts[0]} protection until: {start}')
                else:
                    print('** ERROR ** data file is malformed')
        if (len(dracSnaks) > 0):
            # multi-part output (there are other ways to do this,
            # but I chose to use a single (long) print statement)
            print('Villagers (',end='')
            printed = 0 #have to account for off-by-one when looping output
            for snack in dracSnaks:
                printed += 1
                #split the villager name on the hyphen, only keep the 2-letter code
                name = snack.strip().split('-')
                if (len(name) > 1):
                    if (printed > 1):
                        print(', ',end='')
                    print(name[1].strip(),end='')
                else:
                    print('** ERROR ** data file is malformed')
            print(') look tasty')
        else:
            print('Blah, blah, blah, time to order delivery')
    else:
        print('** ERROR ** data file is malformed')
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    for file in files:
        if ('in.txt' in file):
            print(f'file {file}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

##########################################################################
#Calc student dataset 4 max times VPF can be applied and still protect
# timezorz = datetime.datetime.fromisoformat('2021-03-06 17:00')
# maxTime20 = timezorz - datetime.timedelta(minutes=(20*10))
# maxTime50 = timezorz - datetime.timedelta(minutes=(50*10))
# maxTime75 = timezorz - datetime.timedelta(minutes=(75*10))
# maxTime100 = timezorz - datetime.timedelta(minutes=(100*10))
# #spoiler alert, there is no time you can put 150VPF on that would allow Drac to bite you at 5PM ;)
# print(f'20 max: {maxTime20}')
# print(f'50 max: {maxTime50}')
# print(f'75 max: {maxTime75}')
# print(f'100 max: {maxTime100}')
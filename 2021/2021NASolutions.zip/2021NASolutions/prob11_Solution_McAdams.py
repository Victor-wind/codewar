import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAZ' #prob11
# ------------------------------------------------------------------------

'''
PROBLEM: Springing Along
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 7 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 10 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-11
WHAT IT TESTS: 
    1.) Ability to reformulate a given formula (solve for different variables using algebra)
    2.) Ability to parse and split data from strings
    3.) Ability to round numbers to a specific decimal place
    4.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 2):
        # input format:
        # F 10
        # K 3.8
        # X ?
        F = lines[0].strip().split(' ')
        K = lines[1].strip().split(' ')
        X = lines[2].strip().split(' ')
        # output variable we solve for has ?
        # output as: X -2.63, round to hundredths
        result = 0.0
        var = ''
        # We need to solve for the variable marked with ?
        # So, after we split up the input data, I setu up an
        # if conditional list checking for which variable was marked with
        # a question mark. If F is marked, we were given the formula for
        # that, so all we have to do is multiply it out.
        # If K or X were marked, we have to change the formula (using algebra)
        # so it solves for the variable we need to find. Since both of those
        # require division, I also put in a check for divide by zero (just to 
        # be safe -- as you always should).
        if (F[1] == '?'):
            # F = -kx
            var = 'F'
            result = -1 * float(K[1]) * float(X[1])
        elif (K[1] == '?'):
            # K = F/-x
            var = 'K'
            x = float(X[1])
            if (x != 0):
                result = float(F[1])/(-1 * x)
            else:
                print('** ERROR ** divide by zero')
        elif (X[1] == '?'):
            # X = F/-K
            var = 'X'
            k = float(K[1])
            if (k != 0):
                result = float(F[1])/(-1 * k)
            else:
                print('** ERROR ** divide by zero')
        else:
            print('** ERROR ** data file is malformed')
        # Once we know which variable we solved for, simply round the output
        # and print the result :)
        output = format(round(result,2),'.2f')
        print(f'{var} {output}')
    else:
        print('** ERROR ** data file is malformed')
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    for file in files:
        if ('in.txt' in file):
            print(f'file {file}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

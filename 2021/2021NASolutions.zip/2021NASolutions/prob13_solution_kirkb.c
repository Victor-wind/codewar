#include <stdio.h>
#include <math.h>
#define BUF 64

int main(argc,argv) int argc; char **argv; {
char name[BUF];
double ramp1,rate1,width;
double time1,speed1,distance;

scanf("%s",name);
scanf("%lf",&ramp1);
scanf("%lf",&rate1);
scanf("%lf",&width);

time1 = sqrt(2.0 * ramp1 / rate1);
speed1 = time1 * rate1;
distance = speed1 * speed1 / 9.805;

printf("%s will reach a speed of %.2lf m/s on a %.0lf ramp crossing %.1lf of %.1lf meters, ",name,speed1,ramp1,distance,width);
if(distance<(width-5.0)) printf("SPLASH!\n");
if((distance>=(width-5.0))&&(distance<=width)) printf("BARELY MADE IT!\n");
if(distance>width) printf("LIKE A BOSS!\n");
}

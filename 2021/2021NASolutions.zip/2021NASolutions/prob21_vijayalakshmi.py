# -*- coding: utf-8 -*-

import sys
from textwrap import wrap

def read_input_data():
    in_data = sys.stdin.read().strip()
    return in_data


def _look_for_word(words_list, exp_sub_str, reversed_word=False):
    exp_words = [exp_sub_str, exp_sub_str[::-1]]
    exp_words.extend(wrap(exp_sub_str, 2))
    found_word_details = []
    found_word = None
    for row, l in enumerate(words_list):
        for sub_str in exp_words:
            if sub_str in l:
                index = l.index(sub_str)
                if len(sub_str) == 2 and not reversed_word:
                    if row+1 >= len(words_list):
                        continue
                    rows = [row, row+1]
                    
                    columns = list(range(index, index+len(exp_sub_str)//2))
                    next_str = ""
                    for c in columns:
                        next_str += words_list[row+1][c]
                    if next_str in exp_words:
                        found_word = sub_str + next_str
                        found_word_details.append(f"{sub_str[0]}: {columns[0]},{rows[0]}")
                        found_word_details.append(f"{sub_str[1]}: {columns[1]},{rows[0]}")
                        found_word_details.append(f"{next_str[0]}: {columns[0]},{rows[1]}")
                        found_word_details.append(f"{next_str[1]}: {columns[1]},{rows[1]}")
                        break
                elif len(sub_str) != 2:
                    columns = list(range(index, index+len(exp_sub_str)))
                    found_word = sub_str              
                    
                    for i, letter in enumerate(list(sub_str)):
                        if reversed_word:
                            found_word_details.append(f"{letter}: {row},{columns[i]}")
                        else:
                            found_word_details.append(f"{letter}: {columns[i]},{row}")
                    
        if found_word_details:
            break
    return found_word, found_word_details
  
    

def prob_AN(in_data):
    work_to_look = "MOJO"
    lines = in_data.split("\n")
    reverses_words = list(zip(*lines))
    reverses_row_col = ["".join(w) for w in reverses_words]
    found_word, details = _look_for_word(lines, work_to_look)
    if not found_word:
        found_word, details = _look_for_word(reverses_row_col, work_to_look, reversed_word=True)
        
    if not found_word:
        return
    
    if found_word in [work_to_look]:
        msg = "\n".join(details)
    else:
        msg = "\n".join(details[::-1])
    
    print(msg)
    
           

if __name__ == "__main__":
    in_data = read_input_data()
    prob_AN(in_data)
    

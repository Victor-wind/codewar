# Easy to understand. 10-30 seconds

if __name__ == "__main__":
    print("We bid welcome to the ladies of Beauxbaton and our friends from the north, the sons of Durmstrang.")
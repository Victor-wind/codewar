# -*- coding: utf-8 -*-

import sys


def read_input_data():
    in_data = sys.stdin.read().strip()
    return in_data


def prob_AH():
    (size, unit) = in_data.split(" ")
    size = int(size)
    byte_converstion = {
        "ZB": 21,
        "EB": 18,
        "PB": 15,
        "TB": 12,
        "GB": 9,
        "MB": 6,
        "KB": 3       
    }
    
    base_2_table = {
        "ZiB": 1024**7,
        "EiB": 1024**6,
        "PiB": 1024**5,
        "TiB": 1024**4,
        "GiB": 1024**3,
        "MiB": 1024**2,
        "KiB": 1024      
    }   
         
    # convert base-10 to bytes
    bytes_value = size * 10**byte_converstion[unit]
    previous_unit = ""
    
    for unit in ["KiB", "MiB", "GiB", "TiB", "PiB", "EiB", "ZiB"]:
        if bytes_value >= base_2_table[unit]:
            previous_unit = unit
            continue      
        
        if bytes_value < base_2_table[unit]:
            size = bytes_value / base_2_table[previous_unit]
            print(f"{round(size,2)} {previous_unit}")
            return
    

if __name__ == "__main__":
    in_data = read_input_data()
    prob_AH()
    
    
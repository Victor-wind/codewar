# 3 minutes. Instructions are clearer than before

import sys

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()[1:]

    inputText.reverse()

    for line in inputText:
        print(line)
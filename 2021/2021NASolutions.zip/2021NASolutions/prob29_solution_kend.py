# CodeWars 2021 - TicTacMoe
#
# Read the Board.
# Read X or O
# Search for wins for the requested
# Search for wins for the other (to block)

#globals, overwritten during input
debugPrint = False

import sys

XX='X'
OO='O'
EE='.'

g = [(0) for x in range(9)]
routes = [[(0) for x in range(3)] for x in range(8)]
routes[0]=[1,2,3]  # Routes are ordered in numerical order for ordered printing
routes[1]=[1,4,7]
routes[2]=[1,5,9]
routes[3]=[2,5,8]
routes[4]=[3,5,7]
routes[5]=[3,6,9]
routes[6]=[4,5,6]
routes[7]=[7,8,9]
letters=['.','X','O']
#------------------------------------------------------------------------
# print the Grid
def printGrid(g):
    for i in range(3):
        for j in range(3):
            print(g[3*i+j],end='')
        print('')

#------------------------------------------------------------------------
# countGrid
# count one direction, returning X, O, E count
# 1,2,3 = rows. 4,5,6=cols. 7,8=diagonals
def countGrid(g,route):
    counts=[(0) for x in range(3)]  # new 3-element array for empty, X, O
    for i in range(3):
        counts[g[routes[route][i]-1]]+=1    #-1 to index into g array of 0-8
    return counts

#------------------------------------------------------------------------
#  count each of 8 directions for 2 of our move, with an empty
def checkWin(g,z,winCount):
    winPrint=0
    retVal=0
    for route in range(8):
        counts = countGrid(g,route)
        if counts[0]==1 and counts[z]==2: # We can win!!
            if winPrint==0: # First time, print we will win.
                print(letters[z],"WILL WIN IN 1 MOVES")
                winPrint=1
            print(routes[route][0],routes[route][1],routes[route][2])
            retVal=1
    return retVal

#------------------------------------------------------------------------
#  return the empty spot
def findEmpty(route):
    for i in range(3):
        if g[routes[route][i]-1]==0:
            return routes[route][i]
    return 0
#------------------------------------------------------------------------
#  count each of 8 directions for 2 of theirs, with an empty
def checkBlocks(g,z):
    winPrint=0
    retVal=0
    blocks=[]
    locs=[]
    blocksCount=0
    for route in range(8):
        counts = countGrid(g,route)
        if counts[0]==1 and counts[3-z]==2: # Change 2 to 1 or 1 to 2.  They can win!!
            loc=findEmpty(route)
            if blocksCount==0:
                blocks=[route]
                locs=[loc]
            else:
                blocks.append(route)
                locs.append(loc)
            blocksCount+=1
    return blocksCount,blocks,locs

#------------------------------------------------------------------------
# Main program starts here.

# Read in the grid
numEmpty=9
for i in range(3):
    line = sys.stdin.readline().rstrip('\n').rstrip(' ')  
    for j in range(3):
        val=0
        letter=line[j]
        if letter==XX:
            val=1 #X
        elif letter==OO:
            val=2 #O
        g[3*i+j]=val
        if val>0:
            numEmpty -= 1
    if debugPrint:
        printGrid(g)
line = sys.stdin.readline().rstrip('\n').rstrip(' ')
letter=line[0]               # First move
if letter==XX:
    first=1 #X
else:
    first=2 #O
 
# First check for wins
if debugPrint:
    print("Check for wins")
if checkWin(g,first,1) == 1:
    exit()
if numEmpty==1:
    print("GAME WILL BE A TIE")
    exit()

# Now get a list of all ways the opponent can win.  If "empties" are different, they'll win.
if debugPrint:
    print("Now check for blocks")
blkcount,blocks,locs = checkBlocks(g,first)
if blkcount<=1: # We will be able to stop their win
    if numEmpty==2:
        print("GAME WILL BE A TIE")
        exit()
    else:
        print("NOT ENOUGH INFORMATION")
        exit()

# There are at least 2 to block.  If the Empties match, we'll block.  Else we'll lose.
e=locs[0]
diffE = 0
for i in range(1,blkcount):
    if locs[i]!=e:
        diffE=1
if diffE==0: # We will be able to stop their win
    if numEmpty==2:
        print("GAME WILL BE A TIE")
        exit()
    else:
        print("NOT ENOUGH INFORMATION")
        exit()

#They're going to win
print(letters[3-first],"WILL WIN IN 2 MOVES")
for j in range(blkcount):
    print (routes[blocks[j]][0], routes[blocks[j]][1],routes[blocks[j]][2])

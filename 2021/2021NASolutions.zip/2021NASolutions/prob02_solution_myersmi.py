# 5 minutes. They should be consistent.

import math
import sys

if __name__ == "__main__":
    inputText = sys.stdin.read().split()
    height = float(inputText[0])
    rad = float(inputText[1])

    volume = 3.14 * rad * rad * height

    print("{:.2f} cubic inches".format(volume))
## Time Taken: 5 min

import glob, re

def main(data):

    date_dictionary = {}
    total = 0

    for line in data[1:]:
        regex_return = re.search('(?P<key>\d{2}\/\d{2}).*', line)
        dict_key = str(regex_return.group('key'))
        if dict_key in date_dictionary:
            date_dictionary[dict_key] += 1
            if date_dictionary[dict_key] == 2:
                total += 1
        else:
            date_dictionary[dict_key] = 1

    print(total)
    print('duplicates:', end='')
    
    duplicate_string = ''
    for k, val in date_dictionary.items():
        if val > 1:
            duplicate_string += " {}".format(k)
    if not duplicate_string:
        duplicate_string = " None"

    print("{} ".format(duplicate_string), end='')
    print('')


if __name__ == "__main__":
    print("---- JUDGE ----")  
    for file in glob.glob("*judge*in*.txt"):
        print(file)
        data_set = open(file, 'r').read().split('\n')
        print('---------')
        main(data_set)

    print("---- STUDENT ----")    
    for file in glob.glob("*student*in*.txt"):
        print(file)
        data_set = open(file, 'r').read().split('\n')
        print('---------')
        main(data_set)
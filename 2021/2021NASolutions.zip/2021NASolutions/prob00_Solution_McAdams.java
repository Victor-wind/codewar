public class prob00_Solution_McAdams {
	/*
PROBLEM: Welcome, to the Triwizard Tournament!
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 1 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 1 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-16
WHAT IT TESTS: 
    1.) Ability to submit code which runs :D

NOTE: This solution was translated from my original solution in Python, into Java. I did that for the first 15 problems in the packet
so students who only code in Java will have solutions to look at in their native coding language. The algorithms are the same. The only
parts which change are language specific things (such as how to access list elements). I also collapsed some functions out of python
back into the main program in Java, just to save time. By comparing these 15 translated Java programs to their original Python
implementations, you should be able to pull out Java coding from the rest of the Python solutions, if you'd like. The techniques and
coding functionality used should (more or less) stay the same for the rest of the Python solutions I did. I tend to stick to basics
when at all possible: lists, dictionaries, loops, and logic structures. The only one which might get a little tricky going from
Python to Java will be Pirate Parlay(#27). If you get that one working, I will be impressed :)
	 */
	public static void main(String[] args) {
		// ========================================================================
		// Literally all you have to do is print a hard coded string to the screen :)
		// No datasets, no loops, nothing. Just print a string ;)		
		try
		{
			System.out.println("We bid welcome to the ladies of Beauxbaton and our friends from the north, the sons of Durmstrang.");
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
}

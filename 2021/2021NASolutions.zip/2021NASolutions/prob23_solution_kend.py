#
# CodeWars 2021 - Snowman
#
#
import sys

#-----------------------------------
def printTop(s, center):
    # Top or Bottom line - subtract (s+1)/2 from center for padding
    leftPad = int(center-((s+1)/2))
    for i in range(leftPad):
        print(" ",end='')
    for i in range(s):
        print("#",end='')
    print('')

#-----------------------------------
def printSide(s, center, level):
    # Sides.  First level is always (s+1)/2 spaces before/after center. Next is one farther.
    # If level > (s+1)2, then we're going back in
    if level > (s+1)/2:
        level = s+1-level
    leftPad = int(center-(s+1)/2-level)
    centerPad = s+2*(level-1)
    for i in range(leftPad):
        print(" ",end='')
    print("#",end='')
    for i in range(centerPad):
        print(" ",end='')
    print("#")

#-----------------------------------
# Print Snowball
#    Print snowball.  Knowing the maximum snowball size lets us calculate padding
def printSnowball(s,maxBall):
    # Largest Snowball will have (max+1)/2 chars of sides plus the same to reach the center
    # So the center of ALL will be max+1
    center = maxBall+1
    printTop(s,center)
    for i in range(s):
        printSide(s,center,i+1)
    printTop(s,center)

#------------------------------------------------------------------------
# Main program starts here.

textSize = sys.stdin.readline().rstrip('\n').rstrip(' ');
total = int(textSize)
snowballs = [(1) for x in range(total)] 
maxSize=0
# Read in the grid
for i in range(total):
    snowballs[i] = int(sys.stdin.readline().rstrip('\n').rstrip(' '))
    if snowballs[i] > maxSize:
        maxSize = snowballs[i]

for i in range(total):
    printSnowball(snowballs[i],maxSize)

# Took 30ish minutes. Instructions are clear enough. There should be more test inputs.

import sys

def sort_addresses(addresses):
    sorted_add = []

    for address in addresses.keys():
        if sorted_add == []:
            sorted_add.append(address)
            continue
            
        for i in range(len(sorted_add)):
            if addresses[address] < addresses[sorted_add[i]]:
                sorted_add.insert(i, address)
                break
            elif addresses[address] == addresses[sorted_add[i]]:
                if address < sorted_add[i]:
                    sorted_add.insert(i, address)
                    break
                else:
                    sorted_add.insert(i + 1, address)
                    break
        else:
            sorted_add.append(address)

    return sorted_add

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()
    width = int(inputText[0])
    inputText = inputText[1:]

    buildings = {}

    for line in inputText:
        line_list = line.split()
        buildings[line_list[1]] = int(line_list[0])

    tallest = max(buildings.values())

    sorted_addresses = sort_addresses(buildings)

    addr_map = [[" " for x in range(width)] for y in range(tallest + 2)]

    for i, address in enumerate(sorted_addresses):
        addr_map[0][i] = address
        for j in range(1, tallest+2):
            if j <= buildings[address]:
                addr_map[j][i] = "*"
            elif j <= buildings[address] + 1:
                addr_map[j][i] = "~"
    addr_map.reverse()
    for line in addr_map:
        print(''.join(line))


def get_dataset(problem):
    #read and get input file
    with open(r'.\student_datasets\prob'+problem+'-in.txt') as fi:
        input_file=[]
        for line in fi:
            input_file.append(line.rstrip('\n'))
    
    #read output file
    with open(r'.\student_datasets\prob'+problem+'-out.txt') as fo:
        output_file=[]
        for line in fo:
            output_file.append(line.rstrip('\n'))
    
    #display example output
    print('Example output: ')
    for line in output_file:
        print(line)
    
    return input_file


for example in ['BH-1','BH-2','BH-3']:
    input_file=get_dataset(example)
    print('Solution output: ')
    print("{}, the needs of the many outweigh the needs of the few, or the one; live long and prosper.\n".format(input_file[0]))
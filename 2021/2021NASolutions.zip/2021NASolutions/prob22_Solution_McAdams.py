import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probBA' #prob22
# ------------------------------------------------------------------------

'''
PROBLEM: Chef In Need!
DIFFICULTY LEVEL: Intermediate
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 27 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 32 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-11
WHAT IT TESTS: 
    1.) Ability to convert units on multiple sets of data (always best practice is to convert everything into the base unit and work from there!)
    2.) Ability to calculate new amounts based on a base unit, a given unit, a serving size, and starting amount
    3.) Ability to round numbers accurately to 2 decimal places
    4.) Ability to parse numbers split out from a string
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
# GLOBALS
# We'll be using these units in multiple places in the problem, to making 
# them global to avoid passing them around
units_liquid         = ['teaspoon','tablespoon','ounce','cup','pint','quart','gallon']
units_ratio_liquid   = [1         ,3           ,6      ,48   ,96    ,192    ,768     ]
units_dry            = ['teaspoon','tablespoon','cup']
units_ratio_dry      = [1         ,3           ,48   ]
units_weighted       = ['ounce','pound']
units_ratio_weighted = [1      ,16     ]

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 9):
        servings = float(lines[0])
        sauce    = float(GetUnits(lines[2])) #cups
        olive    = float(GetUnits(lines[3])) #tbs
        salt     = float(GetUnits(lines[5])) #tsp
        pepper   = float(GetUnits(lines[6])) #tsp
        onion    = float(GetUnits(lines[7])) #cup
        eggplant = float(GetUnits(lines[9])) #oz
        if (servings == 1):
            for i in range(1,len(lines)):
                print(lines[i])
        else:
            print('WET INGREDIENTS')
            _sauce = ConvertUnits(servings,sauce,'cup',False,False)
            print(f'{_sauce} tomato-sauce')
            _olive = ConvertUnits(servings,olive,'tablespoon',False,False)
            print(f'{_olive} olive-oil')
            print('DRY INGREDIENTS')
            _salt = ConvertUnits(servings,salt,'teaspoon',True,False)
            print(f'{_salt} salt')
            _pepper = ConvertUnits(servings,pepper,'teaspoon',True,False)
            print(f'{_pepper} black-pepper')
            _onion = ConvertUnits(servings,onion,'cup',True,False)
            print(f'{_onion} onion')
            print('WEIGHTED INGREDIENTS')
            _eggplant = ConvertUnits(servings,eggplant,'ounce',False,True)
            print(f'{_eggplant} eggplant')
    else:
        print('** ERROR ** data file is malformed')
def GetUnits(line):
    'grabs the first part of a given line, split on spaces (assumes the line will not be empty)'
    parts = str(line).strip().split(' ')
    return parts[0]
def PullUnits(unit,isDry,isWeighted):
    '''Does a deep copy of the lists for unit
    names and their ratios to their base unit
    based on what type of units are in question
    then returns those deep copies. Doing this
    avoids having to use copy/paste code in
    out main conversion function'''
    unit_names = []
    unit_ratio = []
    if (isDry):
        for i in range(0,len(units_dry)):
            unit_names.append(units_dry[i])
            unit_ratio.append(units_ratio_dry[i])
    elif (isWeighted):
        for i in range(0,len(units_weighted)):
            unit_names.append(units_weighted[i])
            unit_ratio.append(units_ratio_weighted[i])
    else:
        for i in range(0,len(units_liquid)):
            unit_names.append(units_liquid[i])
            unit_ratio.append(units_ratio_liquid[i])
    return [unit_names,unit_ratio]
def ConvertUnits(servings,amount,unit,isDry,isWeighted):
    '''Pulls the units for the conversion, drops the 
    given measurements to the base units then converts 
    after calculating the new amounts'''
    result = ''
    units = PullUnits(unit,isDry,isWeighted)
    unit_names = units[0]
    unit_ratio = units[1]
    idx = unit_names.index(unit)
    baseUnit = unit_ratio[idx]
    newAmount = servings * amount * baseUnit
    newUnit = unit_names[0]
    for j in range(0,len(unit_names)):
        if (newAmount >= unit_ratio[j]):
            newUnit = unit_names[j]
    newAmount = format(round(newAmount / unit_ratio[unit_names.index(newUnit)],2),'.2f')
    result = f'{newAmount} {newUnit}'
    return result

# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    # counter = -1
    for file in files:
        if ('in.txt' in file):
            # counter +=1
            # print('')
            # print('')
            # print(f'{DATASET} {counter}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

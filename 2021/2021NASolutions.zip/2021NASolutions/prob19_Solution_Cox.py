import sys

#could use supplied text file instead of these dictionaries
iron = {'iron': 1, 'hulk': 1.4, 'spider': 1.7, 'captain': 1.7, 'thor': 1.4, 'black': 1.7, 'hawkeye': 1.7}
hulk = {'iron': 1.2, 'hulk': 1, 'spider': 1.5, 'captain': 1.7, 'thor': 1.8, 'black': 1.4, 'hawkeye': 1.6}
spider = {'iron': 2.0, 'hulk': 1.3, 'spider': 1, 'captain': 1.7, 'thor': 1.2, 'black': 1.3, 'hawkeye': 1.1}
captain = {'iron': 1.6, 'hulk': 1.5, 'spider': 1.7, 'captain': 1, 'thor': 1.6, 'black': 1.8, 'hawkeye': 1.8}
thor = {'iron': 1.7, 'hulk': 1.9, 'spider': 1.2, 'captain': 1.4, 'thor': 1, 'black': 1.4, 'hawkeye': 1.3}
black = {'iron': 1.7, 'hulk': 1.9, 'spider': 1.4, 'captain': 1.3, 'thor': 1.4, 'black': 1, 'hawkeye': 2.0}
hawkeye = {'iron': 1.7, 'hulk': 1.6, 'spider': 1.1, 'captain': 1.8, 'thor': 1.3, 'black': 2.0, 'hawkeye': 1}

line = sys.stdin.readline().rstrip('\n').rstrip(' ')

#note the last item will be TA
avenger = []
power = []
flag_avenger_strength = False
total_avenger_strength = 0

def has_numbers(inputString):
    return any(char.isdigit() for char in inputString)

while(line):
    words = line.split(',')
    for x in range(0, 6):
        
        avenger_power = words[x].lstrip().split(' ')
        avenger.append(avenger_power[0])
        power.append(avenger_power[1])
        if(not has_numbers(power[x])):
            power[x] = avenger_power[2]

    for x in range(0,5):
        avenger_strength = float(power[x])
        for y in range(0,5):
            if avenger[x].lower() == 'iron':
                avenger_strength = avenger_strength * float(iron.get(avenger[y].lower()))
                flag_avenger_strength = True
            if avenger[x].lower() == 'hulk':
                avenger_strength = avenger_strength * float(hulk.get(avenger[y].lower()))
            if avenger[x].lower() == 'spider':
                avenger_strength = avenger_strength * float(spider.get(avenger[y].lower()))
            if avenger[x].lower() == 'captain':
                avenger_strength = avenger_strength * float(captain.get(avenger[y].lower()))
            if avenger[x].lower() == 'thor':
                avenger_strength = avenger_strength * float(thor.get(avenger[y].lower()))
            if avenger[x].lower() == 'black':
                avenger_strength = avenger_strength * float(black.get(avenger[y].lower()))
            if avenger[x].lower() == 'hawkeye':
                avenger_strength = avenger_strength * float(hawkeye.get(avenger[y].lower()))
        total_avenger_strength += avenger_strength

    total_avenger_strength =  int(round(total_avenger_strength, 0))
    if total_avenger_strength == int(power[5]):
        print ("Draw " + str(total_avenger_strength) + "-" + power[5])
    elif total_avenger_strength > int(power[5]):
        print ("Avengers win! " + str(total_avenger_strength) + "-" + power[5])
    else:
        print ("Thanos's Army wins! " + power[5] + "-" + str(total_avenger_strength))
    line = sys.stdin.readline().rstrip('\n').rstrip(' ')

#
# Garbage Collection.
#
#   You will receive a complete map of a room with garbage.
# The first line will be an integer N (from 5 to 10), the size of the square room.
# The next N lines each list N squares.
# The squares are marked with either ".." (empty) or "<>" (garbage). 
# Squares are separated by a single space.  The count of garbage-squares will be less than 30.
# Re-print the map, replacing each garbage-square with a number showing the order of collecting the garbage.
# For a 1-digit number, use a space followed by the digit.
#   There is only one solution.
#
# The original App (100 Logic Games 2, Zen Solitaire) was about picking up stones,
# so I'm referring to stones below, instead of garbage.
#

debugPrint = False
mainGrid = [[(-1) for x in range(11)] for x in range(11)] # 11x11 array (max is 10, so ... wiggle room)
gridSize = 11
stoneCount = 0

import sys

#-----------------------------------
# Initialize a new grid
def initGrid():
	g = [[(-1) for x in range(11)] for x in range(11)]
	return g

#-----------------------------------
# Print the Grid
def printGrid(g):
	for i in range(gridSize):
		for j in range(gridSize):
			val = g[i][j]
			if val == -1: # ..
				print("..", sep='', end='')
			elif val < 10:
				print(" ", val, sep='', end='')
			else:
				print(val, sep='', end='')
			if j < gridSize-1:
				print(" ", sep='', end='') #Space between squares:wc
		print ('')

#----------------------------------------
# isStone
#   checks the direction from the provided grid square for any available stones (zeros)
# Up/Right/Down/Left = 0/1/2/3
# Returns location r,c of an un-numbered (0) stone in that direction
def isStone(g,r,c,d):
	rdiff=0
	cdiff=0
	if d==0:
		rdiff=-1
	elif d==1:
		cdiff=1
	elif d==2:
		rdiff=1
	elif d==3:
		cdiff=-1
	else:
		return -1, -1
	r += rdiff
	c += cdiff
	while (r >=0 and r<gridSize and c>=0 and c<gridSize):
		if g[r][c] == 0: #Found an unused stone
			return r, c
		r += rdiff
		c += cdiff
	return -1, -1

#----------------------------------------
# isExit returns 1 if the direction from the provided grid square has a 0 stone
def isExit(g,r,c,d):
	r,c = isStone(g,r,c,d)
	if r > -1:
		return 1
	return 0
	

#----------------------------------------
# Count Exits
def exitCount(g,e):
	for i in range(gridSize):
		for j in range(gridSize):
			if g[i][j] > -1 :
				e[i][j] = isExit(g,i,j,0) + isExit(g,i,j,1) + isExit(g,i,j,2) + isExit(g,i,j,3)

#------------------------------------------------------------------------
# Solve - using the provided grid, row, column, stoneValue, entrance direction
#   Search clockwise to find the next 0-stone
def solve(g,r,c,val,dir):
	g[r][c] = val
	if val == stoneCount:		# We're done!!
		printGrid(g)			# Print and ...
		exit					# Quit the program!
		
	# Otherwise we're still searching
	loops = 4   				# 4 loops occurs only for the first stone
	newDir = (dir+1)%4			# Start one turn clockwise from entrance direction
	while loops > 0:			
		if newDir == dir:		# Exit when we've returned to our entrance direction
			loops = 0
		else:					# Otherwise, look for the next stone
			newR,newC = isStone(g,r,c,newDir)
			if newR > -1:		# Found one!  Recursively call to find the next
				solve(g,newR,newC,val+1,(newDir+2)%4)  #Mod 4 the direction to keep it from 0 to 3
			loops -= 1
		newDir = (newDir+1)%4	# Rotate to check the next direction clokwise
	g[r][c] = 0					# Restore the stone as unused before exiting
	return
		

#------------------------------------------------------------------------
# Main program starts here.

textSize = sys.stdin.readline().rstrip('\n').rstrip(' ');
gridSize = int(textSize)

# Read in the grid
for i in range(gridSize):
	line = sys.stdin.readline().rstrip('\n').rstrip(' ')  # ".." = space.  "<>" = garbage.
	if debugPrint:
		print(line)
	words = line.split(' ')
	for j in range(gridSize):
		square = words[j]
		if square != "..":    # not empty, count and mark a stone with a zero
			stoneCount += 1
			mainGrid[i][j] = 0

# Debug Print the starting values
if debugPrint:
	print('')
	print('StoneCount:', stoneCount)
	print ('Initial Grid:')
	printGrid(mainGrid)

# Count and set Exit Counts for each stone, to find the possible starts
e=initGrid()
exitCount(mainGrid, e)

if debugPrint:
	print('')
	print("Exit Grid:")
	printGrid(e)
	print('')

# From each "1" Exit-count, start the search
for i in range(gridSize):
	for j in range(gridSize):
		if e[i][j] == 1:
			solve(mainGrid,i,j,1,-1)	# Sending -1 as a direction, allows searching all dirs from start stone

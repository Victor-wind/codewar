#!/bin/python3

import sys

PI = 3.14

def parse_inputs():
    for line in sys.stdin:
        height, radius = line.split()
        # print ("height = %s" % height)
        # print ("Radius = %s" % radius)
        return float(height), float(radius)

def volume(height, radius):
    return (float(PI*radius*radius*height))

def solution():
    radius, height = parse_inputs()
    vol = volume(radius, height)
    print (round(vol,2), "cubic inches")

    
if __name__ == '__main__':
    solution()

#include <stdio.h>
#include <stdlib.h>

#define nl() putchar('\n')
int offset=0;
int *rad;
int n;
void re(c,n)char c; int n;{int i; for(i=0;i<n;i++) putchar (c);}
void po(s)int s; {re(' ',2*(offset-s+1));}

void ball(n) int n; {
int i,j,s;
s=n/2+1;
po(s);re(' ',s);re('#',n);nl();
for(j=0;j<s;j++) {
 po(s); re(' ',s-j-1); re('#',1); re(' ',n+2*j); re('#',1);nl();
}
for(j=s-2;j>=0;j--) {
 po(s); re(' ',s-j-1); re('#',1); re(' ',n+2*j); re('#',1);nl();
}
po(s);re(' ',s);re('#',n);nl();
}

int main(argc,argv) int argc; char **argv; {
int i;
int max=0;
scanf("%d",&n);
rad=malloc(sizeof(int)*n);
for(i=0;i<n;i++) {
 scanf("%d",&rad[i]);
 if(max<rad[i]) max=rad[i];
 }
offset=max/2;
for(i=0;i<n;i++)
 if(rad[i])
  ball(rad[i]);
 }

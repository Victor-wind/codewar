import sys

'''
    When can we assume a new day?
    For instance 23:55 23:00 as iputs?
'''

#for roll over of day
minutes_in_day = 1440

line = sys.stdin.readline().rstrip('\n').rstrip(' ')

while(line):

    #starting width = 25 spaces(5m or 500cm), where each space equal 20cm
    #the 40 seconds the droids take to act costs an additional 40cm
    width = 500 - 40
    
    words = line.split(' ')
    h1, m1 = words[0].split(':')
    h2, m2 = words[1].split(':')
    time1 = (int(h1) * 60) + int(m1)
    time2 = (int(h2) * 60) + int(m2)

    #handle roll of clock
    if time2 < time1:
        time2 += minutes_in_day

    minutes_lost = time2 - time1

    width = width - (minutes_lost * 60)
    if width < 0:
        width = 0

    # 1 space = 20cm
    spaces_width = width / 20

    #print the height of the garbage masher walls
    for x in range(0, 6):
        print("|", end='')
        #print the width of the garbage masher walls
        masher_width = ' ' * int(spaces_width)
        print(masher_width + "|")

    if width < 20:
        print("CURSE MY METAL BODY, I WASN'T FAST ENOUGH!")
        
    line = sys.stdin.readline().rstrip('\n').rstrip(' ')

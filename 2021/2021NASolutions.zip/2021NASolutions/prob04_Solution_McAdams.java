import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
public class prob04_Solution_McAdams {
/*
PROBLEM: You're Doing My Ears A Favor
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 2 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 5-10 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-11
WHAT IT TESTS: 
    1.) Ability to edit string data to preserve whitespace while removing line-ending characters
    2.) Ability to either reverse the lines of input, or x-swap map the characters in the input as a 2D map (please don't do this)
    3.) Ability to handle looping data
    4.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
    
NOTE: This solution was translated from my original solution in Python, into Java. I did that for the first 15 problems in the packet
so students who only code in Java will have solutions to look at in their native coding language. The algorithms are the same. The only
parts which change are language specific things (such as how to access list elements). I also collapsed some functions out of python
back into the main program in Java, just to save time. By comparing these 15 translated Java programs to their original Python
implementations, you should be able to pull out Java coding from the rest of the Python solutions, if you'd like. The techniques and
coding functionality used should (more or less) stay the same for the rest of the Python solutions I did. I tend to stick to basics
when at all possible: lists, dictionaries, loops, and logic structures. The only one which might get a little tricky going from
Python to Java will be Pirate Parlay(#27). If you get that one working, I will be impressed :)
*/
	//------------------------------------------------------------------------
	// CHANGE THIS BEFORE SUBMITTING!
	private static final boolean AM_DEBUGGING = true;
	private static final boolean DATA_STUDENT = false;
	private static final String DEBUG_PROB_ID = "prob04";
	private static final int DEBUG_PROB_IN = 1;
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";
	private static final boolean DEBUG_MODE_ALL = true;
	//------------------------------------------------------------------------
	public static void main(String[] args) {
		try
		{
			GetData();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void MainProgram(List<String> lines) {
		for (int i=lines.size()-1;i>0;i--) {
			print(lines.get(i));
		}
	}
	private static List<String> inputFromStdIn() {
		List<String> lines =new ArrayList<String>();
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static void GetData() throws IOException {
		String dataset = "student";
		if (!DATA_STUDENT) {
			dataset = "judge";
		}
		if (AM_DEBUGGING) {
			if (DEBUG_MODE_ALL) {
				List<String> datasets =new ArrayList<String>();
				File datasetFolder = new File(DEBUG_PATH+"\\"+dataset+"_datasets\\");
				File[] files = datasetFolder.listFiles();
				for (File f:files) {
					if (f.isFile()) {
						if (f.getName().indexOf(DEBUG_PROB_ID) > -1 && f.getName().indexOf("in") > -1)
						{
							datasets.add(f.getName());
						}
					}
				}
				for (String file: datasets) {
					print("--------------------------------------------------------------------------------------");
					print("DEBUGGING OUTPUT FOR: "+file);
					MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+file).toPath()));
				}
			}
			else {
				MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+DEBUG_PROB_ID+
						"-"+DEBUG_PROB_IN+"-in.txt").toPath()));
			}
		}
		else{
			MainProgram(inputFromStdIn());
		}
	}
	private static void print(String s) {
		//shortcut for moving back and forth between Python (and, also, (and I cannot stress this enough), I hate typing out the full System.out.println() ceremony every time
		System.out.println(s);
	}
}

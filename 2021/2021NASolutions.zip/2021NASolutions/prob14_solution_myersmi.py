# Easy. 15ish minutes. Instructions are pretty straightforward

from fractions import Fraction
import sys

one_dynamite_weight = 0.45  # kg
kg_of_dynamite_force = 7.5  # MJ

def calc_dynamite_force(num, size):
    total_sticks = num * size

    return (total_sticks * one_dynamite_weight) * kg_of_dynamite_force

if __name__ == "__main__":
    inputText = sys.stdin.read().split()
    num = Fraction(inputText[0])
    size = Fraction(inputText[1])
    limit = Fraction(inputText[2])

    explosive_force = calc_dynamite_force(num, size)

    text = ""
    if explosive_force > limit:
        text = "the Mask should not eat it!"
    else:
        text = "the Mask can eat it!"
    print("{:.2f} {}".format(explosive_force, text))

#!/bin/python3

import sys

def parse_inputs():
    map_list = []
    y = 0  # line num
    for line in sys.stdin:
        try:
            x = line.strip().index('P')
            # print ("cordinates", x, y)
            return x,y
        except:
            pass
        map_list.append(line.strip())
        y += 1
    print (map_list)
    raise ValueError

def solution():
    try:
        x, y = parse_inputs()
        print("Ace, move fast, pigeon is at (%d, %d)" % (x,y))
    except:
        print("No pigeon, try another map, Ace")

    
if __name__ == '__main__':
    solution()

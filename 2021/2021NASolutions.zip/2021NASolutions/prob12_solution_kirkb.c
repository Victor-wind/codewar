#include <stdio.h> 
#include <string.h>
#include <math.h>
#define BUF 256
#define LUS 7
#define TUS 3

char   *lun[LUS] = {"MILES", "KILOMETERS", "YARDS", "FEET", "METERS", "INCHES", "CENTIMETERS"};
double luf[LUS] = {1609.34, 1000.0, 0.9144, 0.3048, 1.0, 0.0254, 0.01};

char *tun[TUS] = {"HOUR", "MINUTE", "SECOND"};
double tuf[TUS] = {3600.0,60.0,1.0};

int main(argc,argv) int argc; char **argv; {
char name[BUF],tu[BUF],lu[BUF];
double r;
double h;
int t,l;

scanf("%s %lf %s %s %s",name,&r,lu,tu,tu);
for(t=0;t<TUS;t++) if(strcmp(tun[t],tu)==0) break;
for(l=0;t<LUS;l++) if(strcmp(lun[l],lu)==0) break;

r=r*luf[l]/tuf[t];
h=r*r/(2*9.805);

printf("%s will launch the message %.2lf meters high, ",name,h);
if(h>50.0) printf("OUCH!\n");
if((h>25.0)&&(h<50.0)) printf("SUCCESS!\n");
if(h<25.0) printf("SPLAT!\n");
}

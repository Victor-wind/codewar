# took about 5-10 minutes

import sys

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()

    dates = []
    dupe_dates = []

    for i, full_date in enumerate(inputText):
        date = full_date[:5]
        if i == 0:
            continue
        if date in dates:
            if date not in dupe_dates:
                dupe_dates.append(date)
        else:
            dates.append(date)

    print(len(dupe_dates))
    print("duplicates: {}".format(' '.join(dupe_dates)))
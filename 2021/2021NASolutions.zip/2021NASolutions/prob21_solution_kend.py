# CodeWars 2021 - Where's my Mojo
#
# Read the Maze. 
# G - a door that opens (-3)
# R - a door that closes (-2)
# Flood the maze from B to F.  If you reach R/G change it to wall or path and use it as such.
# Record the path in reverse order.
# Translate path to compass directions

#globals
debugPrint = False

import sys

def OJOcheck(g,r,c,rd,cd):
    if g[r+rd][c+cd]=='O' and g[r+2*rd][c+2*cd]=='J' and g[r+3*rd][c+3*cd]=='O':
        return True
    return False

def OJOcoords(r,c,rd,cd):
    return r+rd,c+cd,r+2*rd,c+2*cd,r+3*rd,c+3*cd
#------------------------------------------------------------------------
def printMojo(a,b,c,d,e,f,g,h): # Problem wants column before row, so swap each.
    print("M: ",b ,",",a,sep='')
    print("O: ",d ,",",c,sep='')
    print("J: ",f ,",",e,sep='')
    print("O: ",h ,",",g,sep='')
#------------------------------------------------------------------------
# Return coords for O,J,O  (Diagonal check isn't required for solution, but it's here.
def findOJO(g,r,c):
    # Special Case first
    if c<width-1 and r<height-1:
        if g[r][c+1]=='O' and g[r+1][c]=='J' and g[r+1][c+1]=='O':
            return r,c+1,r+1,c,r+1,c+1
    #Now straight lines
    
    if r<=height-4:  #Down
        rd=1
        cd=0
        if OJOcheck(g,r,c,rd,cd):
            return OJOcoords(r,c,rd,cd)
        if c>=3: #Down-Left
            cd=-1
            if OJOcheck(g,r,c,rd,cd):
                return OJOcoords(r,c,rd,cd)
        if c<=width-4: #Down-Right
            cd=+1
            if OJOcheck(g,r,c,rd,cd):
                return OJOcoords(r,c,rd,cd)
    if r>=3: # Up
        rd=-1
        cd=0
        if OJOcheck(g,r,c,rd,cd):
            return OJOcoords(r,c,rd,cd)
        if c>=3: #Up-Left
            cd=-1
            if OJOcheck(g,r,c,rd,cd):
                return OJOcoords(r,c,rd,cd)
        if c<=width-4: #Up-Right
            cd=+1
            if OJOcheck(g,r,c,rd,cd):
                return OJOcoords(r,c,rd,cd)
    if c>=3: #Left
        rd=0
        cd=-1
        if OJOcheck(g,r,c,rd,cd):
            return OJOcoords(r,c,rd,cd)
    if c<=width-4: #Right
        rd=0
        cd=1
        if OJOcheck(g,r,c,rd,cd):
            return OJOcoords(r,c,rd,cd)
    # No match, return -1s
    return -1,-1,-1,-1,-1,-1

#------------------------------------------------------------------------
# Main program starts here.
height=0
while height>=0:
    line     = sys.stdin.readline().rstrip('\n').rstrip(' ');
    if line=="": # File is done
        break
    if height==0:
        g=[line]
        width=len(line)
    else:
        g.append(line)
    height += 1
if debugPrint:
    print(g)

for i in range(height):
    for j in range(width):
        if g[i][j]=='M':
            Orow1,Ocol1,Jrow,Jcol,Orow2,Ocol2 = findOJO(g,i,j)
            if Orow1>-1: #Found it.  Print!
                printMojo(i,j,Orow1,Ocol1,Jrow,Jcol,Orow2,Ocol2)
                exit()

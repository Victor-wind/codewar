#!/bin/python3
# solved by karthik.r@hpe.com


import sys
import re

def parse_inputs():
    sizes = []
    for line in sys.stdin:
        sizes.append(int(line.rstrip()))
    count = sizes.pop(0)
    # print(count, len(sizes))
    assert count == len(sizes)
    return sizes
    
    
def print_circle(offset, size): 
    
    mid = int(size/2)
    left_space = offset +1
    middle_space = size
    
    #print("Offset = %d Size = %d mid = %d" % (offset, size, mid))
    
    print(left_space*' ' + '#'*size)
    left_space -= 1
    for i in range(mid):                
        print(left_space*' ' + '#' + ' '*middle_space + '#')
        left_space -= 1
        middle_space += 2

    for i in range(mid, size):        
        print(left_space*' ' + '#' + ' '*middle_space + '#')
        left_space += 1
        middle_space -= 2
    
    
    print(left_space*' ' + '#'*size)
    
    
def solution():
    sizes = parse_inputs()
    max_val = max(sizes)*2 +1
    for size in sizes:
        offset = int((max_val- size)/2)        
        print_circle(offset, size)
    
if __name__ == '__main__':
    solution()

# It's not clear whether the material or the surface should be first.
# 10ish minutes. Fairly easy

import sys
import math

materials = {
    "RUBBER":0,
    "WOOD":1,
    "STEEL":2
}

surface_coefficients = {
    "CONCRETE": [0.90, 0.62, 0.57],
    "WOOD": [0.80, 0.42, 0.30],
    "STEEL": [0.70, 0.30, 0.74],
    "RUBBER": [1.15, 0.80, 0.70],
    "ICE": [0.15, 0.05, 0.03]
}

if __name__ == "__main__":
    inputText = sys.stdin.read().split()

    material = inputText[0]
    surface = inputText[1]

    coeff = surface_coefficients[surface][materials[material]]
    print("{:.2f} {:.1f}".format(coeff, math.degrees(math.atan(coeff))))
# took like 10 minutes. 

import sys

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()

    F = inputText[0].split()[1]
    K = inputText[1].split()[1]
    X = inputText[2].split()[1]

    if F == "?":
        K = float(K)
        X = float(X)
        F = K * X * -1
        print("F {:.2f}".format(F))
    elif K == "?":
        F = float(F)
        X = float(X)
        K = F / X * -1
        print("K {:.2f}".format(K))
    else:
        F = float(F)
        K = float(K)
        X = F / K * -1
        print("X {:.2f}".format(X))

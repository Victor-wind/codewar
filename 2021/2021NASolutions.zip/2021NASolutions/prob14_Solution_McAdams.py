import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAU' #prob14
# ------------------------------------------------------------------------

'''
PROBLEM: Smokin'!
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 10 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 14 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-08
WHAT IT TESTS: 
    1.) Ability to handle fractional data in math operations as well as whole integers
    2.) Ability to split string data
    3.) Ability to run calculations according to a formula
    4.) Ability to extrapolate how to get the final force (we don't hold their hand on this one, they have to figure out how to apply the numbers given - hence the extra point on this problem ^_-)
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 0):
        # Math ... amirite? (╯° °）╯︵ ┻━┻

        # Relevant info from problem:
        # 1 whole stick of dynamite weighs 0.45 kilograms (kg)
        # 7.5MJ of explosive force are released when 1kg of dynamite explodes.
        # Yes ... I *am* worried that I am on some sort of DHS list now 
        # after looking up those numbers for you. The things I suffer for CodeWars ... ^^;

        # input format: N M YY
        # N  =  number of sticks
        # N  =  size of stick
        # YY = damage mask can sustain as a tensile limit with respect to force as MJ (if you haven't had physics yet, then ... *MAGIC!*)

        # Biggest problem with this problem (heh) is the fractional sizes.
        # Without those things there this would be a very simple math problem.
        # But we're going to have to convert the whole number fractions to decimal
        # values if we get them. Other than that, the problem is simply: figure out
        # how many kilograms (kg) of dynamite we have, then figure out how much
        # explosive force that amount of dynamite would generate (note that LESS 
        # than 1kg of dynamite is what we give for the MJ generated, a little more math
        # will have to be done by the students to get the final numbers), then compare
        # that to the amount of force the Mask can currently withstand. If the dynamite
        # will produce less than or equal to the force the Mask can withstand, then
        # print the success message. Else, print the "run away! ε=ε=┏( >_<)┛" message
        parts = lines[0].strip().split(' ')
        if (len(parts) > 2):
            sticks = int(parts[0])
            size = 0
            if ('/' in parts[1]):
                fraction = parts[1].strip().split('/')
                if (len(fraction) > 1 and fraction[1].strip() != '0'):
                    size = int(fraction[0]) / int(fraction[1])
            else:
                size = int(parts[1])
            limit = int(parts[2])
            dynamite = sticks * size
            force = (dynamite*0.45) * 7.5
            forcePrint = format(round(force,2),'.2f')
            if (force <= limit):
                print(f'{forcePrint} the Mask can eat it!')
            else:
                print(f'{forcePrint} the Mask should not eat it!')
        else:
            print('** ERROR ** data file is malformed')
    else:
        print('** ERROR ** data file is malformed')
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    # counter = -1
    for file in files:
        if ('in.txt' in file):
            # counter +=1
            # print('')
            # print('')
            # print(f'example {counter}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

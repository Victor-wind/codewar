# some trial and error. 35ish minutes. Instructions were clear. Examples were helpful.

import sys

if __name__ == "__main__":
    untouched_wall = []
    damaged_wall = "#"

    inputText = sys.stdin.read().split()

    height = int(inputText[0])
    punch_height = int(inputText[1])
    strength = int(int(inputText[2])/10)

    if punch_height == 0:
        punch_height = -1
        wall_left = height - 1
    elif punch_height > height:
        punch_height = -1
        wall_left = height - 1
    else:
        wall_left = punch_height - 2

    for i in range(wall_left):
        untouched_wall.append("#")

    if punch_height != -1:
        for i in range(strength):
            damaged_wall += "."

        for i in range(height-(punch_height-1)):
            damaged_wall += "#"

    for section in untouched_wall:
        print(section)

    print(damaged_wall)
#include <stdio.h>
#include <stdlib.h>

#define DIM 10
#define EMPTY 0
#define MIN 1
#define MAX 4
//int CHECKIT=90;
//int trials=0;
int board[DIM][DIM];
int final[DIM][DIM];
int dim;
int flag;
//int best=0;

int done(){
int i;
int f;
for(i=0,f=1;i<dim*dim;i++)
 f=f&&final[i/dim][i%dim];
return(f);
}

int legal(minr,minc,maxr,maxc)int minr,minc,maxr,maxc; {
int r,c;
int f=1;
int v[DIM*DIM];
int i,m;

int lr=0,ur=dim,lc=0,uc=dim;

lr=(minr<0)?0:minr; ur=(maxr>dim)?dim:maxr;
lc=(minc<0)?0:minc; uc=(maxc>dim)?dim:maxc;


for(r=lr;f&&(r<(ur-1));r++)
 for(c=lc;f&&(c<(uc-1));c++)
  if(board[r][c]&&board[r][c+1]&&board[r+1][c]&&board[r+1][c+1]) {
   for(i=0;i<DIM*DIM;i++) v[i]=0;
   v[final[r][c]]++;
   v[final[r+1][c]]++;
   v[final[r][c+1]]++;
   v[final[r+1][c+1]]++;
   for(i=m=0;i<DIM*DIM;i++)
    m=(v[i]>m)?v[i]:m;
  f=f&&(m>1);
  }
for(r=lr;f&&(r<ur);r++)
 for(c=lc;f&&(c<uc);c++) {
  if(board[r][c]&&((c+1)<dim)&&(board[r][c]==board[r][c+1]))
   f=f&&(final[r][c]==final[r][c+1]);
  if(board[r][c]&&((r+1)<dim)&&(board[r][c]==board[r+1][c]))
   f=f&&(final[r][c]==final[r+1][c]);
 }
return f;
}

void complete(){
int i;
//printf("trials=%d\n",trials);
for(i=0;i<dim*dim;i++)
 printf("%1d%s",board[i/dim][i%dim],(i+1)%dim?"":"\n");
}

void dump(){
int i;
printf("board[%d][%d]=",dim,dim);
for(i=0;i<dim*dim;i++)
 printf("%2d",board[i/dim][i%dim]);
printf("\n");

for(i=0;i<dim*dim;i++)
 printf("%2d%s",board[i/dim][i%dim],(i+1)%dim?" ":"\n");
printf("final[%d][%d]=\n",dim,dim);
for(i=0;i<dim*dim;i++)
 printf("%2d%s",final[i/dim][i%dim],(i+1)%dim?" ":"\n");
}

int open(r,c,dr,dc) int r,c,dr,dc; {
int f=1;
int R,C;
for(R=0;R<=dr*(board[r][c]-1);R++)
 for(C=0;C<=dc*(board[r][c]-1);C++)
  f = f &&
  ((r+R)<dim) &&
  ((c+C)<dim) &&
  ((board[r+R][c+C]==0)||((board[r+R][c+C]==board[r][c])&&(!final[r+R][c+C])));
return f;
}

#define VECS 2
void play(d,p,l) int d,p,l; {
int r,c;
int i;
int temp[4];
int v;
int x;
int m;

//trials++;
r=p/dim;
c=p%dim;

//if(d==CHECKIT)
// printf("CHECK\n");

//if(d>=best) {best=d; printf("best: %d\n",best);dump();}

//if(flag>2) printf("play(%d,%d,%d)\n",d,p,l);
//if(flag>2) dump();

if(done()) {
 complete();
//dump();
 exit(0);
} 
x=board[r][c];
if(final[r][c])
 play(d+1,p+1,l);
else for(m=MAX;m>=MIN;m--) {
 if(x&&(m!=x)) continue;
 board[r][c]=m;
 for(v=0;v<((m==1)?1:2);v++)
  if(open(r,c,v,!v)) {
   final[r][c]=l;
   for(i=0;i<board[r][c];i++){ 
    temp[i]=board[r+v*i][c+!v*i];
    board[r+v*i][c+!v*i]=board[r][c];
    final[r+v*i][c+!v*i]=l;
   }
   if(legal(r-1,c-1,r+v*m+1,c+!v*m+1)) 
    play(d+1,p+1,l+1);
   for(i=0;i<board[r][c];i++){ 
    board[r+v*i][c+!v*i]=temp[i];
    final[r+v*i][c+!v*i]=EMPTY;
    }
   final[r][c]=EMPTY;
  }
}
board[r][c]=x;
}

int main(argc,argv) int argc; char **argv; {
int i=0;
char c;
flag=argc;
scanf("%d",&dim);
while((c=getchar())!=EOF) {
 switch(c) {
  case '1':
  case '2':
  case '3':
  case '4':
   board[i/dim][i%dim]=c-'0';
   final[i/dim][i%dim]=0;
   i++;
   break;
  case '.':
   final[i/dim][i%dim]=board[i/dim][i%dim]=0;
   i++;
   break;
 }
}
play(0,0,11);
}

import sys
import time
import math
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAE' #prob15
# ------------------------------------------------------------------------

'''
PROBLEM: Everypony line up!
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 9 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 12 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-01-31
WHAT IT TESTS: 
    1.) Ability to sort a list/array of data (either manually or through library functions)
    2.) Ability to sort and combine two separate lists/arrays
    3.) Ability to look up ranking/value/index of items in a list/array
    4.) Ability to use dictionaries, or similar structures, to organize groups of data
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))

# ========================================================================
def Main(lines=[]):
    'Main Program'
    #taking the easy/lazy way out and just throwing up a dict. with all of the possible combinations
    gems = ['Lapis','Topaz','Tourmaline','Sapphire','Peridot','Ruby','Pearl','Emerald','Diamond','Aquamarine','Amethyst','Garnet']
    if (len(lines) > 0):
        #setup a list for both types of ponies. Regular ponies just get sorted. Royal ponies have an extra step
        regularPonies = []
        royalPonies = []
        for pony in lines:
            pony = pony.strip()
            if (pony != 'END'):
                #split the name into parts on the space character
                nameParts = pony.split(' ')
                #look at each part of the name, and compare it to the gems list
                #if the name part is in the gems list (as a stand-alone word)
                #then the pony is royal, add them to the royals list
                #else, add them to the regular ponies list
                for part in nameParts:
                    if (part in gems):
                        royalPonies.append(pony)
                        break
                if (pony not in royalPonies):
                    regularPonies.append(pony)
        # simply print the royal list if it is empty or has only one pony in it
        # (the for loop will skip if it is empty)
        if (len(royalPonies) <= 1):
            for pony in royalPonies:
                print(pony)
        else:
            # however, if there is more than one pony in the royal list, now we have
            # a problem. We can't simply sort the list, because we aren't sorting
            # alphabetically, we are sorting by gem stone ranking. There are lots of
            # ways to solve this, including a custom sorting algorithm, but the way
            # I chose to solve this was with a dictionary (hash in other languages)
            # keyed on the gem stone names, with a value of a sorted list of the 
            # ponies matching that gem stone.
            royalsGrouped = {}
            #iterate through the gems list, in order
            for gem in gems:
                tmp = []
                #iterate through the royal ponies we have
                for royal in royalPonies:
                    #if the gem name stands alone (has a space before or after it),
                    #or the entire name of the pony IS the gem name, add it to the list
                    if ((gem+' ') in royal or (' '+gem) in royal or gem == royal):
                        tmp.append(royal)
                # if the list is not empty, sort it, then add the list as the value of
                # a dictionary item keyed to the gem stone name
                if (len(tmp) > 0):
                    tmp.sort()
                    royalsGrouped[gem] = tmp
            # create a list to keep track of ponies already printed
            #(have to do this, or something like this, to account for
            # ponies that have more than one gem stone in their name, as
            # they will show up in the value lists for more than one gemstone)
            royalsPrinted = []
            #iterate through all of the items in the dictionary
            for key, value in royalsGrouped.items():
                for royal in value:
                    # if we haven't already printed the royal pony, 
                    # print it, and add it to the list
                    if (royal not in royalsPrinted):
                        print(royal)
                        royalsPrinted.append(royal)
        # once we are done dealing with the royal ponies, simply sort 
        # the regular ponies and print their list last
        regularPonies.sort()
        for pony in regularPonies:
            print(pony)
    else:
        print('** ERROR ** data file is malformed')

# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)

# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    for file in files:
        if ('in.txt' in file):
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

# took 40ish minutes. One of the harder ones. Instructions are clear, but it isn't obvious how to do it which I think is fine for the point value

import sys

def get_snowball(size):
    snowball = []
    for i in range(size + 2):
        snowball.append("")
        for j in range(size + size + 1):
            if i == 0 or i == size + 2 - 1:
                if j > int(size / 2) and j < size + int(size / 2) + 1:
                    snowball[i] += "#"
                else:
                    snowball[i] += " "
            else:
                if j == int(size / 2) - i + 1 or j == int(size/2) + size + i or j == -1 * int(size / 2) + i - 1 or j == int(size/2) + 2 * size + 1 - i :
                    snowball[i] += "#"
                else:
                    snowball[i] += " "
    return snowball

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()[1:]

    snowballs = []
    largest = -1

    for line in inputText:
        num = int(line)
        snowballs.append(get_snowball(num))
        if num > largest:
            largest = num

    for s, snowball in enumerate(snowballs):
        padding = ''.join([" " for i in range(largest - int(inputText[s]))])
        for line in snowball:
            print("{}{}".format(padding, line))
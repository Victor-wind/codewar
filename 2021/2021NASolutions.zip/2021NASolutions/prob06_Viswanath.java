import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * In case of invalid input(Non upper case alphabets except whitespace),
 * program exits without any output.
 */
public class probBF_Viswanath {

    public static void main(String[] args) {
        char[] charArr = validateInput();
        Map<Character, Character> decodeMap = constructMap();
        for (char ch : charArr) {
            System.out.print(decodeMap.get(ch));
        }
    }

    private static char[] validateInput() {
        Scanner scanner = new Scanner(System.in);
        int cipherLength = scanner.nextInt();
        scanner.nextLine();
        String cipherText = scanner.nextLine();

        //If we don't want user to re-enter text in case of invalid input
        //====BEGIN====
        if (cipherText.length() != cipherLength)
            System.exit(1);

        char[] charArr = cipherText.toCharArray();
        for (char ch : charArr)
            if (!((Character.isAlphabetic(ch) && Character.isUpperCase(ch)) || ch == ' '))
                System.exit(1);
        //====END====

        // if we want to allow user re-enter text in case of invalid input
        // Un-comment below and comment above code between BEGIN and END
        //====BEGIN====
        /*while (cipherText.length() != cipherLength)
        {
            System.out.println("Text should contain only upper case alphabets of length:" + cipherLength);
            cipherText = scanner.nextLine();
        }

        boolean isNotValidString = true;
        while (isNotValidString)
        {
            char[] chars = cipherText.toCharArray();

            for(char ch: chars)
            {
                if(!((Character.isAlphabetic(ch) && Character.isUpperCase(ch)) || ch == ' '))
                {
                    System.out.println("Text should contain only upper case alphabets or of length:" + cipherLength);
                    cipherText = scanner.nextLine();
                    continue;
                }
            }
            isNotValidString = false;
        }*/
        //====END====
        scanner.close();
        return charArr;
    }

    private static Map<Character, Character> constructMap() {
        Map<Character, Character> map = new HashMap<>();
        map.put(' ', ' ');
        map.put('F', 'A');
        map.put('G', 'B');
        map.put('H', 'C');
        map.put('I', 'D');
        map.put('J', 'E');
        map.put('K', 'F');
        map.put('L', 'G');
        map.put('M', 'H');
        map.put('N', 'I');
        map.put('O', 'J');
        map.put('P', 'K');
        map.put('Q', 'L');
        map.put('R', 'M');
        map.put('S', 'N');
        map.put('T', 'O');
        map.put('U', 'P');
        map.put('V', 'Q');
        map.put('W', 'R');
        map.put('X', 'S');
        map.put('Y', 'T');
        map.put('Z', 'U');
        map.put('A', 'V');
        map.put('B', 'W');
        map.put('C', 'X');
        map.put('D', 'Y');
        map.put('E', 'Z');

        return map;
    }
}

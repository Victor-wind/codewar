import sys
import time
import math
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAJ' #prob12
# ------------------------------------------------------------------------

'''
PROBLEM: You Flew In What?!
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 15 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 20 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-01
WHAT IT TESTS: 
    1.) Ability to work with floating point decimals
    2.) Ability to convert units of length and time
    3.) Ability to square numbers, multiply, and divide
    4.) Ability to round a number to a desired decimal place
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))

# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 0):
        parts = lines[0].split(' ')
        #0 == name, 1 == rate, 2 == unit length, 3 == per, 4 == unit time
        if (len(parts) > 4):
            rate = float(parts[1])
            unit_l = parts[2].strip()
            unit_t = parts[4].strip()
            #need meters per second for formula

            #IMPERIAL UNITS
            if (unit_l == 'MILES'):
                #1 meter is equal to 3.28 feet
                #5280 feet in a mile
                #rate is given in miles, and we want meters, so first convert to feet
                #then divide by 3.28 to get meters
                rate = ((rate * 5280)/3.28)
            elif (unit_l == 'YARDS'):
                #1 meter is equal to 3.28 feet
                #3 feet in a yard
                #rate is given in yards, want meters. First convert to feet, 
                #then divide by 3.28 to get meters
                rate = ((rate * 3) / 3.28)
            elif (unit_l == 'FEET'):
                #1 meter is equal to 3.28 feet
                rate = (rate / 3.28)
            elif (unit_l == 'INCHES'):
                #1 meter is equal to 3.28 feet
                #12 inches equals 1 foot
                rate = ((rate/12)/3.28)
            elif (unit_l == 'KILOMETERS'):
                #METRIC UNITS
                #we are already in metric, just need to increase to meters
                #1000 meters = 1 kilometer
                rate = (rate * 1000)
            elif (unit_l == 'CENTIMETERS'):
                #METRIC UNITS
                #we are already in metric, just need to reduce to meters
                #100 centimeters = 1 meter
                rate = (rate / 100)

            if (unit_t == 'HOUR'):
                rate = ((rate / 60.0)/60.0) #60 seconds in a minute, 60 minutes in an hour, and we want seconds
            elif (unit_t == 'MINUTE'):
                rate = (rate / 60.0) #60 seconds in a minute, and we want seconds

            # ------------------------------------------------------------
            CalcDistance(parts[0].strip(),rate)
        else:
            print('** ERROR ** data file is malformed')
    else:
        print('** ERROR ** data file is malformed')
def CalcDistance(name,rate=0.0):
    'Calculate the vertical distance an object will achieve given its launch speed in m/s, and output the result'
    vertical_distance = (rate**2) / (2 * 9.805)
    distanceOut = format(round(vertical_distance,2),'0.2f')
    print(f'{name} will launch the messenger {distanceOut} meters high, ',end='')
    if (vertical_distance < 25.0):
        print('SPLAT!')
    elif (vertical_distance > 50.0):
        print('OUCH!')
    else:
        print('SUCCESS!')
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    #time.sleep(5)

# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    for file in files:
        if ('in.txt' in file):
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

#include <stdio.h>
#define MAX 26

int main(argc,argv) int argc; char **argv; {
int n;
char c[26];
int h[26];
int i;
int max=0;
int f;
int t;
int j;

scanf("%d",&n);
for(i=0;i<n;i++) {
 scanf("%d %c",&h[i],&c[i]);
 if(h[i]>max) max=h[i];
}

for(f=1;f;) {
 f=0;
 for(i=0;i<(n-1);i++) {
  if((h[i]>h[i+1]) || ((h[i]==h[i+1])&&(c[i]>c[i+1]))) {
   t=h[i];h[i]=h[i+1];h[i+1]=t;
   t=c[i];c[i]=c[i+1];c[i+1]=t;
   f++;
   }
 }
}

for(i=max+1;i>0;i--) {
 for(j=0;j<n;j++) {
  if(i>(h[j]+1))  putchar(' ');
  if(i==(h[j]+1)) putchar('~');
  if(i<=(h[j]))   putchar('*');
  }
  putchar('\n');
}
for(i=0;i<n;i++)
 putchar(c[i]);
putchar('\n');
}

  
 

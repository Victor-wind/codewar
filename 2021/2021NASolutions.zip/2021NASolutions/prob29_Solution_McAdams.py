import sys
import datetime
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAC' #prob29
# ------------------------------------------------------------------------

'''
PROBLEM: Tic-Tac-Moe
DIFFICULTY LEVEL: Difficult
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION:  45 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED:  50 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-01-31
WHAT IT TESTS: 
    1.) Ability to work with 2D arrays (or synced lists, up to the programmer)
    2.) Ability to split string data and/or parse data from a string
    3.) Ability to keep track of "state" for the data
    4.) Ability to enforce a rules algorithm
    5.) Ability to keep many different aspects of a problem in focus at the same time (can't just solve for X, have to keep in mind what Y is doing too)
    6.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
NOTE: It would be possible to solve this problem using recursion on the calculated "win states" of the game, however, setting that up could
have a potentially high time cost (especially if the student isn't familiar with recursion), and the payoff would only be a slightly shorter run-time.
But, when the total "problem space" is simply caculating all possible permutation of open space in a N-space game grid with N = 9 -(moves taken) 
already further widdling down the total "problem space", the benefits of recursion would not be realized in any meaningful way.
Thus, the solution I am showing is a simple iteration through the calculated problem space, manually, using loops (which, I suspect, is how
most students would attempt to solve this anyway ^_-)
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))

# ========================================================================
def Main(lines=[]):
    'Main Program'
    nextPlayer = ''
    if (len(lines) > 3):
        # Initial setup, get the game board
        row1 = list(lines[0])
        row2 = list(lines[1])
        row3 = list(lines[2])
        board = [row1,row2,row3]
        # get which player's turn we will evaluate first
        nextPlayer = str(lines[3])[0:1]
        # play a round of the game
        endStateFound = PlayARound(board,nextPlayer)
        # if we reached an end-state during that round, we are done
        if (not endStateFound):
            #else, play again
            nextPlayer = ChangePlayer(nextPlayer)
            #check if we reached an end-state during the second player's turn
            endStateFound = PlayARound(board,nextPlayer)
            #if still no end-state, then the game will either be a tie, or not enough information
            if (not endStateFound):
                #check to see if any moves remaining (if no moves remaining, TIE, else Not Enough Info)
                openSpaces = GetOpenSpaces(board)
                if (len(openSpaces) > 0):
                    print('NOT ENOUGH INFORMATION')
                else:
                    print('GAME WILL BE A TIE')
    else:
        print('** ERROR ** data file is malformed')
def ChangePlayer(currentPlayer)->str:
    'Swaps out the current player symbol (X,O) for the other'
    nextRoundPlayer = 'X'
    if (currentPlayer == 'X'):
        nextRoundPlayer = 'O'
    return nextRoundPlayer
def PlayARound(board,nextPlayer)->[]:
    '''
    Executes the rules, in order of priority, for playing a round of the game.
    First checks what the open spaces are on the board.
    Next generates a list of all possible moves the current player can make
    Next checks if the current player can WIN using any of the possible moves
    --If the player can win, do so, and list the winning moves, mark endState as true
    Else, checks if the other player can win on their next turn.
    --If the other player has one (and only one) winning move available to them
    --current player must move to block them.
    --Else, if the other player has more than one way to win on their next move,
    --declare an end state reached, and say that the other player will win in 2
    --moves, and list those moves, mark endState as true
    Else, make a "random" move, by choosing the next available move for the current
    player to take, working left to right, top to bottom, and having them put their
    symbol in the first available space.
    Return whether or not an end-state (someone won) was reached.
    '''
    endStateFound = False
    #print('next player: '+nextPlayer)
    openSpaces = GetOpenSpaces(board)
    if (len(openSpaces) > 0):
        #print('open spaces: '+str(openSpaces))
        possibleMoves = []
        for move in openSpaces:
            #print(CheckState(board,move,nextPlayer))
            possibleMoves.append(CheckState(board,move,nextPlayer))
        #print('possible moves: '+str(possibleMoves))
        winningMoves = CheckWins(possibleMoves)
        if (len(winningMoves) > 0):
            #check easy condition first: next player to move can win
            endStateFound = True
            print(nextPlayer +' WILL WIN IN 1 MOVES')
            for move in winningMoves:
                print(move)
        else:
            #check second most easy condition, other player WILL win on their turn (so we have to block, or they will win)
            possibleMoves = []
            otherPlayer = ChangePlayer(nextPlayer)
            for move in openSpaces:
                possibleMoves.append(CheckState(board,move,otherPlayer))
            winningMoves = CheckWins(possibleMoves)
            if(len(winningMoves) > 1):
                #other player will win on their next turn (we can't block all their winning states)
                endStateFound = True
                print(otherPlayer +' WILL WIN IN 2 MOVES')
                for move in winningMoves:
                    print(move)
            else:
                #Current player must make a move, if any open spaces
                if (len(winningMoves) == 1):
                    #current player MUST block
                    key, value = list(winningMoves.items())[0]
                    coords = GetMoveWinCoords(str(key))
                    for coord in coords:
                        if (board[coord[0]][coord[1]] == '.'):
                            board[coord[0]][coord[1]] = nextPlayer
                    #print(board)
                else:
                    # don't have to block, can't win, and other player isn't going to win, 
                    # so make a "random" move by simply accepting the first possible move calculated
                    # as per the problem instructions of working left to right, top to bottom when 
                    # needing to have the "AI" make a "random" move
                    board = possibleMoves[0]
    return endStateFound

def GetMoveWinCoords(move)->[]:
    'Translate a winning move set of numbered coordinates back to the 2D array indexes'
    coords = []
    if (str(move) == '1 2 3'):
        coords = [[0,0],[0,1],[0,2]]
    elif (str(move) == '4 5 6'):
        coords = [[1,0],[1,1],[1,2]]
    elif (str(move) == '7 8 9'):
        coords = [[2,0],[2,1],[2,2]]
    elif (str(move) == '1 4 7'):
        coords = [[0,0],[1,0],[2,0]]
    elif (str(move) == '2 5 8'):
        coords = [[0,1],[1,1],[2,1]]
    elif (str(move) == '3 6 9'):
        coords = [[0,2],[1,2],[2,2]]
    elif (str(move) == '1 5 9'):
        coords = [[0,0],[1,1],[2,2]]
    elif (str(move) == '3 5 7'):
        coords = [[0,2],[1,1],[2,0]]
    return coords

def CheckWins(possibleMoves=[]) -> {}:
    '''
    Check for winning moves for the given player, return those winning moves as 
    a dictionary of the winning moves keyed on the numbered spaces for the grid
    given in the problem, with the value being the player which would make the
    winning move.
    '''
    winningMoves = {}
    players = ['X','O']
    for player in players:
        for move in possibleMoves:
            #ROWS
            if (move[0][0] == player and move[0][1] == player and move[0][2] == player):
                winningMoves['1 2 3'] = player
            if (move[1][0] == player and move[1][1] == player and move[1][2] == player):
                winningMoves['4 5 6'] = player
            if (move[2][0] == player and move[2][1] == player and move[2][2] == player):
                winningMoves['7 8 9'] = player
            #COLS
            if (move[0][0] == player and move[1][0] == player and move[2][0] == player):
                winningMoves['1 4 7'] = player
            if (move[0][1] == player and move[1][1] == player and move[2][1] == player):
                winningMoves['2 5 8'] = player
            if (move[0][2] == player and move[1][2] == player and move[2][2] == player):
                winningMoves['3 6 9'] = player
            #DIAG
            if (move[0][0] == player and move[1][1] == player and move[2][2] == player):
                winningMoves['1 5 9'] = player
            if (move[0][2] == player and move[1][1] == player and move[2][0] == player):
                winningMoves['3 5 7'] = player
    return winningMoves

def GetOpenSpaces(board=[]):
    'Finds the board indexes of all of the open spaces currently on the board'
    openSpaces = []
    for i in range(0,3):
        for j in range(0,3):
            if (board[i][j] == '.'):
                openSpaces.append([i,j])
    return openSpaces
def CheckState(board=[],move=[],player='') ->[]:
    '''
    Make a deep copy of the board (so we do not corrupt the current game 
    board reference) then place the symbol of the player into the game board
    at the move coordinates provided
    '''
    copy = CopyArray(board)
    if (len(move) > 1):
        copy[move[0]][move[1]] = player
    #print(copy)
    return copy
def CopyArray(board)->[]:
    'Make a deep copy of the 2D array game board'
    copy = []
    for i in range(0,3):
        row = []
        for j in range(0,3):
            row.append(board[i][j])
        copy.append(row)
    return copy
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)

# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}Data\{probID}') if isfile(join(fr'{DATASET}Data\{probID}', f))]
    for file in files:
        if ('in.txt' in file):
            lines = GetData(AM_DEBUGGING,fr'{DATASET}Data\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

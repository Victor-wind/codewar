# 40ish minutes. A step up in difficulty from the other conversion problems. clear directions.

import sys

wet_conversions = {
    "teaspoon": 3.0,
    "tablespoon": 2.0,
    "ounce": 8.0,
    "cup": 2.0,
    "pint": 2.0,
    "quart": 4.0,
    "gallon": 1.0
}

wet_keys = list(wet_conversions.keys())

dry_conversions = {
    "teaspoon": 3.0,
    "tablespoon": 16.0,
    "cup": 1.0
}

dry_keys = list(dry_conversions.keys())

weighted_conversions = {
    "ounce": 16.0,
    "pound": 1.0
}

weighted_keys = list(weighted_conversions.keys())

def get_conversion_tables(unit):
    if unit == "WET":
        return wet_conversions, wet_keys
    elif unit == "DRY":
        return dry_conversions, dry_keys
    elif unit == "WEIGHTED":
        return weighted_conversions, weighted_keys

def _max(value, size, unit):
    conversion_index, conversion_key = get_conversion_tables(unit)
    while size != conversion_key[-1]:
        value /= conversion_index[size]
        size = conversion_key[conversion_key.index(size)+1]
    return value, size

def unit_conversion(value, size, unit):
    conversion_index, conversion_key = get_conversion_tables(unit)
    
    value, size = _max(value, size, unit)
    while value < 1.00 and size != conversion_key[0]:
        size = conversion_key[conversion_key.index(size)-1]
        value *= conversion_index[size]

    return value, size


if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()

    multiplier = float(inputText[0])
    tomato_value, tomato_size, tomato_name = inputText[2].split()
    final_tomato_value, final_tomato_size = unit_conversion(float(tomato_value) * multiplier, tomato_size, "WET")
    olive_value, olive_size, olive_name = inputText[3].split()
    final_olive_value, final_olive_size = unit_conversion(float(olive_value) * multiplier, olive_size, "WET")
    salt_value, salt_size, salt_name = inputText[5].split()
    final_salt_value, final_salt_size = unit_conversion(float(salt_value) * multiplier, salt_size, "DRY")
    bp_value, bp_size, bp_name = inputText[6].split()
    final_bp_value, final_bp_size = unit_conversion(float(bp_value) * multiplier, bp_size, "DRY")
    onion_value, onion_size, onion_name = inputText[7].split()
    final_onion_value, final_onion_size = unit_conversion(float(onion_value) * multiplier, onion_size, "DRY")
    eggplant_value, eggplant_size, eggplant_name = inputText[9].split()
    final_eggplant_value, final_eggplant_size = unit_conversion(float(eggplant_value) * multiplier, eggplant_size, "WEIGHTED")

    print("WET INGREDIENTS")
    print("{:.2f} {} {}".format(final_tomato_value, final_tomato_size, tomato_name))
    print("{:.2f} {} {}".format(final_olive_value, final_olive_size, olive_name))
    print("DRY INGREDIENTS")
    print("{:.2f} {} {}".format(final_salt_value, final_salt_size, salt_name))
    print("{:.2f} {} {}".format(final_bp_value, final_bp_size, bp_name))
    print("{:.2f} {} {}".format(final_onion_value, final_onion_size, onion_name))
    print("WEIGHTED INGREDIENTS")
    print("{:.2f} {} {}".format(final_eggplant_value, final_eggplant_size, eggplant_name))



import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAV' #prob27
# ------------------------------------------------------------------------

'''
PROBLEM: Pirate Parlay
DIFFICULTY LEVEL: Advanced
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 42 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 50 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-09
WHAT IT TESTS: 
    (Sheesh, what doesn't it test? [¬º-°]¬ )
    1.) Ability to recursively parse through a list of symbols to reach a pre-determined state (yes, you can do it with loops, no, you shouldn't)
    2.) Ability to truly understand, and demonstrate, order of operations
    3.) Ability to truly understand, and demonstrate, boolean logic
    4.) Ability to parse through a string, character by character, and do something with each character (including ignore it)
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 0):
        line = lines[0].strip()
        # print(line)
        symbols = []
        counter = -1
        skipNext = False
        # ----------------------------------------------------------------
        # remove nots
        for c in line:
            counter += 1
            if (not skipNext):
                if (c == '!'):
                    if (line[counter+1] == 'T'):
                        symbols.append('F')
                    else:
                        symbols.append('T')
                    skipNext = True
                else:
                    symbols.append(c)
            else:
                skipNext = False
        # ----------------------------------------------------------------
        # isolate and evaluate parenthesis
        counter = -1
        newList = []
        skipSymb = 0
        # print(symbols)
        for c in symbols:
            counter += 1
            subSymbols = []
            if skipSymb == 0:
                if (c == '('):
                    endParen = False
                    i = counter
                    while (not endParen):
                        i += 1
                        if (symbols[i] != ')'):
                            subSymbols.append(symbols[i])
                        else:
                            endParen = True
                    if (len(subSymbols) > 1):
                        cromulence = DetermineTruth(subSymbols)
                        newList.append(cromulence[0])
                        skipSymb = 1 + len(subSymbols)
                    else:
                        newList.append(subSymbols[0])
                        skipSymb = 2
                else:
                    newList.append(c)
            else:
                skipSymb -= 1
        # ----------------------------------------------------------------
        # print(newList)
        finalAnswer = DetermineTruth(newList)
        # print('answer: '+finalAnswer[0])
        if (finalAnswer[0] == 'F'):
            print('I am disinclined to acquiesce to your request')
        else:
            for c in line:
                # ! means 1 step north (N)
                # & means 2 steps west (W)
                # | means 3 steps south (S)
                # T means 4 steps east (E)
                # F means JUMP over a hidden trap
                if (c == '!'):
                    print('1 N')
                elif (c == '&'):
                    print('2 W')
                elif (c == '|'):
                    print('3 S')
                elif (c == 'T'):
                    print('4 E')
                elif (c == 'F'):
                    print('JUMP')
    else:
        print('** ERROR ** data file is malformed')
def DetermineTruth(subSymbols=[])->'':
    '''
    Returns T or F after recursively parsing all of the symbols in the list
    -----------------------------------------------------------------------
    FINE! You made me write a recursive algorithm! ಠ_ಠ 
    (and by "you" ... I mean "me" -- since I wrote this problem ~(^-^)~  )
    
    Normally I avoid these things like the plague. Not every programmer
    understands them, and even seasoned programmers can get these
    things wrong. They are, however, a powerful tool in your toolkit
    that you will need to use in exactly these types of situations.

    I unwound the problem as much as I could using loops, but once
    you get down to the point where you have to parse and keep
    parsing the symbols in the list until you reach a specific state
    of cromulence (heh), it ends up actually being easier to do THAT
    part of the problem with recursion than trying to use a while
    loop to keep track of it with a WHOLE BUNCH of status flags.
    
    Can you do it with a while loop? Sure. Should you? No.
    The complexity of the order of operations for this problem is
    exactly the type of scenario where recursion is the better option
    over a loop, as you can preserve state that way and drill all the
    way down until there is an answer, doing one "step" at a time.
    If you try to mimic that behavior using loops, you are going to
    keep finding a lot of corner cases you will have to code for and
    catch using all sorts of status flags to get there.

    I actually started down that path when I was writing this solution
    then bailed out when I realized how far down that rabbit hole I would
    have to go to get this solution to spit out the right answer in all
    circumstances. You can see that in the coding. More status variables
    than are strictly needed for a recursive solution. I didn't refactor
    that though to show you that you can use recursion where you absolutely
    need to/should use it, but otherwise code the way you always would.
    
    (That, plus, you know, I am simulating being a student when I write
    these solutions, so I am trying to hurry -- and refactoring is a game
    for when you have plenty of time to sit and think about the "best" way
    to do something. That's my story and I'm sticking with it. (ง'̀-'́)ง )
    '''

    # I am not going to explain recursion in this solution. Both because it
    # is a very involved topic, and also because (and I cannot stress this 
    # enough) I don't want to :P

    # In essence the code below is checking to see if it is "done" because it
    # no longer has more than 1 symbol to process. If so, it returns the symbol
    # list it is working on, and calls it a day.
    # If not, it checks to see if there are no "&" symbols in the list, if that
    # is true, then only "or" symbols and T/F will be in the list, so it can
    # do a simple evaluation.
    # If none of that is true, it builds a new symbol list to pass to itself,
    # evaluating pairs of "ands" as it goes.
    # ... and I just (more or less) explained recursion ... how did you trick
    # me into doing that?! (._.)
    if (len(subSymbols) == 1):
        return subSymbols
    else:
        subList = []
        i = 0
        # print('---------------------------------')
        # print('evaluating:')
        # for s in subSymbols:
        #     print(s,end='')
        # print()
        # print('---------------------------------')
        while i < len(subSymbols):
            if ('&' not in subSymbols):
                if ('T' in subSymbols):
                    subList = ['T']
                else:
                    subList = ['F']
                i = len(subSymbols)
            else:
                # print(subList[0]+subSymbols[i]+subSymbols[i+1]+'=',end='')
                # subList = [subSymbols[0]]
                if (subSymbols[i] == '|' or subSymbols[i] == '&' or i == (len(subSymbols)-1)):
                    subList.append(subSymbols[i])
                    i += 1
                elif (subSymbols[i+1] == '|'):
                    subList.append(subSymbols[i])
                    subList.append(subSymbols[i+1])
                    i += 2
                elif ((subSymbols[i] == 'T' and subSymbols[i+2] == 'T')):
                    subList.append('T')
                    i += 3
                else:
                    subList.append('F')
                    i += 3
                # print('in progress:')
                # for s in subList:
                #     print(s,end='')
                # print()
        return DetermineTruth(subList)
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    # counter = -1
    for file in files:
        if ('in.txt' in file):
            # counter +=1
            # print('')
            # print('')
            # print(f'example {counter}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

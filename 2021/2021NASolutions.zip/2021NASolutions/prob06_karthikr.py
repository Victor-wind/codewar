#!/bin/python3
# Solved by karthik.r@hpe.com

import sys
PLAINTEXT="ABCDEFGHIJKLMNOPQRSTUVWXYZ "
CIPHERTEXT="FGHIJKLMNOPQRSTUVWXYZABCDE "

translation = {}
def translate():
    global translation
    for i in range(0, len(PLAINTEXT)):
        translation[CIPHERTEXT[i]] = PLAINTEXT[i]
    

def parse_inputs():
    inputs = []
    for line in sys.stdin:
        inputs.append(line.rstrip())
    num_lines = int(inputs.pop(0))
    return num_lines, inputs

def solution():
    num_lines, inputs = parse_inputs()
    output = ""
    translate()
    for c in inputs[0]:
        output += translation[c]
    print(output)
        
   
if __name__ == '__main__':
    solution()

#!/bin/python3
# Solved by karthik.r@hpe.com

import sys

def parse_inputs():
    birthdays = []
    for line in sys.stdin:
        birthdays.append(line.rstrip())
    num_lines = int(birthdays.pop(0))
    # print(num_lines, wave)
    return num_lines, birthdays

def solution():
    num_lines, birthdays = parse_inputs()
    bday_dict = {}
    dup_list = []

    # print(birthdays)
    for bday_full in birthdays:
        fields = bday_full.split('/')
        bday = " %s/%s" % (fields[0], fields[1])
        if bday in bday_dict:
            if bday_dict[bday] == 1:
                dup_list.append(bday)        
            bday_dict[bday] += 1
        else:
            bday_dict[bday] = 1

    print(len(dup_list))
    output = "duplicates:"
    for day in dup_list:
        output += "%s" % day
    if len(dup_list) == 0:
        output += " None"
    print(output)
    
if __name__ == '__main__':
    solution()

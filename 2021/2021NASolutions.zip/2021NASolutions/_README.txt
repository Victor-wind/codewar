Please note:

The following solutions were created by CodeWars testers inside and outside of HPE/HPI. They work hard every year to test solve the problems we craft for the contest to make sure (A) the problems are solveable, and (B) that our datasets are as correct as they can be (we're human, sometimes we miss things ;_;)

Some of the solutions were created when we were still crafting and adjusting the problems (some before we even had datasets available). As such, not all of the solutions contained in this collection will be 100% correct. However, all of the algorithms should be correct, even if the problem and/or datasets were further changed after the tester solved the problem.

Not a lot of testers chose to solve using Java this year, so one of our admins translated the first half of his solutions from Python to Java just for our Java students. We leave the rest to the students as an exercise ^_-

--CodeWars Admins
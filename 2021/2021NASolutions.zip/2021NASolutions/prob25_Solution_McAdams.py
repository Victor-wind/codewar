import sys
import time
import os
from os import path,listdir
from os.path import isfile, join
import math

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAX' #prob25
# ------------------------------------------------------------------------

'''
PROBLEM: Swamp Chase
DIFFICULTY LEVEL: Upper Intermediate / Lower Advanced
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 38 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 45 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-11
WHAT IT TESTS: 
    1.) Ability to work with polynomial equations, solve for X, etc.
    2.) Ability to solve systems of equations
    3.) Ability to calculate distance, and use the quadratic equation in code
    4.) Ability to understand spatial distances/vectors in 2D space to properly determine which "direction" along a "path" of an equation is being "traveled"
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 9):
        # input format:
        # 00: DONKEY
        # 01: Y 1 0 0
        # 02: 0.000 0.000 +
        # 03: SHREK
        # 04: A 1 0 2
        # 05: 0.000 2.000 +
        # 06: B 1 6 0
        # 07: -0.200 -1.160 +
        # 08: C -9 -2 3
        # 09: 0.000 3.000 +
        donkey = lines[1].strip().split(' ')
        shrek1 = lines[4].strip().split(' ')
        shrek2 = lines[6].strip().split(' ')
        shrek3 = lines[8].strip().split(' ')
        startY = lines[2].strip().split(' ')
        startA = lines[5].strip().split(' ')
        startB = lines[7].strip().split(' ')
        startC = lines[9].strip().split(' ')
        
        #load up shrek's paths into a dictionary so we can cycle through it
        shrekPaths = {'A':[shrek1,startA],'B':[shrek2,startB],'C':[shrek3,startC]}
        #setup a dictionary of distances for calculated intersection points and the distance between shrek's starting point and the point
        distances = {}

        #Cycle through all of Shrek's paths
        for path in shrekPaths.items():
            handled = False
            #first check to see if the paths CAN intersect
            if (PathsCanIntersect(donkey,path[1][0])):
                #Get the intersection points for this shrek path and Donkey's path
                points = GetIntersectionPoints(donkey,path[1][0])
                #For each X coordinate in those points check the direction of travel between donkey and shrek
                for X in points:
                    dDir = startY[2].strip()
                    sDir = path[1][1][2].strip()
                    dStartX = float(startY[0].strip())
                    sStartX = float(path[1][1][0].strip())
                    if ( (dDir == '+' and X >= dStartX and ((sDir == '+' and X >= sStartX) or (sDir == '-' and X <= sStartX)))
                          or 
                         (dDir == '-' and X <= dStartX and ((sDir == '+' and X >= sStartX) or (sDir == '-' and X <= sStartX)))
                       ):
                        # if they are traveling in a direction where the intersection point would matter, output it as a possible catch
                        Y = GetYCoordinate(X,donkey)
                        XOut = format(round(X,3),'0.3f')
                        YOut = format(round(Y,3),'0.3f')
                        print (f'{path[0]} ({XOut},{YOut})')
                        handled = True
                        # calculate the distance and load it into the possible final answers dictionary
                        d = GetDistance(float(path[1][1][0].strip()),float(path[1][1][1].strip()),X,Y)
                        distances[path[0]] = d
            else:
                print(f'{path[0]} MISS!')
                handled = True
            if (not handled):
                #points intersected, but not in the correct direction
                print(f'{path[0]} MISS!')
        # If we had at least 1 catch, look for the one with the shortest distance, and output that as the answer
        if (len(distances) > 0):
            shortestPath = ''
            #using just an arbitrarily large number as a starting point, since we are checking less-than
            shortestDist = 999999999
            #print('DEBUG: '+str(distances))
            for item in distances.items():
                if (float(item[1]) < shortestDist):
                    shortestPath = item[0]
                    shortestDist = float(item[1])
            shortestDist = format(round(shortestDist,3),'0.3f')
            print(f'{shortestPath} CATCHES DONKEY {shortestDist} METERS AWAY')
        else:
            #Computer says noooooooo :P
            print('DONKEY GETS AWAY!')
    else:
        print('** ERROR ** data file is malformed')
# ========================================================================
def PathsCanIntersect(donkey=[],shrek=[]):
    'Determines if the 2 paths can intersect or not'
    result = False
    # If the new 'a' is zero, the new equation is "bx+c", so the only intersection is x= (-c/b).
    # But if the new 'b' is also zero, that is undefined (so there's no intersection).
    # If the new 'a' is not zero, plug the coefficients into the quadratic formula.
    newB = int(donkey[2].strip()) - int(shrek[2].strip())
    if (newB != 0):
        result = True
    return result
# ========================================================================
def GetIntersectionPoints(donkey=[],shrek=[])->[]:
    'Gets all of the intersection points between the 2 paths'
    # If the new 'a' is zero, the new equation is "bx+c", so the only intersection is x= (-c/b).
    # But if the new 'b' is also zero, that is undefined (so there's no intersection).
    # If the new 'a' is not zero, plug the coefficients into the quadratic formula.
    points = []
    newA = int(donkey[1].strip()) - int(shrek[1].strip())
    newB = int(donkey[2].strip()) - int(shrek[2].strip())
    newC = int(donkey[3].strip()) - int(shrek[3].strip())
    if (newA == 0):
        #special case:
        intersect = (-1 * newC)/newB
        if (abs(intersect) == 0):
            intersect = 0.0
        points.append(intersect)
    else:
        #use quadratic
        intersect1 = ((-1 * newB) - math.sqrt((newB**2)-(4*newA*newC)))/(2*newA)
        intersect2 = ((-1 * newB) + math.sqrt((newB**2)-(4*newA*newC)))/(2*newA)
        #remove negative from zero, if that was one of the results
        if (abs(intersect1) == 0):
            intersect1 = 0.0
        if (abs(intersect2) == 0):
            intersect2 = 0.0
        points.append(intersect1)
        points.append(intersect2)
    return points
# ========================================================================
def GetYCoordinate(X,path):
    'Plugs the X coordinate found earlier into one of the original equations to find the Y coordinate'
    A = int(path[1].strip())
    B = int(path[2].strip())
    C = int(path[3].strip())
    Y = (A*(X**2))+(B*X)+(C)
    return Y
# ========================================================================
def GetDistance(X1,Y1,X2,Y2):
    'Gets the distance between two sets of coordinates'
    result = 0
    try:
        result = math.sqrt((((X2-X1)**2) + ((Y2-Y1)**2)))
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
    return result
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    # counter = -1
    for file in files:
        if ('in.txt' in file):
            # counter +=1
            # print('')
            # print('')
            # print(f'example {counter}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

def get_dataset(problem):
    #read and get input file
    with open(r'.\student_datasets\prob'+problem+'-in.txt') as fi:
        input_file=[]
        for line in fi:
            input_file.append(line.rstrip('\n'))
    
    #read output file
    with open(r'.\student_datasets\prob'+problem+'-out.txt') as fo:
        output_file=[]
        for line in fo:
            output_file.append(line.rstrip('\n'))
    
    #display example output
    print('Example output: ')
    for line in output_file:
        print(line)
    
    return input_file


for example in ['AP-1','AP-2','AP-3','AP-4','AP-5']:
    input_file=get_dataset(example)
    height=float(input_file[0].split(' ')[0])
    radius=float(input_file[0].split(' ')[1])
    pi=3.14
    volumn=round(pi*height*radius*radius,2)
    
    print('Solution output: ')
    print("{} cubic inches\n".format(volumn))
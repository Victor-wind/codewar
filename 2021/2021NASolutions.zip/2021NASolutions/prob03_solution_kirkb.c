#include <stdio.h>

int main(argc,argv) int argc; char **argv; {
char b;
int r=0;
int c=0;

while((b=getchar())!=EOF) {
 if(b=='P') break;
 if(b=='\n') {r++; c=0; continue;} 
 c++;
}

if(b=='P')
 printf("Ace, move fast, pigeon is at (%d,%d)\n",c,r);
else
 printf("No pigeon, try another map, Ace\n");
}

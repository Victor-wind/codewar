import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAN' #prob21
# ------------------------------------------------------------------------

'''
PROBLEM: Where's My Mojo?
DIFFICULTY LEVEL: Intermediate
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 22 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 28 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-02
WHAT IT TESTS: 
    1.) Ability to examine 2D data in multiple directions
    2.) Ability to loop (or recurse) through the data to find a pattern
    3.) Ability to guard against index overflows (if looping)
    4.) Ability to keep track of multiple sets of data at the same time
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))

# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 0):
        x = -1
        y = -1
        for line in lines:
            y +=1
            # CHECK EASIEST FIRST: HORIZONTAL
            if 'MOJO' in line:
                x = line.index('MOJO')
                print(f'M: {x},{y}')
                print(f'O: {x+1},{y}')
                print(f'J: {x+2},{y}')
                print(f'O: {x+3},{y}')
                break
            elif 'OJOM' in line:
                x = line.index('OJOM')
                print(f'M: {x+3},{y}')
                print(f'O: {x+2},{y}')
                print(f'J: {x+1},{y}')
                print(f'O: {x},{y}')
                break
        if (x < 0 or y < 0):
            # We have to scan for it, load the lines into a 2D array
            grid = []
            row = []
            width = 0
            for line in lines:
                row = []
                width = 0
                for c in line:
                    row.append(c)
                    width += 1
                grid.append(row)
            # now that we have the characters in a grid, step through 
            # them column by column looking for verticals
            column = ''
            found = False
            for x in range(0,width):
                column = ''
                for y in range(0,len(lines)):
                    column += grid[y][x]
                if ('MOJO' in column):
                    yy = column.index('MOJO')
                    print(f'M: {x},{yy}')
                    print(f'O: {x},{yy+1}')
                    print(f'J: {x},{yy+2}')
                    print(f'O: {x},{yy+3}')
                    found = True
                    break
                if ('OJOM' in column):
                    yy = column.index('OJOM')
                    print(f'M: {x},{yy+3}')
                    print(f'O: {x},{yy+2}')
                    print(f'J: {x},{yy+1}')
                    print(f'O: {x},{yy}')
                    found = True
                    break
            # if we still haven't found it, check for blocks
            # could also do this recursively, but I don't wanna :P
            if (not found):
                for x in range(0,width):
                    for y in range(0,len(lines)):
                        if (grid[y][x] == 'M'):
                            #guard against index overflow
                            if (((x+1) <= (width-1)) and ((y+1) <= (len(lines)-1))):
                                if (grid[y][x+1] == 'O' and grid[y+1][x] == 'J' and grid[y+1][x+1] == 'O'):
                                    print(f'M: {x},{y}')
                                    print(f'O: {x+1},{y}')
                                    print(f'J: {x},{y+1}')
                                    print(f'O: {x+1},{y+1}')
                                    found = True
                                    break
            if (not found):
                print("** ERROR ** could not find Austin's MOJO!")
    else:
        print('** ERROR ** data file is malformed')
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)

# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    counter = -1
    for file in files:
        counter +=1
        print(f'example {counter}')
        if ('in.txt' in file):
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

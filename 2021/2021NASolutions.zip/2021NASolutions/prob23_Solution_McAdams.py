import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probBB' #prob23
# ------------------------------------------------------------------------

'''
PROBLEM: Do You Want To Build A Snowman?
DIFFICULTY LEVEL: Intermediate
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 32 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 40 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-11
WHAT IT TESTS: 
    1.) Ability to calculate width, height, and range as ratios to a given number with respect to a base number (widest snowball & current snowball)
    2.) Ability to center output to the screen
    3.) Ability to account for numerous sets of off-by-one issues
    4.) Ability to parse numbers out of a string
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 1):
        #create a list which will hold the ints for each snowball, and while
        #doing so, figure out which snowball is the largest
        snowballs = []
        largest = 0
        for i in range(1,len(lines)):
            ball = int(lines[i])
            if (ball > largest):
                largest = ball
            snowballs.append(ball)
        # Cycle through each snowball size and print it (centered on the
        # largest snowball) to the screen
        for snowball in snowballs:
            '''
            There are, just ... SO MANY calculations to walk you through
            here. This is a ratios problem. If you map it out on paper
            or in notepad or a whiteboard (or whatever) before you start
            coding, you will be okay. If you do not, you're DOOOOOMED.

            Because of the special case of a snowball of size 1, and because
            the output must be centered on the largest snowball, you are going
            to have to do a lot of calculations.

            Some of them are based on the midpoint of the width of the largest
            snowball, others are ratios in relation to the row count above/below
            the midpoint with respect to the width, etc. etc.

            You can walk through my calculations below and see how it all works.
            If you take those calculations and write out the actual numbers
            on paper, you will see the relationships appear pretty quickly.

            The tricky part, obviously, is getting all of that to work together
            inside your code ^_-
            '''
            PrintSnowball(snowball,largest)
    else:
        print('** ERROR ** data file is malformed')
def PadLeft(snowball,largest,width=0,row=0,isTopBtm=True,isMiddle=False,isMid=False):
    '''
    This is, by far, the function which requires the most amount of
    hand-holding in your code. That is partly because of the way I chose
    to code the snowball output, and partly because the rules will be 
    different for the padding if we are printing the "top" or "bottom" vs.
    the exact middle, vs. the upper or lower middle (counting up vs. down, 
    etc.). I could have done this as a unified output, but that requires
    more time up-front for calculations and planning, and when I solve these
    things I try my best to act like a student who is working against a time
    limit. So, I don't tend to do a lot of backtracking ^_^'''
    # PAD LEFT============================================================
    padLeft = (largest*2) // 2
    if (isTopBtm):
        #This will always be a static ratio against how big the snowball is with respect to the largest snowball
        if (snowball > 1):
            padLeft = ((largest*2) // 2) - (snowball // 2)
        for m in range(0,padLeft):
            print(' ',end='')
    elif (isMid):
        #this is the ratio that will change every time a new middle row is output, and the ratio will
        #also have to be used in ASC or DESC order depending on which middle section is being output
        if (snowball > 1):
            padLeft = ((largest*2) // 2) - (snowball // 2)
        if (width < 0):
            for m in range(padLeft-(row+1),-1,-1):
                print(' ',end='')
        else:
            for m in range(0,padLeft-(row+1)):
                print(' ',end='')
    elif (isMiddle):
        #this will also alwas be a static ratio against how large the snowball is with respect to the largest snowball
        padLeft = (((largest*2)//2) - ((width//2)+1))
        for m in range(0,padLeft):
            print(' ',end='')
def PrintTopBtm(snowball,largest):
    'Our most straight-forward part(s) to print'
    # TOP=========================================================
    PadLeft(snowball,largest)
    print('#'*snowball) #top
def PrintMiddle(snowball,largest):
    'Second most straight-forward part to print, the exact middle'
    # EXACT-MIDDLE================================================
    width = (snowball * 2) -1
    PadLeft(snowball,largest,width,0,False,True)
    print('#',end='')
    for j in range(0,width):
        print(' ',end='')
    print('#')
def PrintUpper(snowball,largest):
    'The upper and lower middle sections are where the calculations (and the padding) get intense o_O'
    # UPPER-MIDDLE================================================
    height = snowball//2
    for k in range(0,height):
        PadLeft(snowball,largest,0,k,False,False,True)
        print('#',end='')
        for l in range(0,(snowball + (k*2))):
            print(' ',end='')
        print('#')
def PrintLower(snowball,largest):
    'The upper and lower middle sections are where the calculations (and the padding) get intense o_O'
    # LOWER-MIDDLE================================================
    height = snowball//2
    if (snowball > 1):
        for k in range(height,0,-1):
            PadLeft(snowball,largest,-1,k,False,False,True)
            print('#',end='')
            meow = (snowball + (k*2))-2
            for l in range(0,meow):
                print(' ',end='')
            print('#')

def PrintSnowball(snowball,largest):
    '''Seems desceptively simple, doesn't it? Just print the top, 
    upper, middle, lower, and bottom sections. What could do wrong?!'''
    PrintTopBtm(snowball,largest)
    PrintUpper(snowball,largest)
    PrintMiddle(snowball,largest)
    PrintLower(snowball,largest)
    PrintTopBtm(snowball,largest)

# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    # time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    counter = -1
    for file in files:
        if ('in.txt' in file):
            counter +=1
            print('')
            print(f'{file}')
            print(f'{DATASET} {counter}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

# Tiling With Tatamis
#
# There are 2 rules when placing Tatamis:
# A Tatami may not share an edge with a Tatami of the same size.
# Four Tatamis may not share the same corner.
#
# You will receive a partial description of a square room tiled with Tatamis.
# The first line will be an integer N (from 4 to 7), the size of the square room.
# The next N lines describe squares already known.
# Each number marks the only square known in a single Tatami, and unknown squares are marked with a period (.)
# Not all Tatamis are marked.
# Print the completed tiling of the room.
# There is only one solution.

# Create a grid with a buffer all around the possible size (12x12 for a 10x10 max) to avoid limit checks.
maxGrid = 12

debugPrint = False

#globals, overwritten during input

given = [[(0) for x in range(maxGrid)] for x in range(maxGrid)] # Input grid. 12x12 to hold a 10x10
grid = [[(0) for x in range(maxGrid)] for x in range(maxGrid)] # Working grid
dim = 4
currentTile = 0
inverted = False
import sys


#-----------------------------------
# Invert the grid - It's faster to analyze when more clues are in the upper half
def invertGrid(g):
    tmpgrid = [[(0) for x in range(maxGrid)] for x in range(maxGrid)] # Working grid
    for i in range(1,dim+1):
        for j in range(1, dim + 1):
            tmpgrid[dim+1-i][j] = g[i][j]
    for i in range(1,dim+1):
        for j in range(1, dim + 1):
            g[i][j] = tmpgrid[i][j]

#-----------------------------------
# Print the grid
def printGrid(g):
    lowR=1
    highR=dim+1
    stepR=1
    if inverted:
        lowR=dim
        highR=0
        stepR=-1
    for i in range(lowR, highR, stepR):
        for j in range(1, dim + 1):
            val = g[i][j]
            if val == 0: # Empty
                print('.', sep='', end='')
            else:
                print(val, sep='', end='')
        print ('')
    if debugPrint:
        print ("Max tile:",currentTile)

# -----------------------------------
# all4Diff
#   Return true if all 4 values are different
def all4Diff(w, x, y, z):
    return (w != x and w != y and w != z and x != y and x != z and y != z)

# -----------------------------------
# goodPreCheck(r,c,rMax,cMax,val)
#   - Confirm no tiles already placed
#   - Confirm neighboring tiles and given values don't match
#   - Confirm placement won't cause 4-corners
def goodPreCheck(r, c, rMax, cMax, val):
    # Check if any tiles were already placed here or Given values don't match
    for i in range(r, rMax + 1):
        for j in range(c, cMax + 1):
            # Only check for tiles horizontally (there can't be any beneath this square)
            if j>c and grid[i][j] != 0: # A tile is in the way
                if debugPrint:
                    print(val,"at",r,c,"Tile at",i,j,"present")
                return False
            if given[i][j] > 0 and given[i][j] != val: # Mismatch on provided values
                if debugPrint:
                    print(val,"at",r,c,"Given",given[i][j],"at",i,j,"conflicts")
                return False
    # Check surrounding tiles and make sure no prior tiles or given values match
    # Above
    if r>1:
        for j in range(c - 1, cMax + 2):
            if (grid[r-1][j] == val):
                if debugPrint:
                    print("Above:",val,"at",r,c,"matches",r-1,j)
                return False
    # Sides
    for i in range(r, rMax + 1):
        for j in range(c - 1, cMax + 2, cMax-c+2):  # Check c-1 and cMax+1
            if grid[i][j] == val or given[i][j] == val:
                if debugPrint:
                    print("Side:",val,"at",r,c,"matches",i,j)
                return False
    # Below
    if rMax<dim:
        for j in range(c - 1, cMax + 2):
            if grid[rMax+1][j] == val or given[rMax+1][j] == val:
                if debugPrint:
                    print("Below:",val,"at",r,c,"matches",rMax+1,j)
                return False
    # Four Corners
    # We already validated no matches around the tile.  Now check top corners for
    #    four different values, which would mean four Tatamis
    #    In most cases, checking bottom corners is pointless, since lower Tatamis
    #       aren't placed, and the 2x2 will be checked later (as top corners then.)
    # Above-Right
    a1 = grid[r - 1][cMax + 1]
    b1 = grid[r - 1][cMax]
    c1 = grid[r][cMax + 1]
    d1 = val #[r][cMax]
    if all4Diff(a1, b1, c1, d1):
        if debugPrint:
            print("Above-Right: Four-Corners for ",r,c,":",a1,b1,c1,d1)
        return False

    # Above-Left
    a1 = grid[r - 1][c - 1]
    b1 = grid[r - 1][c]
    c1 = grid[r][c - 1]
    d1 = val #[r][c]
    if all4Diff(a1, b1, c1, d1):
        if debugPrint:
            print("Above-Left: Four-Corners for ",r,c,":",a1,b1,c1,d1)
        return False

    # All checks passed
    return True

# -----------------------------------
# findNextEmpty - scan from r,c to next empty grid location
#    If there are none, we must be done.
def findNextEmpty(r, c):
    initR=r
    initC=c
    while grid[r][c] > 0:
        c += 1
        if c > dim:
            r += 1
            c = 1
            if r > dim: # We finished
                printGrid(grid)
                print('')
                return -1,-1                # Print EVERY solution to be sure only 1 is found
    if debugPrint:
        print("From",initR,initC,"to",r,c)
    return r,c

# -----------------------------------
# place - Place a Tatami tile
#    - Loop through 1-4 and horiz/vert
#       - Validate no errors
#       - Find next empty square and recurse
#       - Remove placement before returning  (less time than copying full grid)
def place(r, c):
    global currentTile
    if debugPrint:
        print ("At",r,c)
        printGrid(grid)
    for val in range(4, 0, -1):   # Placing larger tiles first finds issues faster
#    for val in range(1,5):
        #Horizontal
        if c + val - 1 <= dim:                          # Tile fits horizontally
            # Pre-check no other tiles placed and no wrong given values
            if goodPreCheck(r, c, r, c+val-1, val):         # Horiz Tile will work here
                currentTile += 1                   # Get a new tile ID
                for j in range(c, c + val):
                    grid[r][j] = val
                newR, newC =findNextEmpty(r, c + val - 1)
                if newR>0:
                    place(newR, newC)     # Recursively fill grid
                # Clear placement before next loop
                for j in range(c, c + val):
                    grid[r][j] = 0
        # Vertical
        if val > 1 and r + val - 1 <= dim:                # Tile fits vertically (already tried 1 horizontally)
            # Pre-check no other tiles placed and no wrong given values
            if goodPreCheck(r, c, r+val-1, c, val):         # Vertical Tile will work here
                currentTile += 1                    # Get a new tile ID
                for i in range(r, r + val):
                    grid[i][c] = val
                newR, newC =findNextEmpty(r, c)
                if newR>0:
                    place(newR, newC)     # Recursively fill grid
                # Clear placement before next loop
                for i in range(r, r + val):
                    grid[i][c] = 0


#------------------------------------------------------------------------
# Main program starts here.

textSize = sys.stdin.readline().rstrip('\n').rstrip(' ');
dim = int(textSize)

# These values will determine if an inverted given would be faster
givenCount=0
givenRow=0
# Read in the grid, filling [1,1] to [dim,dim]
for i in range(1, dim + 1):
    line = sys.stdin.readline()             # "." = unknown (0).  "1/2/3/4" = Tatami
    for j in range(dim):
        square = line[j]
        if square != '.':                   # not empty
            val = int(square)
            given[i][j + 1] = val             # filling from [1,1], leaving an empty border
            if val>0:
                givenCount+=1
                givenRow+=i

# Debug Print the starting values
if debugPrint:
    print('')
    print ('Initial Grid:')
    printGrid(given)
    print('')

if (givenRow/givenCount > dim/2):           # The grid has more clues lower in the grid.
    invertGrid(given)
    inverted=True
    if debugPrint:
        print("Inverting Grid for speed.")

if debugPrint:
    print("Starting at",newR,newC)
place(1,1)


import sys
import time
import os
from os import path,listdir
from os.path import isfile, join
import math

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAW'#prob09
# ------------------------------------------------------------------------

'''
PROBLEM: Tight Fit
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 8 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 15 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-09
WHAT IT TESTS: 
    This is a straight-forward math problem. There is a little bit of difficulty related to the data parsing from the file, but other than
    that the problem is a straight multiplication problem using various formulas (give) for volume.
    1.) Ability to work with floating point decimal numbers
    2.) Ability to parse numbers from strings
    3.) Ability to calculate volumes of various geometric shapes
    4.) Ability to output numbers rounded to specific significant figures
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 3):
        # input in form of:
        # 872               -> minion count
        # 15.90             -> radius cockpit
        # 22.10 17.34       -> radius and height of the body
        # 10.00 10.00 9.82  -> length, width and height storage pods
        #
        # Space considerations:
        # Minions: 1.20 m^3, per minion, minimum
        # Gru: 2.20 m^3
        # Cockpit controls: 4.10 m^3
        # Equipment: 12.10 m^3
        
        #CONSTANTS
        vGru =2.2
        vCockpit = 4.1
        vBody = 12.1
        vMinion = 1.2

        #VARIABLES
        # Pull the data out of the file, and format as int or float
        # Then use those numbers to do the initial volume calculations
        minionCount   = int(lines[0].strip())
        sphere        = CalcVolSphere(float(lines[1].strip()))
        cyl           = 0.0
        pyrm          = 0.0
        partsCylinder = lines[2].strip().split(' ')
        partsPyramid  = lines[3].strip().split(' ')
        if (len(partsCylinder) > 1 and len(partsPyramid) > 2):
            #have to do the multi-part data analysis in 2-parts, to account for needing to split on the spaces
            cyl = CalcVolCylinder(float(partsCylinder[0].strip()),float(partsCylinder[1].strip()))
            pyrm = CalcVolPyramid(float(partsPyramid[0].strip()),float(partsPyramid[1].strip()),float(partsPyramid[2].strip()))
            
            # Now that we have the volume calculations, account for the space already
            # spoken for by controls, Gru, Minions, etc. Also double the space for 
            # the pods (as there are two of them)
            finalCockpit = sphere - vGru - vCockpit
            finalBody = cyl - vBody
            finalPods = 2 * pyrm
            finalMinions = minionCount * vMinion

            # Format the final numbers for output, rounded to 2 decimal points of sigfigs
            outputCockpit = format(round(finalCockpit,2),'.2f')
            outputBody    = format(round(finalBody,2),'.2f')
            outputPods    = format(round(finalPods,2),'.2f')
            outputMinions = format(round(finalMinions,2),'.2f')

            # Output the results
            print(f'Cockpit {outputCockpit}')
            print(f'Body {outputBody}')
            print(f'Pods {outputPods}')
            # print(f'DEBUG total vol {round((finalBody + finalCockpit + finalPods),2)}')
            print(f'Minions Need {outputMinions}')
            
            #Output the final accept/reject message base of the space available against the space needed
            if (finalMinions <= round((finalBody + finalCockpit + finalPods),2)):
                print('PLAN ACCEPTED')
            else:
                print('PLAN REJECTED')
        else:
            print('** ERROR ** data file is malformed')
    else:
        print('** ERROR ** data file is malformed')
# ========================================================================
def CalcVolSphere(r):
    'Calculates the volume of a sphere'
    return 4*((math.pi * (r**3))/3)
# ========================================================================
def CalcVolCylinder(r,h):
    'Calculates the volume of a cylinder'
    return r**2 * math.pi * h
# ========================================================================
def CalcVolPyramid(l,w,h):
    'Calculates the volume of a pyramid'
    return (l * w * h)/3
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    # counter = -1
    for file in files:
        if ('in.txt' in file):
            # counter +=1
            # print('')
            # print('')
            # print(f'example {counter}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
import java.text.DecimalFormat;//required for rounding
public class prob09_Solution_McAdams {
/*
PROBLEM: Tight Fit
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 8 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 15 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-09
WHAT IT TESTS: 
    This is a straight-forward math problem. There is a little bit of difficulty related to the data parsing from the file, but other than
    that the problem is a straight multiplication problem using various formulas (given) for volume.
    1.) Ability to work with floating point decimal numbers
    2.) Ability to parse numbers from strings
    3.) Ability to calculate volumes of various geometric shapes
    4.) Ability to output numbers rounded to specific significant figures
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.

NOTE: This solution was translated from my original solution in Python, into Java. I did that for the first 15 problems in the packet
so students who only code in Java will have solutions to look at in their native coding language. The algorithms are the same. The only
parts which change are language specific things (such as how to access list elements). I also collapsed some functions out of python
back into the main program in Java, just to save time. By comparing these 15 translated Java programs to their original Python
implementations, you should be able to pull out Java coding from the rest of the Python solutions, if you'd like. The techniques and
coding functionality used should (more or less) stay the same for the rest of the Python solutions I did. I tend to stick to basics
when at all possible: lists, dictionaries, loops, and logic structures. The only one which might get a little tricky going from
Python to Java will be Pirate Parlay(#27). If you get that one working, I will be impressed :)
*/
	//------------------------------------------------------------------------
	// CHANGE THIS BEFORE SUBMITTING!
	private static final boolean AM_DEBUGGING = true;
	private static final boolean DATA_STUDENT = true;
	private static final String DEBUG_PROB_ID = "prob09";
	private static final int DEBUG_PROB_IN = 1;
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";
	private static final boolean DEBUG_MODE_ALL = true;
	//------------------------------------------------------------------------
	public static void main(String[] args) {
		try
		{
			GetData();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void MainProgram(List<String> lines) {
		if (lines.size() > 0)
		{
	        // input in form of:
	        // 872               -> minion count
	        // 15.90             -> radius cockpit
	        // 22.10 17.34       -> height and radius of the body
	        // 10.00 10.00 9.82  -> length, width and height storage pods
	        //
	        // Space considerations:
	        // Minions: 1.20 m^3, per minion, minimum
	        // Gru: 2.20 m^3
	        // Cockpit controls: 4.10 m^3
	        // Equipment: 12.10 m^3
	        
	        //CONSTANTS
	        double vGru =2.2;
	        double vCockpit = 4.1;
	        double vBody = 12.1;
	        double vMinion = 1.2;

	        //VARIABLES
	        // Pull the data out of the file, and format as int or float
	        // Then use those numbers to do the initial volume calculations
	        int minionCount = Integer.parseInt(lines.get(0).strip());
	        double sphere   = CalcVolSphere(Double.parseDouble(lines.get(1).strip()));
	        double cyl      = 0.0;
	        double pyrm     = 0.0;
	        String[] partsCylinder = lines.get(2).strip().split(" ");
	        String[] partsPyramid  = lines.get(3).strip().split(" ");
	        if (partsCylinder.length > 1 && partsPyramid.length > 2)
	        {
	            //have to do the multi-part data analysis in 2-parts, to account for needing to split on the spaces
	            cyl = CalcVolCylinder(Double.parseDouble(partsCylinder[0].strip()),Double.parseDouble(partsCylinder[1].strip()));
	            pyrm = CalcVolPyramid(Double.parseDouble(partsPyramid[0].strip()),Double.parseDouble(partsPyramid[1].strip()),Double.parseDouble(partsPyramid[2].strip()));
	            
	            // Now that we have the volume calculations, account for the space already
	            // spoken for by controls, Gru, Minions, etc. Also double the space for 
	            // the pods (as there are two of them)
	            double finalCockpit = sphere - vGru - vCockpit;
	            double finalBody = cyl - vBody;
	            double finalPods = 2 * pyrm;
	            double finalMinions = Math.round((minionCount * vMinion)*100.0)/100.0; 
	            
	            DecimalFormat df = new DecimalFormat("0.00");//constant for rounding decimals
	            
	            // Format the final numbers for output, rounded to 2 decimal points of sigfigs
	            String outputCockpit = df.format(finalCockpit);
	            String outputBody    = df.format(finalBody);
	            String outputPods    = df.format(finalPods);
	            String outputMinions = df.format(finalMinions);

	            // Output the results
	            print("Cockpit "+outputCockpit);
	            print("Body "+outputBody);
	            print("Pods "+outputPods);
	            print("Minions Need "+outputMinions);
	            
	            double availableSpace = Math.round((finalBody + finalCockpit + finalPods)*100.0)/100.0; 
	            //print("DEBUG "+finalMinions+" <= "+availableSpace);
	            
	            //Output the final accept/reject message base of the space available against the space needed
	            if (finalMinions <= availableSpace)
	            {
	                print("PLAN ACCEPTED");
	            }
	            else
	            {
	                print("PLAN REJECTED");
	            }
	        }
	        else
	        {
	            print("** ERROR ** data file is malformed");
	        }
		}
		else
		{
			print("*****Error Malformed Data");
		}
	}
	// ========================================================================
	private static double CalcVolSphere(double r)
	{
	    //Calculates the volume of a sphere
	    return 4*((Math.PI * (r*r*r))/3);
	}
	// ========================================================================
	private static double CalcVolCylinder(double r, double h)
	{
	    //Calculates the volume of a cylinder
	    return (r*r * Math.PI * h);
	}
	// ========================================================================
	private static double CalcVolPyramid(double l,double w,double h)
	{
	    //Calculates the volume of a pyramid
	    return ((l * w * h)/3);
	}
	private static List<String> inputFromStdIn() {
		List<String> lines =new ArrayList<String>();
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static void GetData() throws IOException {
		String dataset = "student";
		if (!DATA_STUDENT) {
			dataset = "judge";
		}
		if (AM_DEBUGGING) {
			if (DEBUG_MODE_ALL) {
				List<String> datasets =new ArrayList<String>();
				File datasetFolder = new File(DEBUG_PATH+"\\"+dataset+"_datasets\\");
				File[] files = datasetFolder.listFiles();
				for (File f:files) {
					if (f.isFile()) {
						if (f.getName().indexOf(DEBUG_PROB_ID) > -1 && f.getName().indexOf("in") > -1)
						{
							datasets.add(f.getName());
						}
					}
				}
				for (String file: datasets) {
					print("--------------------------------------------------------------------------------------");
					print("DEBUGGING OUTPUT FOR: "+file);
					MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+file).toPath()));
				}
			}
			else {
				MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+DEBUG_PROB_ID+
						"-"+DEBUG_PROB_IN+"-in.txt").toPath()));
			}
		}
		else{
			MainProgram(inputFromStdIn());
		}
	}
	private static void print(String s) {
		//shortcut for moving back and forth between Python (and, also, (and I cannot stress this enough), I hate typing out the full System.out.println() ceremony every time
		System.out.println(s);
	}
}

# I'm Gonna Wreck It
#
# Read input.  Print 3 different sections, based on size
import sys

debugPrint = False

#------------------------------------------------------------------------
# Main program starts here.

line     = sys.stdin.readline().rstrip('\n').rstrip(' ');
words    = line.split(' ')
wall     = int(words[0])
hit      = int(words[1])
power    = int(int(words[2])/10)
if debugPrint:
    print("Wall:",wall,". Hit:",hit,". Dots:",power)

if hit > wall or hit<2: #special cases for missing the wall.
    hit=wall+1
    power=0
# Print wall
i=hit-1
while i>1:
    print("#")
    i -= 1
print("#",end='') #Last block of wall
# Print power dots
while power>0 and wall>hit:
    print('.',end='')
    power -= 1
# Print fallen top-of-wall
while wall>=hit:
    print("#",end='')
    wall -= 1
print('')


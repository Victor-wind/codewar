import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAR' #prob28
# ------------------------------------------------------------------------

'''
PROBLEM: Elmo's Rectangle
DIFFICULTY LEVEL: Intermediate
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 36 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 45 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-03-01
WHAT IT TESTS: 
    1.) Ability to work with 2-dimensional data (I would suggest 2D arrays, but you can use dictionaries/hashes, or even recursion if you're clever)
    2.) Ability to calculate output coordinates in 2-dimensional space
    3.) Ability to keep track of multiple sets of data at the same time
    4.) Ability to loop (or recurse, or calculate) through multiple sets of data, in the correct order, to achieve the desired output
    5.) Ability to hang on to one's sanity while thinking in 2-dimensional space about outputting characters in changing directions o_O
    6.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def GetNumbersDict()->{}:
    'Returns a dictionary with the numbers.txt data in it'
    
    ## Original intention was to read the file in at run time. Changed 
    ## problem before publication to state that the file will not be 
    ## available at run-time anymore. So need to copy+paste hardcode
    # global AM_DEBUGGING
    # numbers = {}
    # numbersFile = ''
    # if AM_DEBUGGING:
    #     numbersFile = GetData(True,filePath=r"studentData\probAR\numbers.txt")
    # else:
    #     numbersFile = GetData(True,filePath=r"numbers.txt")
    # for line in numbersFile:
    #     num = line.strip().split(' ')
    #     if (len(num) > 1):
    #         numbers[int(num[0])] = num[1].strip()
    numbers = {
         1:"one"
        ,2:"two"
        ,3:"three"
        ,4:"four"
        ,5:"five"
        ,6:"six"
        ,7:"seven"
        ,8:"eight"
        ,9:"nine"
        ,10:"ten"
        ,11:"eleven"
        ,12:"twelve"
        ,13:"thirteen"
        ,14:"fourteen"
        ,15:"fifteen"
        ,16:"sixteen"
        ,17:"seventeen"
        ,18:"eighteen"
        ,19:"nineteen"
        ,20:"twenty"
        ,21:"twentyone"
        ,22:"twentytwo"
        ,23:"twentythree"
        ,24:"twentyfour"
        ,25:"twentyfive"
        ,26:"twentysix"
        ,27:"twentyseven"
        ,28:"twentyeight"
        ,29:"twentynine"
        ,30:"thirty"
        ,31:"thirtyone"
        ,32:"thirtytwo"
        ,33:"thirtythree"
        ,34:"thirtyfour"
        ,35:"thirtyfive"
        ,36:"thirtysix"
        ,37:"thirtyseven"
        ,38:"thirtyeight"
        ,39:"thirtynine"
        ,40:"forty"
        ,41:"fortyone"
        ,42:"fortytwo"
        ,43:"fortythree"
        ,44:"fortyfour"
        ,45:"fortyfive"
        ,46:"fortysix"
        ,47:"fortyseven"
        ,48:"fortyeight"
        ,49:"fortynine"
        ,50:"fifty"
        ,51:"fiftyone"
        ,52:"fiftytwo"
        ,53:"fiftythree"
        ,54:"fiftyfour"
        ,55:"fiftyfive"
        ,56:"fiftysix"
        ,57:"fiftyseven"
        ,58:"fiftyeight"
        ,59:"fiftynine"
        ,60:"sixty"
        ,61:"sixtyone"
        ,62:"sixtytwo"
        ,63:"sixtythree"
        ,64:"sixtyfour"
        ,65:"sixtyfive"
        ,66:"sixtysix"
        ,67:"sixtyseven"
        ,68:"sixtyeight"
        ,69:"sixtynine"
        ,70:"seventy"
        ,71:"seventyone"
        ,72:"seventytwo"
        ,73:"seventythree"
        ,74:"seventyfour"
        ,75:"seventyfive"
        ,76:"seventysix"
        ,77:"seventyseven"
        ,78:"seventyeight"
        ,79:"seventynine"
        ,80:"eighty"
        ,81:"eightyone"
        ,82:"eightytwo"
        ,83:"eightythree"
        ,84:"eightyfour"
        ,85:"eightyfive"
        ,86:"eightysix"
        ,87:"eightyseven"
        ,88:"eightyeight"
        ,89:"eightynine"
        ,90:"ninety"
        ,91:"ninetyone"
        ,92:"ninetytwo"
        ,93:"ninetythree"
        ,94:"ninetyfour"
        ,95:"ninetyfive"
        ,96:"ninetysix"
        ,97:"ninetyseven"
        ,98:"ninetyeight"
        ,99:"ninetynine"
        ,100:"onehundred"
    }
    return numbers
# ========================================================================
def SetupGrid(rows,cols)->[]:
    'returns a 2D array of size equal to the cols/rows passed into it'
    grid = []
    for i in range (0,cols):
        row = []
        for j in range (0,rows):
            row.append('')
        grid.append(row)
    return grid
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 0):
        # There are lots of ways to solve this, but one of the simpler ways
        # to do this, is to create a large 2D array which will have 
        # enough space on all 4 "sides" to place all of the layers of output.
        # That way, you don't have to do any calculations, you simply have 
        # to implement loops in the correct "directions".
        # Since we were guaranteed in the problem description that our 
        # output will fit inside an 80x80 grid, that means ~40 characters 
        # out in all directions from "center". So, I am going to create
        # a 100x100 grid (because I like large round numbers :P)
        # and start outputting from the center.
        parts = lines[0].strip().split(' ')
        if (len(parts) > 1):
            start = int(parts[0])
            stop = int(parts[1])
            # making life easy for myself by using the provided number dictionary
            numbers = GetNumbersDict()
            # setting up a large 2D array/list to use as digital "graph paper"
            # to chart the output
            grid = SetupGrid(100,100)
            # Starting output in the center of the grid.
            # Need to keep track of where we started, because
            # the reset position after the first number will
            # be different than every other iteration after that
            X_START = 50
            Y_START = 50
            # the X and Y variables will keep running track of where we are 
            # currently outputting characters (the "cursor", if you will)
            X = X_START
            Y = Y_START
            # priorWidth is used to keep track of how long the previous line
            # was (which we will still have to manipulate)
            priorWidth = len(numbers[start])
            # priorHeight does the same thing as priorWidth, but for height
            priorHeight = 1
            # letterIdx keeps track of which index of the current number we
            # are outputting. This will be handed off to each sub loop to 
            # maintain continuity with the output
            letterIdx = 0
            # numCount is the number we are currently outputting
            numCount = start
            # totalNumbersOutput should be self explanitory
            totalNumbersOutput = 0
            # Whew! So, at this point, you're probably wanting to do this:
            # (ノ°Д°）ノ︵ ┻━┻
            # But, it isn't as bad as it seems. (See included snapshot of 
            # solving method sketch). Those of you who sketched out a solution
            # to this before you started coding are very wise. Getting some
            # numbers and relationships on paper in front of you before you
            # start coding will save you a LOT of time!
            # If you sketch out just one wrap of a number around a start number
            # you will immediately start to see the relationship between the
            # columns, rows, heights, and widths of the numbers in the output.
            # You'll have to account for +2 to the width every time you start 
            # a new number (because you added two "sides" in the prior run).
            # You should also see that the relationship between the height
            # per run is ALSO +2 per run (again, because you added two "sides"
            # to the top and bottom from the last run).
            # The trickier part is to account for the differences between
            # the heights and widths when wrapping the output. The way *I* 
            # chose to do it was to extend the output from each prior "side"
            # into the "start" of the next "side". E.G. the last character output
            # for the "right side" is also the "first" character for the bottom
            # "side" (working right to left). Same deal for the last character
            # output on the bottom, it is the first character for the "left 
            # side". Because I chose to do it that way, I only add +1 
            # to the width when calculating the output width of the bottom "side"
            # from, and I will actually need to subtract one from the height
            # when outputting the final "left side". 
            # 
            # If you walk through what I just wrote with the little sketch 
            # included with this solution the coding should basically write 
            # itself. Yeah, you have to keep track of a lot of positional
            # variables, but the coding logic itself is rather simple to keep
            # track of, and the nice thing about it is that each wrapped
            # layer of output will end up placing you at the next X,Y
            # coordinate you will need to start each successive layer.
            #
            # Are there other ways to do this? Sure. You can get fancy with 
            # recursion and precalculating the dimensions of the output ... if
            # you want. (And if any student teams submit a solution like that
            # during a timed contest, I will be IMPRESSED!)
            # You could also use a dictionary/hash approach to solve this as 
            # well. You could also pre-calculate the lengths of the output
            # you will need for each number's layer, put them all into a single
            # string variable, then print that in reverse from top to bottom,
            # outer to inner. And, again, if you any student does that during
            # the timed contest, I will be impressed :)
            #
            # But, literally every student who comes to compete in CodeWars
            # will understand loops. So, loops is the solution I showed.
            # (Also, I cannot stress strongly enough just how much I DO 
            # NOT WANT to code a recursive solution for this ¯\_(ツ)_/¯ )
            while numCount <= stop:
                #each time we start the output for a new number, clear/reset
                #all of the per-number counters
                letterIdx = 0
                totalTopCount = 0
                totalRightCount = 0
                totalBtmCount = 0
                totalLeftCount = 0
                #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                # TOP SIDE:
                # special handling for width, as we will need to add +2 after the
                # first number is output
                if (totalNumbersOutput > 1):
                    priorWidth += 2
                # Logic for each side's loop is always the same. (So I am only
                # explaining it once :P ). The only factors which change per
                # side is whether we're tracking width or height. If height, we
                # will be modifying the Y coordinate for the output, else the 
                # X coordinate. Otherwise we just keep looping through the 
                # characters of the number written out as a word until we reach
                # the desired length of output.
                while totalTopCount < priorWidth:
                    if (letterIdx >= len(numbers[numCount])):
                        letterIdx = 0
                    grid[Y][X] = numbers[numCount][letterIdx]
                    X += 1
                    letterIdx += 1
                    totalTopCount += 1
                priorWidth = totalTopCount
                #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #not going to do any wrap-around layers if we are on the first number
                if (totalNumbersOutput > 0):
                    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    # RIGHT SIDE:
                    while totalRightCount < (priorHeight + 2):
                        if (letterIdx >= len(numbers[numCount])):
                            letterIdx = 0
                        grid[Y][X] = numbers[numCount][letterIdx]
                        Y += 1
                        letterIdx += 1
                        totalRightCount += 1
                    priorHeight = totalRightCount
                    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    # BOTTOM SIDE:
                    # Before we start the bottom and the left side, we will
                    # have to reposition the X,Y coordinates to account for
                    # changing directions.

                    # roll back Y increase by 1, stay on same line
                    Y -= 1
                    # move one "back" for X too
                    X -= 1
                    while totalBtmCount < (priorWidth + 1):
                        if (letterIdx >= len(numbers[numCount])):
                            letterIdx = 0
                        grid[Y][X] = numbers[numCount][letterIdx]
                        X -= 1
                        letterIdx += 1
                        totalBtmCount += 1
                    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    # LEFT SIDE:
                    # pull X back "right" by one, decrease Y
                    X += 1
                    Y -= 1
                    while totalLeftCount < (priorHeight - 1):
                        if (letterIdx >= len(numbers[numCount])):
                            letterIdx = 0
                        grid[Y][X] = numbers[numCount][letterIdx]
                        Y -= 1
                        letterIdx += 1
                        totalLeftCount += 1
                #---------------------------------------------------------
                #RESET FOR NEXT NUMBER
                numCount += 1
                totalNumbersOutput += 1
                if (totalNumbersOutput == 1):
                    X = X_START
                    Y = Y_START - 1
            #-------------------------------------------------------------
            # All done. Start the output
            Y += 1 # (rewind back to where we were before the final character was output)
            priorWidth += 2 #update the width to the new total width
            # start outputting the characters
            for out_x in range(Y,(Y+priorHeight)):
                for out_y in range(X,(X+priorWidth)):
                    print(grid[out_x][out_y],end='')
                print('')
        else:
            print('** ERROR ** data file is malformed')
    else:
        print('** ERROR ** data file is malformed')
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)

# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    # counter = -1
    for file in files:
        if ('in.txt' in file):
            # counter +=1
            # print('')
            # print('')
            # print(f'example {counter}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

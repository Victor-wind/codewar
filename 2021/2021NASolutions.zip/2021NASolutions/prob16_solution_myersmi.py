# Easy. 20ish minutes. Instructions are clear

import sys

def convert_B_to_bytes(num, size):
    total = num
    if size == "ZB":
        size = "EB"
        total *= 1000.0
    if size == "EB":
        size = "PB"
        total *= 1000.0
    if size == "PB":
        size = "TB"
        total *= 1000.0
    if size == "TB":
        size = "GB"
        total *= 1000.0
    if size == "GB":
        size = "MB"
        total *= 1000.0
    if size == "MB":
        size = "KB"
        total *= 1000.0
    if size == "KB":
        size = "B"
        total *= 1000.0
    return total

def convert_bytes_to_iB(total):
    current = total
    if current < 1024.0:
        return current, "B"
    current = current / 1024.0
    if current < 1024.0:
        return current, "KiB"
    current = current / 1024.0
    if current < 1024.0:
        return current, "MiB"
    current = current / 1024.0
    if current < 1024.0:
        return current, "GiB"
    current = current / 1024.0
    if current < 1024.0:
        return current, "TiB"
    current = current / 1024.0
    if current < 1024.0:
        return current, "PiB"
    current = current / 1024.0
    if current < 1024.0:
        return current, "EiB"
    current = current / 1024.0
    return current, "ZiB"



if __name__ == "__main__":
    inputText = sys.stdin.read().split()

    num = float(inputText[0])
    size = inputText[1]

    byte_total = convert_B_to_bytes(num, size)
    result, ib = convert_bytes_to_iB(byte_total)


    print("{:.2f} {}".format(result, ib))
## Time to Solve 12 min

import glob

def main(data):
    '''
    '''

    method = data[0]
    people_required = int(data[1]) 
    method_duration = int(data[2]) #minutes
    startup_time = int(data[3]) #seconds
    power_output = float(data[4]) #Watts/hour
    people_available = int(data[5])
    target = 1210000000

    running_time = method_duration - startup_time

    if running_time >= 1:
        total_possible_running = int(people_available/people_required)
        pops = power_output/360 #power output per second

        result = pops * total_possible_running


    # Cannot sustain for 1 second
    else:
        result = 0

    retval = '{} can generate {} watts/second'.format(method, result)
    if result > target:
        retval += "\nMARTY CAN MAKE IT!"
    else:
        retval += "\nWHOA, HEAVY!"

    print(retval)

if __name__ == "__main__":
    print("---- JUDGE ----")  
    for file in glob.glob("*judge*in*.txt"):
        print(file)
        data_set = open(file, 'r').read().split('\n')
        print('---------')
        main(data_set)

    print("---- STUDENT ----")    
    for file in glob.glob("*student*in*.txt"):
        print(file)
        data_set = open(file, 'r').read().split('\n')
        print('---------')
        main(data_set)
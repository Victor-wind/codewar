#!/bin/python3
# Solved by karthik.r@hpe.com

import sys
import math

CONCRETE = [0.90, 0.62, 0.57]
WOOD = [0.80, 0.42, 0.30]
STEEL = [0.70, 0.30, 0.74]
RUBBER = [1.15, 0.80, 0.70]
ICE = [0.15, 0.05, 0.03]

SKI_MATERIAL = {'RUBBER':0, 'WOOD':1, 'STEEL':2}
SURFACE_MATERIAL = {'CONCRETE':CONCRETE, 'WOOD':WOOD, 'STEEL':STEEL, 'RUBBER':RUBBER, 'ICE':ICE}

def parse_inputs():
    inputs = []
    for line in sys.stdin:
        inputs.append(line.rstrip())
    return inputs[0].split()

def solution():
    mat, surface = parse_inputs()

    value = float(SURFACE_MATERIAL[surface][SKI_MATERIAL[mat]])
    print(SURFACE_MATERIAL[surface][SKI_MATERIAL[mat]], round(float(math.degrees(math.atan(value))),1) )
        
   
if __name__ == '__main__':
    solution()

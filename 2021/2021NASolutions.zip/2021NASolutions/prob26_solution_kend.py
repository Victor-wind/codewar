# CodeWars 2021 - Fly You Fools
#
# Read the Maze. 
# G - a door that opens (-3)
# R - a door that closes (-2)
# Flood the maze from B to F.  If you reach R/G change it to wall or path and use it as such.
# Record the path in reverse order.
# Translate path to compass directions

#globals, overwritten during input
debugPrint = False

import sys

def addSquare(row,col,t):
    global g
    global done
    global rows
    global cols
    #First check if this is a door
    if g[row][col][0] == -2:            # Red Door
        if debugPrint:
            print("R:",row,col)
        if g[row][col][1]>t:            # Door is open when we arrive.  Change to path
            g[row][col][0]=0
        else:                           # Door is closed when we arrive. Change to wall
            g[row][col][0]=-1
    elif g[row][col][0] == -3:          # Green Door
        if debugPrint:
            print("G:",row,col)
        if g[row][col][0]<t:            # Door is open when we arrive.  Change to path
            g[row][col][0]=0
        else:                           # Door is closed when we arrive. Change to wall
            g[row][col][1]=-1
    # Now the square is either wall (-1), path (0), or filled (>0)
    # Only if empty, fill and add to the analysis.
    if g[row][col][0] == 0:
        g[row][col][0] = t
        rows.append(row)
        cols.append(col)
    if (row==fRow) and(col==fCol):
        done=True
    return

#-----------------------
def printGrid(g):
    for i in range(height):
        for j in range(width):
            print (g[i][j][0]," ",sep='',end='')
        print('')
#-----------------------
def nextSquare(r,c):
    global g
    t=g[r][c][0]
    if r>0:
        v=g[r-1][c][0]
        if v>0 and v<t:
            return r-1,c
    if r<height-1:
        v=g[r+1][c][0]
        if v>0 and v<t:
            return r+1,c
    if c>0:
        v=g[r][c-1][0]
        if v>0 and v<t:
            return r,c-1
    # MUST be last option
    return r,c+1

#------------------------------------------------------------------------
# Main program starts here.

line     = sys.stdin.readline().rstrip('\n').rstrip(' ');
words    = line.split(' ')
width    = int(words[0])
height   = int(words[1])
doors    = int(words[2])

g = [[[0 for x in range(2)]for x in range(width)] for x in range(height)] # Working grid

sRow=0
sCol=0
fRow=0
fCol=0
# Read in the grid
for i in range(height):
    line = sys.stdin.readline().rstrip('\n').rstrip(' ')             # "." = unknown (0).  "1/2/3/4" = Tatami
    if debugPrint:
        print(line)
    for j in range(width):
        square = line[j]
        val = 0
        if square == '#':                   # wall = -1
            val = -1
        elif square == 'R':                 # Red Door = -2
            val = -2
        elif square == 'G':                 # Green Door = -3
            val = -3
        elif square == 'B':                 # Start Square
            sRow=i
            sCol=j
            val=0
        elif square == 'F':                 # Finish Square
            fRow=i
            fCol=j
            val=0
        else:
            val=0
        g[i][j][0]=val                      #[0] is the value. [1] is the time

# Read in the doors  C N X Y: color, time, column, row
for i in range(doors):
    line = sys.stdin.readline()
    words    = line.split(' ')
    row      = int(words[3])
    col      = int(words[2])
    time     = int(words[1])
    g[row][col][1]=time

# Create the row/col lists to use to fill the grid
rows = [sRow]
cols = [sCol]
g[sRow][sCol][0]=1
if debugPrint:
    print("Start:",sRow,sCol,rows,cols)

# Fill the Grid from start to finish
i=0
done=False
while i<len(rows) and not done:
    curR=rows[i]
    curC=cols[i]
    t=g[curR][curC][0]
    if t==1:        # Special case for start square
        t=0
    if curR>0:      # Up
        addSquare(curR-1,curC,t+2)
    if curR<height-1:
        addSquare(curR+1,curC,t+2)
    if curC>0:      #Left
        addSquare(curR,curC-1,t+2)
    if curC<width-1:
        addSquare(curR,curC+1,t+2)
    i+=1
# Grid now holds the path from start to finish.
if debugPrint:
    printGrid(g)

# Starting at finish, look for the lower numbered square and fill the array.
curR=fRow
curC=fCol
rows=[fRow]
cols=[fCol]

while not (curR==sRow and curC==sCol):
    if debugPrint:
        print(curR,curC)
    curR,curC = nextSquare(curR,curC)
    rows.insert(0,curR)
    cols.insert(0,curC)

if debugPrint:
    print("Path:",rows,cols)

# We have the path.  Find the direction, then see how far we go in that direction and print.
i=0
while i<len(rows)-1:
    rDiff=rows[i]-rows[i+1]
    cDiff=cols[i]-cols[i+1]
    if rDiff==1:
        dir='N'
    elif rDiff==-1:
        dir='S'
    elif cDiff==1:
        dir='W'
    else:
        dir='E'
    # Now check for longer length
    j=i+1
    length=1
    turn=0
    while j<len(rows)-1 and turn==0:
        if rows[j]-rows[j+1] == rDiff and cols[j]-cols[j+1]==cDiff:
            length+=1
            j+=1
        else:
            turn=1
    print(dir, length)
    i+=length




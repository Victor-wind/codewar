# Elmo's Rectangle
#
# First create a text array.  Then read input.
import sys

debugPrint = False

numbers = ["" for x in range(101)]  # Numbers strings

numbers[1  ] = "one"
numbers[2  ] = "two"
numbers[3  ] = "three"
numbers[4  ] = "four"
numbers[5  ] = "five"
numbers[6  ] = "six"
numbers[7  ] = "seven"
numbers[8  ] = "eight"
numbers[9  ] = "nine"
numbers[10 ] = "ten"
numbers[11 ] = "eleven"
numbers[12 ] = "twelve"
numbers[13 ] = "thirteen"
numbers[14 ] = "fourteen"
numbers[15 ] = "fifteen"
numbers[16 ] = "sixteen"
numbers[17 ] = "seventeen"
numbers[18 ] = "eighteen"
numbers[19 ] = "nineteen"
numbers[20 ] = "twenty"
numbers[21 ] = "twentyone"
numbers[22 ] = "twentytwo"
numbers[23 ] = "twentythree"
numbers[24 ] = "twentyfour"
numbers[25 ] = "twentyfive"
numbers[26 ] = "twentysix"
numbers[27 ] = "twentyseven"
numbers[28 ] = "twentyeight"
numbers[29 ] = "twentynine"
numbers[30 ] = "thirty"
numbers[31 ] = "thirtyone"
numbers[32 ] = "thirtytwo"
numbers[33 ] = "thirtythree"
numbers[34 ] = "thirtyfour"
numbers[35 ] = "thirtyfive"
numbers[36 ] = "thirtysix"
numbers[37 ] = "thirtyseven"
numbers[38 ] = "thirtyeight"
numbers[39 ] = "thirtynine"
numbers[40 ] = "forty"
numbers[41 ] = "fortyone"
numbers[42 ] = "fortytwo"
numbers[43 ] = "fortythree"
numbers[44 ] = "fortyfour"
numbers[45 ] = "fortyfive"
numbers[46 ] = "fortysix"
numbers[47 ] = "fortyseven"
numbers[48 ] = "fortyeight"
numbers[49 ] = "fortynine"
numbers[50 ] = "fifty"
numbers[51 ] = "fiftyone"
numbers[52 ] = "fiftytwo"
numbers[53 ] = "fiftythree"
numbers[54 ] = "fiftyfour"
numbers[55 ] = "fiftyfive"
numbers[56 ] = "fiftysix"
numbers[57 ] = "fiftyseven"
numbers[58 ] = "fiftyeight"
numbers[59 ] = "fiftynine"
numbers[60 ] = "sixty"
numbers[61 ] = "sixtyone"
numbers[62 ] = "sixtytwo"
numbers[63 ] = "sixtythree"
numbers[64 ] = "sixtyfour"
numbers[65 ] = "sixtyfive"
numbers[66 ] = "sixtysix"
numbers[67 ] = "sixtyseven"
numbers[68 ] = "sixtyeight"
numbers[69 ] = "sixtynine"
numbers[70 ] = "seventy"
numbers[71 ] = "seventyone"
numbers[72 ] = "seventytwo"
numbers[73 ] = "seventythree"
numbers[74 ] = "seventyfour"
numbers[75 ] = "seventyfive"
numbers[76 ] = "seventysix"
numbers[77 ] = "seventyseven"
numbers[78 ] = "seventyeight"
numbers[79 ] = "seventynine"
numbers[80 ] = "eighty"
numbers[81 ] = "eightyone"
numbers[82 ] = "eightytwo"
numbers[83 ] = "eightythree"
numbers[84 ] = "eightyfour"
numbers[85 ] = "eightyfive"
numbers[86 ] = "eightysix"
numbers[87 ] = "eightyseven"
numbers[88 ] = "eightyeight"
numbers[89 ] = "eightynine"
numbers[90 ] = "ninety"
numbers[91 ] = "ninetyone"
numbers[92 ] = "ninetytwo"
numbers[93 ] = "ninetythree"
numbers[94 ] = "ninetyfour"
numbers[95 ] = "ninetyfive"
numbers[96 ] = "ninetysix"
numbers[97 ] = "ninetyseven"
numbers[98 ] = "ninetyeight"
numbers[99 ] = "ninetynine"
numbers[100] = "onehundred"


#------------------------------------------------------------------------
# printGrid
def printGrid(g,h,w):
    for i in range(h):
        for j in range(w):
            print (g[i][j], sep='', end='')
        print('')

#------------------------------------------------------------------------
# nextPerimeter
# - Given the min/max corners and current location,
#     return the next square clockwise around the perimeter
def nextPerimeter(rMin,cMin,rMax,cMax,r,c):
    if r==rMin:             # Top
        if c==cMax:         # Top-Right, move down
            return r+1, c
        else:               # Move Right
            return r, c+1
    elif c==cMax:           # Right
        if r==rMax:         # Bottom, move left
            return r, c-1
        else:               # Move Down
            return r+1, c
    elif r==rMax:           # Bottom
        if c==cMin:         # Left, move up
            return r-1, c
        else:               # Move left
            return r, c-1
    else:                   # Left Wall is all that's left (c==cMin
        if r==rMin:         # Top, move right
            return r, c+1
        else:               # Move up
            return r-1, c

#------------------------------------------------------------------------
# Main program starts here.

line     = sys.stdin.readline().rstrip('\n').rstrip(' ');
words    = line.split(' ')
start    = int(words[0])
startLen = len(numbers[start])
end      = int(words[1])
endLen   = len(numbers[end])
if debugPrint:
    print("Start End: ",start," ",end, " ",numbers[start],"(",startLen,") ",numbers[end],"(",endLen,")", sep='')

# Calculate grid size
# Center word is startLen and is one line
# Each following word adds one line above and below, and one character right and left
gridHeight = 1 + 2*(end-start)
gridWidth = startLen + 2*(end-start)
startRow = end-start # grid is 0-based
startCol = end-start
if debugPrint:
    print("Grid Height and Width:", gridHeight, gridWidth)

#initialize a grid of dots
grid = [['.' for x in range(gridWidth)] for x in range(gridHeight)] # Working grid
if debugPrint:
    printGrid(grid,gridHeight,gridWidth)
    print('')

# Place first word
for j in range(startCol, startCol+startLen):
    grid[startRow][j] = numbers[start][j-startCol]

if debugPrint:
    printGrid(grid,gridHeight,gridWidth)

# Rectangle Loops
# Determine corners for first rectangle and the number we're writing
currentNum = start+1
currentNumIndex = 0
rMin = startRow-1
cMin = startCol-1     
rMax = startRow+1
cMax = startCol+startLen
curR = rMin
curC = startCol     # Second starts immediately above first rectangle

while curR >= 0:                         # End when we leave the grid
    while grid[curR][curC] == '.':       # Fill the empty squares on the perimeter
        grid[curR][curC] = numbers[currentNum][currentNumIndex]
        currentNumIndex = (currentNumIndex+1) % len(numbers[currentNum])
        curR, curC = nextPerimeter(rMin,cMin,rMax,cMax,curR,curC)
    # Set next rectangle's data
    rMin -= 1
    cMin -= 1
    rMax += 1
    cMax += 1
    curR = rMin
    curC = cMin+1       # Each rectangle starts above the (rMin,cMin) of the previous
    currentNum += 1
    currentNumIndex = 0

printGrid(grid, gridHeight, gridWidth)

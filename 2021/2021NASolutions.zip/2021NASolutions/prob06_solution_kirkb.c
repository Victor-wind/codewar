#include <stdio.h>
char code[] = "FGHIJKLMNOPQRSTUVWXYZABCDE";

char decode(c) char c; {
int i=0;
while(code[i]!=c) i++;
return(i+'A');
}

int main(argc,argv) int argc; char **argv; {
int n;
char c;
fscanf(stdin,"%d ",&n);

while((c=getchar())!=EOF) 
 putchar(((c>='A')&&(c<='Z'))?decode(c):c);
}


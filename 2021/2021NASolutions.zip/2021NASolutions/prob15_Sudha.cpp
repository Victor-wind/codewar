// probAE_Sudha.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>    // std::sort
#include <fstream>

using namespace std;

vector<string> GemList;
vector<string> WithGem;
vector<string> WithOutGem;
vector<string> FinalList;

void FillGemList()
{
    GemList.push_back("Lapis");
    GemList.push_back("Topaz");
    GemList.push_back("Tourmaline");
    GemList.push_back("Sapphire");
    GemList.push_back("Peridot");
    GemList.push_back("Ruby");
    GemList.push_back("Pearl");
    GemList.push_back("Emerald");
    GemList.push_back("Diamond");
    GemList.push_back("Aquamarine");
    GemList.push_back("Amethyst");
    GemList.push_back("Garnet");
}
 void FindGem(string str)
{
    int nLen = GemList.size();
    bool bFound = false;
    for (int i = 0; i < nLen; i++)
    {
        std::size_t found = str.find(GemList[i]);
        if (found != std::string::npos)
        {
            int nSize = WithGem.size();
            if (nSize == 0)
                WithGem.push_back(str);
            else
            {
                bool ValFound = false;
                for (int k = 0; k < nSize; k++)
                {
                    if (WithGem[k] == str)
                        ValFound = true;
                }
                if (!ValFound)
                    WithGem.push_back(str);
            }
            bFound = true;
        }
    }
    if (!bFound)
        WithOutGem.push_back(str);
}
void GetValues(string filename)
{
    ifstream b_file(filename); // "probAT-2-in.txt");
    string str;
    while (getline(b_file, str)) {
        if (str == "END")
            return;
        FindGem(str);
    }
}
void FillFinal()
{
    int wlen = WithGem.size();
    if (wlen > 0)
    {
        for (int i = 0; i < wlen; i++)
            FinalList.push_back(WithGem[i]);
    }
    int nLen = WithOutGem.size();
    std::sort(WithOutGem.begin(), WithOutGem.end());
    for (int i = 0; i < nLen; i++)
        FinalList.push_back(WithOutGem[i]);
}
int main(int argc, char* argv[])
{
    FillGemList();
    GetValues(argv[1]);
    FillFinal();
    int kLen = FinalList.size();
    for (int i = 0; i < kLen; i++)
        cout << FinalList[i] << endl;
}

// Run program: Crl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file

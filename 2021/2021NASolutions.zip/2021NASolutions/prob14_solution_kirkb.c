#include <stdio.h>
#include <string.h>

int main(argc,argv) int argc; char **argv; {

char *text[] = { "1/4", "1/3", "1/2", "1", "2", "3", 0};
double amt[] = { 0.25,  0.33,  0.5,   1.0, 2.0, 3.0, 0};

double count,size,limit;
double damage;
char buf[32];
int i;

fscanf(stdin,"%lf %s %lf",&count,buf,&limit);
for(i=0;amt[i];i++)
 if(strcmp(text[i],buf)==0)
  size=amt[i];

damage = 0.45 * 7.5 * count * size;

printf("%.2f the Mask %s eat it!\n",damage,(damage<=limit)?"can":"should not");
}


import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
import java.text.DecimalFormat;//required for rounding
public class prob14_Solution_McAdams {
/*
PROBLEM: Smokin'!
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 10 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 14 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-08
WHAT IT TESTS: 
    1.) Ability to handle fractional data in math operations as well as whole integers
    2.) Ability to split string data
    3.) Ability to run calculations according to a formula
    4.) Ability to extrapolate how to get the final force (we don't hold their hand on this one, they have to figure out how to apply the numbers given - hence the extra point on this problem ^_-)
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.

NOTE: This solution was translated from my original solution in Python, into Java. I did that for the first 15 problems in the packet
so students who only code in Java will have solutions to look at in their native coding language. The algorithms are the same. The only
parts which change are language specific things (such as how to access list elements). I also collapsed some functions out of python
back into the main program in Java, just to save time. By comparing these 15 translated Java programs to their original Python
implementations, you should be able to pull out Java coding from the rest of the Python solutions, if you'd like. The techniques and
coding functionality used should (more or less) stay the same for the rest of the Python solutions I did. I tend to stick to basics
when at all possible: lists, dictionaries, loops, and logic structures. The only one which might get a little tricky going from
Python to Java will be Pirate Parlay(#27). If you get that one working, I will be impressed :)
*/
	//------------------------------------------------------------------------
	// CHANGE THIS BEFORE SUBMITTING!
	private static final boolean AM_DEBUGGING = true;
	private static final boolean DATA_STUDENT = true;
	private static final String DEBUG_PROB_ID = "prob14";
	private static final int DEBUG_PROB_IN = 1;
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";
	private static final boolean DEBUG_MODE_ALL = true;
	//------------------------------------------------------------------------
	public static void main(String[] args) {
		try
		{
			GetData();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void MainProgram(List<String> lines) {
		if (lines.size() > 0)
		{
		    // Math ... amirite? (╯° °）╯︵ ┻━┻

		    // Relevant info from problem:
		    // 1 whole stick of dynamite weighs 0.45 kilograms (kg)
		    // 7.5MJ of explosive force are released when 1kg of dynamite explodes.
		    // Yes ... I *am* worried that I am on some sort of DHS list now 
		    // after looking up those numbers for you. The things I suffer for CodeWars ... ^^;

		    // input format: N M YY
		    // N  =  number of sticks
		    // N  =  size of stick
		    // YY = damage mask can sustain as a tensile limit with respect to force as MJ (if you haven't had physics yet, then ... *MAGIC!*)

		    // Biggest problem with this problem (heh) is the fractional sizes.
		    // Without those things there this would be a very simple math problem.
		    // But we're going to have to convert the whole number fractions to decimal
		    // values if we get them. Other than that, the problem is simply: figure out
		    // how many kilograms (kg) of dynamite we have, then figure out how much
		    // explosive force that amount of dynamite would generate (note that LESS 
		    // than 1kg of dynamite is what we give for the MJ generated, a little more math
		    // will have to be done by the students to get the final numbers), then compare
		    // that to the amount of force the Mask can currently withstand. If the dynamite
		    // will produce less than or equal to the force the Mask can withstand, then
		    // print the success message. Else, print the "run away! ε=ε=┏( >_<)┛" message
		    String[] parts = lines.get(0).strip().split(" ");
		    if (parts.length > 2){
		        int sticks = Integer.parseInt(parts[0]);
		        double size = 0;
		        if (parts[1].indexOf("/") >=0)
		        {
		            String[] fraction = parts[1].strip().split("/");
		            if (fraction.length > 1 && !fraction[1].strip().equals("0"))
		            {
		                size = Double.parseDouble(fraction[0]) / Double.parseDouble(fraction[1]);
		            }
		        }
		        else
		        {
		            size = Integer.parseInt(parts[1]);
		        }
		        int limit = Integer.parseInt(parts[2]);
		        double dynamite = sticks * size;
		        double force = (dynamite*0.45) * 7.5;
		        DecimalFormat df = new DecimalFormat("0.00");//constant for rounding decimals
		        String forcePrint = df.format(force);
		        if (force <= limit)
		        {
		            print(forcePrint+" the Mask can eat it!");
		        }
		        else
		        {
		            print(forcePrint+" the Mask should not eat it!");
		        }
		    }
		    else{
		        print("** ERROR ** data file is malformed");
		    }
		}
		else
		{
			print("*****Error Malformed Data");
		}
	}
	private static List<String> inputFromStdIn() {
		List<String> lines =new ArrayList<String>();
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static void GetData() throws IOException {
		String dataset = "student";
		if (!DATA_STUDENT) {
			dataset = "judge";
		}
		if (AM_DEBUGGING) {
			if (DEBUG_MODE_ALL) {
				List<String> datasets =new ArrayList<String>();
				File datasetFolder = new File(DEBUG_PATH+"\\"+dataset+"_datasets\\");
				File[] files = datasetFolder.listFiles();
				for (File f:files) {
					if (f.isFile()) {
						if (f.getName().indexOf(DEBUG_PROB_ID) > -1 && f.getName().indexOf("in") > -1)
						{
							datasets.add(f.getName());
						}
					}
				}
				for (String file: datasets) {
					print("--------------------------------------------------------------------------------------");
					print("DEBUGGING OUTPUT FOR: "+file);
					MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+file).toPath()));
				}
			}
			else {
				MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+DEBUG_PROB_ID+
						"-"+DEBUG_PROB_IN+"-in.txt").toPath()));
			}
		}
		else{
			MainProgram(inputFromStdIn());
		}
	}
	private static void print(String s) {
		//shortcut for moving back and forth between Python (and, also, (and I cannot stress this enough), I hate typing out the full System.out.println() ceremony every time
		System.out.println(s);
	}
}

import sys
import time
import math
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAD' #prob07
# ------------------------------------------------------------------------

'''
PROBLEM: Can I Ski It?
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 12 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 14 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-01-31
WHAT IT TESTS: 
    1.) Ability to organize and reference tabular data
    2.) Ability to parse data from strings
    3.) Ability to either use the arctan functions of your language's math library, or calculate arctan on your own
    4.) Ability to force output to degrees from your language's arctan function (or calculate it yourself)
    5.) Ability to format and round floating point decimals
    6.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))

# ========================================================================
def Main(lines=[]):
    'Main Program'
    #taking the easy/lazy way out and just throwing up a dict. with all of the possible combinations
    table = {
         'CONCRETE RUBBER':0.90
        ,'CONCRETE WOOD':0.62
        ,'CONCRETE STEEL':0.57
        ,'WOOD RUBBER':0.80
        ,'WOOD WOOD':0.42
        ,'WOOD STEEL':0.30
        ,'WOOD CONCRETE':0.62
        ,'WOOD ICE':0.05
        ,'STEEL	RUBBER':0.70
        ,'STEEL	WOOD':0.30
        ,'STEEL	STEEL':0.74
        ,'STEEL CONCRETE':0.57
        ,'STEEL ICE':0.03
        ,'RUBBER RUBBER':1.15
        ,'RUBBER WOOD':0.80
        ,'RUBBER STEEL':0.70
        ,'RUBBER CONCRETE':0.90
        ,'RUBBER ICE':0.15
        ,'ICE RUBBER':0.15
        ,'ICE WOOD':0.05
        ,'ICE STEEL':0.03
    }
    if (len(lines) > 0):
        coefficient = table[lines[0].strip()]
        arctan = math.degrees(math.atan(coefficient))
        coef = format(coefficient,'0.2f')
        degrees = format(round(arctan,1),'.1f')
        print(f'{coef} {degrees}')
    else:
        print('** ERROR ** data file is malformed')

# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)

# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    for file in files:
        if ('in.txt' in file):
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

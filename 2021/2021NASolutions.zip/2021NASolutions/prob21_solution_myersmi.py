# 25ish minutes. Instructions are clear. I almost missed the square MOJO rule but caught it thanks to the 4 example.

import sys

def get_coords(lines):
    M = ""
    O1 = ""
    J = ""
    O2 = ""
    for i, line in enumerate(lines):
        for j, char in enumerate(line):
            if char == "M":
                if j - 3 >= 0 and line[j-3:j] == "OJO":
                    M = "{},{}".format(j,i)
                    O1 = "{},{}".format(j-1,i)
                    J = "{},{}".format(j-2,i)
                    O2 = "{},{}".format(j-3,i)
                    break
                if j + 3 < len(line) and line[j+1:j+4] == "OJO":
                    M = "{},{}".format(j,i)
                    O1 = "{},{}".format(j+1,i)
                    J = "{},{}".format(j+2,i)
                    O2 = "{},{}".format(j+3,i)
                    break
                if i - 3 >= 0 and lines[i-1][j] == "O" and lines[i-2][j] == "J" and lines[i-3][j] == "O":
                    M = "{},{}".format(j,i)
                    O1 = "{},{}".format(j,i-1)
                    J = "{},{}".format(j,i-2)
                    O2 = "{},{}".format(j,i-3)
                    break
                if i + 3 < len(lines) and lines[i+1][j] == "O" and lines[i+2][j] == "J" and lines[i+3][j] == "O":
                    M = "{},{}".format(j,i)
                    O1 = "{},{}".format(j,i+1)
                    J = "{},{}".format(j,i+2)
                    O2 = "{},{}".format(j,i+3)
                    break
                if i + 1 < len(lines) and j + 1 < len(line) and line[j+1] == "O" and lines[i+1][j:j+2] == "JO":
                    M = "{},{}".format(j,i)
                    O1 = "{},{}".format(j+1,i)
                    J = "{},{}".format(j,i+1)
                    O2 = "{},{}".format(j+1,i+1)
                    break
        else:
            continue
        break
    return M, O1, J, O2

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()

    M, O1, J, O2 = get_coords(inputText)

    print("M: {}".format(M))
    print("O: {}".format(O1))
    print("J: {}".format(J))
    print("O: {}".format(O2))



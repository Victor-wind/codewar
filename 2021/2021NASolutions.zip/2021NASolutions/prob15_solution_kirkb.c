#include <stdio.h>
#include <string.h>

#define MAXP 30
#define BUFLEN 256

char *gems[]= { "NONE", "Garnet", "Amethyst", "Aquamarine", "Diamond",
                "Emerald", "Pearl", "Ruby", "Peridot", "Sapphire",
                "Tourmaline", "Topaz", "Lapis", 0};

char ponies[MAXP][BUFLEN];
int  gp[MAXP];
int count=0;

int decode(c) char *c; {
int r;
for(r=0;gems[r];r++)
 if(strcmp(gems[r],c)==0) break;
return(gems[r]?r:0);
}

void swap(a,b) int a,b;{
char tc[BUFLEN];
int  tp;

tp=gp[a]; strcpy(tc,ponies[a]);
gp[a]=gp[b]; strcpy(ponies[a],ponies[b]);
gp[b]=tp; strcpy(ponies[b],tc);
}

int greater(a,b) int a,b;{
if(gp[a]>gp[b]) return 0;
if(gp[b]>gp[a]) return 1;
return strcmp(ponies[a],ponies[b])>0;
}

void sort() {
int i,f;

do {
 for(f=i=0;i<(count-1);i++)
  if(greater(i,i+1)) {
   swap(i,i+1); f++; }
   } while(f);
}

void dump() {
int i;
for(i=0;i<count;i++)
 printf("%s",ponies[i]);
 }

int main(argc,argv) int argc; char **argv; {
char buf[BUFLEN];
char part[BUFLEN];
int p=0;
int r;
int i,j;
char *s;

while(fgets(buf,BUFLEN-1,stdin),strncmp("END",buf,3)!=0) {
 strcpy(ponies[p],buf);
 gp[p]=0;
 r=0;
 s=ponies[p];
 while(sscanf(s,"%s%n",part,&j)!=EOF) {
  gp[p]=((i=decode(part))>gp[p])?i:gp[p];
  s+=j;
 }
 p++;
 }

count=p;
sort();
dump();
}


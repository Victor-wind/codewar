import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required to parse split from array into List
import java.util.Collections;//required to sort a generic list
import java.util.Dictionary;//required for basic Dictionary functionality
import java.util.Hashtable;//required type to implement the raw data type of Dictionary
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
public class prob15_Solution_McAdams {
/*
PROBLEM: Everypony line up!
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 9 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 12 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-01-31
WHAT IT TESTS: 
    1.) Ability to sort a list/array of data (either manually or through library functions)
    2.) Ability to sort and combine two separate lists/arrays
    3.) Ability to look up ranking/value/index of items in a list/array
    4.) Ability to use dictionaries, or similar structures, to organize groups of data
    5.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.

NOTE: This solution was translated from my original solution in Python, into Java. I did that for the first 15 problems in the packet
so students who only code in Java will have solutions to look at in their native coding language. The algorithms are the same. The only
parts which change are language specific things (such as how to access list elements). I also collapsed some functions out of python
back into the main program in Java, just to save time. By comparing these 15 translated Java programs to their original Python
implementations, you should be able to pull out Java coding from the rest of the Python solutions, if you'd like. The techniques and
coding functionality used should (more or less) stay the same for the rest of the Python solutions I did. I tend to stick to basics
when at all possible: lists, dictionaries, loops, and logic structures. The only one which might get a little tricky going from
Python to Java will be Pirate Parlay(#27). If you get that one working, I will be impressed :)
*/
	//------------------------------------------------------------------------
	// CHANGE THIS BEFORE SUBMITTING!
	private static final boolean AM_DEBUGGING = true;
	private static final boolean DATA_STUDENT = false;
	private static final String DEBUG_PROB_ID = "prob15";
	private static final int DEBUG_PROB_IN = 1;
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";
	private static final boolean DEBUG_MODE_ALL = true;
	//------------------------------------------------------------------------
	public static void main(String[] args) {
		try
		{
			GetData();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void MainProgram(List<String> lines) {
	    //taking the easy/lazy way out and just throwing up a dict. with all of the possible combinations
	    List<String> gems = Arrays.asList("Lapis","Topaz","Tourmaline","Sapphire","Peridot","Ruby","Pearl","Emerald","Diamond","Aquamarine","Amethyst","Garnet");
	    if (lines.size() > 0){
	        //setup a list for both types of ponies. Regular ponies just get sorted. Royal ponies have an extra step
	    	List<String> regularPonies = new ArrayList<String>();
	    	List<String> royalPonies = new ArrayList<String>();
	        for (String pony: lines){
	            pony = pony.strip();
	            if (!pony.equals("END")){
	                //split the name into parts on the space character
	            	String[] nameParts = pony.split(" ");
	                //look at each part of the name, and compare it to the gems list
	                //if the name part is in the gems list (as a stand-alone word)
	                //then the pony is royal, add them to the royals list
	                //else, add them to the regular ponies list
	                for (String part:nameParts){
	                    if (gems.indexOf(part) > -1){
	                        royalPonies.add(pony);
	                        break;
	                    }
	                }
	                if (!royalPonies.contains(pony)){
	                    regularPonies.add(pony);
	                }
	            }
	        }
	        // simply print the royal list if it is empty or has only one pony in it
	        // (the for loop will skip if it is empty)
	        if (royalPonies.size() <= 1){
	            for (String pony:royalPonies){
	                print(pony);
	            }
	        }
	        else{
	            // however, if there is more than one pony in the royal list, now we have
	            // a problem. We can't simply sort the list, because we aren't sorting
	            // alphabetically, we are sorting by gem stone ranking. There are lots of
	            // ways to solve this, including a custom sorting algorithm, but the way
	            // I chose to solve this was with a dictionary (hash in other languages)
	            // keyed on the gem stone names, with a value of a sorted list of the 
	            // ponies matching that gem stone.
	        	Dictionary<String, List<String>> royalsGrouped = new Hashtable<String, List<String>>(); 
	            //iterate through the gems list, in order
	            for (String gem:gems){
	                List<String> tmp = new ArrayList<String>();
	                //iterate through the royal ponies we have
	                for (String royal:royalPonies){
	                    //if the gem name stands alone (has a space before or after it),
	                    //or the entire name of the pony IS the gem name, add it to the list
	                    if (royal.indexOf((gem+" ")) > -1 || royal.indexOf((" "+gem)) > -1 || royal.equals(gem)){
	                        tmp.add(royal);
	                    }
	                }
	                // if the list is not empty, sort it, then add the list as the value of
	                // a dictionary item keyed to the gem stone name
	                if (tmp.size() > 0){
	                    Collections.sort(tmp);
	                    royalsGrouped.put(gem, tmp);
	                }
	            }
	            // create a list to keep track of ponies already printed
	            //(have to do this, or something like this, to account for
	            // ponies that have more than one gem stone in their name, as
	            // they will show up in the value lists for more than one gemstone)
	            List<String> royalsPrinted = new ArrayList<String>();
	            //Because the Java implementation of Dictionary hashes DOES NOT GUARANTEE ORDER
	            //We have to be pickier in this solution than in other languages.
	            //Best way to deal with this is to simply iterate over the gemstones again
	            //look for the stone name as a key in the dictionary. If found, output the list
	            for (String gem: gems) {
	            	if (royalsGrouped.get(gem) != null) {
	            		for(String royal:royalsGrouped.get(gem)) {
		                    // if we haven't already printed the royal pony, 
		                    // print it, and add it to the list
		                    if (!royalsPrinted.contains(royal)){
		                        print(royal);
		                        royalsPrinted.add(royal);
		                    }	            			
	            		}
	            	}
	            }
//	            //This won't always work, as Java is squirrely about order in dictionaries
//	            for (Enumeration<List<String>> i = royalsGrouped.elements(); i.hasMoreElements();) 
//	            {
//	            	List<String> value = i.nextElement();
//	                for (String royal:value){
//	                    // if we haven't already printed the royal pony, 
//	                    // print it, and add it to the list
//	                    if (!royalsPrinted.contains(royal)){
//	                        print(royal);
//	                        royalsPrinted.add(royal);
//	                    }
//	                }
//	            } 
	        }
	        // once we are done dealing with the royal ponies, simply sort 
	        // the regular ponies and print their list last
	        Collections.sort(regularPonies);
	        for (String pony:regularPonies){
	            print(pony);
	        }
	    }
		else {
	        print("** ERROR ** data file is malformed");
	    }
	}
	private static List<String> inputFromStdIn() {
		List<String> lines =new ArrayList<String>();
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static void GetData() throws IOException {
		String dataset = "student";
		if (!DATA_STUDENT) {
			dataset = "judge";
		}
		if (AM_DEBUGGING) {
			if (DEBUG_MODE_ALL) {
				List<String> datasets =new ArrayList<String>();
				File datasetFolder = new File(DEBUG_PATH+"\\"+dataset+"_datasets\\");
				File[] files = datasetFolder.listFiles();
				for (File f:files) {
					if (f.isFile()) {
						if (f.getName().indexOf(DEBUG_PROB_ID) > -1 && f.getName().indexOf("in") > -1)
						{
							datasets.add(f.getName());
						}
					}
				}
				for (String file: datasets) {
					print("--------------------------------------------------------------------------------------");
					print("DEBUGGING OUTPUT FOR: "+file);
					MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+file).toPath()));
				}
			}
			else {
				MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+DEBUG_PROB_ID+
						"-"+DEBUG_PROB_IN+"-in.txt").toPath()));
			}
		}
		else{
			MainProgram(inputFromStdIn());
		}
	}
	private static void print(String s) {
		//shortcut for moving back and forth between Python (and, also, (and I cannot stress this enough), I hate typing out the full System.out.println() ceremony every time
		System.out.println(s);
	}
}

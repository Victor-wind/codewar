import re
def main(data_file):

    dictionary = {}

    lambdas = {
        'X': lambda F, K : F/(-K),
        'F': lambda X, K : -K*X,
        'K': lambda F, X : -(F/X),
    }

    #read it line by line as the user would normally get this problem
    for line in data_file:
        try:
            regex = r'(?P<variable>\S+)\s+(?P<value>.*)'
        except:
            break

        regex_retval = re.search(regex, line)

        try:
            variable = regex_retval.group('variable')
            value = regex_retval.group('value')
        except:
            break

        try:
            value = float(value)
        except:
            pass

        dictionary[variable] = value

    print(dictionary)

    if dictionary['X'] == '?':
        missing_var = 'X '
        print(missing_var, end='')
        print(round(lambdas['X'](dictionary['F'], dictionary['K']), 2))

    elif dictionary['F'] == '?':
        missing_var = 'F '
        print(missing_var, end='')
        print(round(lambdas['F'](dictionary['X'], dictionary['K']), 2))
    
    elif dictionary['K'] == '?':
        missing_var = 'K '
        print(missing_var, end='')
        print(round(lambdas['K'](dictionary['F'], dictionary['X']), 2))

data_file = open('probAZ-judge-3-in.txt', 'r').read()
main(data_file.split('\n'))
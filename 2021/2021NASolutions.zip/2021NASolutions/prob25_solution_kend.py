# CodeWars 2021 - Swamp Chase
#
# Read Text File of this format.
# DONKEY
# Y 1 0 0
# 0.000 0.000 +
# SHREK
# A 1 0 2
# 0.000 2.000 +
# B 1 6 0
# -0.200 -1.160 +
# C -9 -2 3
# 0.000 3.000 +

import sys
from math import sqrt

#globals, overwritten during input
debugPrint = False
MISS = 999999.9

eqnName = ['?' for x in range (4)]
eqn = [[(0) for x in range(3)] for x in range(4)] # Donkey:0.  Shrek: 1,2,3
start = [[float(0) for x in range(3)] for x in range(4)]
ints = [[(MISS) for x in range(4)] for x in range(4)]  #X coord for 2 intersections and Dist for 4 equations (Donkey's just a placeholder)
dist = [(MISS) for x in range (4)]
minDist = MISS
minDistName = 'NoName'
minX = MISS
minY = MISS

#---------------------------------------------------
# Read the equation data and the Start Location data
def readEqnAndStart():
    line = sys.stdin.readline().rstrip('\n').rstrip(' '); #  Equation
    words = line.split(' ')
    name = words[0]
    a = int(words[1])
    b = int(words[2])
    c = int(words[3])
    line = sys.stdin.readline().rstrip('\n').rstrip(' '); # Start Location
    words = line.split(' ')                                # X Y +/-
    x = float(words[0])
    y = float(words[1])
    z = -1.0
    if words[2][0] == '+':
        z = 1.0
    return name, a, b, c, x, y, z

#------------------------
# Check valid intersection (moving in the right direction)
def validateInt(ii, jj):
    global minDist, minDistName,minX,minY
    x = ints[ii][jj]
    #Donkey X location is [0][0].  Shrek start X location [ii][0]. Direction at [][2]
    # Adding .0001 to allow for slight variation
    if ((x - start[0][0]) * start[0][2] + .0001 >= 0) and ((x - start[ii][0]) * start[ii][2] + .0001 >= 0):
        #Store Distance
        y = eqn[0][0]*x*x + eqn[0][1]*x + eqn[0][2]
        dist[ii] = sqrt((x-start[ii][0])*(x-start[ii][0]) + (y-start[ii][1])*(y-start[ii][1]))
        ints[ii][jj+2] = dist[ii]
        if dist[ii]<minDist:
            minDist=dist[ii]
            minDistName = eqnName[ii]
            minX = x
            minY = y
        return
    # Not going the right direction
    ints[ii][jj] = MISS

#------------------------------------------------------------------------
# Main program starts here.

line = sys.stdin.readline().rstrip('\n').rstrip(' '); # "DONKEY"
eqnName[0],eqn[0][0],eqn[0][1],eqn[0][2],start[0][0],start[0][1],start[0][2] = readEqnAndStart()

line = sys.stdin.readline().rstrip('\n').rstrip(' '); # "SHREK"
for ii in range(1, 4):
    eqnName[ii],eqn[ii][0],eqn[ii][1],eqn[ii][2],start[ii][0],start[ii][1],start[ii][2] = readEqnAndStart()
    # Recalculate equation by subtracting Donkey's equation to get intersection analysis
    for jj in range(3):
        eqn[ii][jj] = eqn[ii][jj] - eqn[0][jj]     # Subtract a/b/c terms
    # Check for MISS before running Quadratic Formula
    # a==0 and b==0 is a miss since there's a constant difference between equations
    a = eqn[ii][0]
    b = eqn[ii][1]
    c = eqn[ii][2]
    det = (b * b) - 4 * a * c
    if a == 0 and b == 0:
        continue
    # determinant is negative is a miss
    elif ( det ) < 0:
        continue
    # Special case if a is 0, the solution is -c/b
    elif a == 0:
        ints[ii][0] = float(-c / b)
        validateInt(ii,0)
        continue
    else: # Quadratic Formula
        ints[ii][0] = (-b + sqrt(det) ) / (2 * a)
        validateInt(ii,0)
        ints[ii][1] = (-b - sqrt(det) ) / (2 * a)
        validateInt(ii,1)
        if ints[ii][3] < ints[ii][2]:  # store best in the first slot
            ints[ii][0] = ints[ii][1]

for ii in range(1,4):
    print (eqnName[ii]," ",sep='',end='')
    x = ints[ii][0]
    if x<MISS:
        y = round(eqn[0][0]*x*x + eqn[0][1]*x + eqn[0][2],3)
        x = round(x,3)
        print("(",format(x,'0.3f'),",",format(y,'0.3f'),")",sep='')
    else:
        print ("MISS!")
if minX==MISS:
    print("DONKEY GETS AWAY!")
else:
    print (minDistName,"CATCHES DONKEY", format(round(minDist,3),'0.3f'), "METERS AWAY")





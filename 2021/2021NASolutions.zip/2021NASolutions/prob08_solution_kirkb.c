#include <stdio.h>

int main(argc,argv) int argc; char **argv; {
int w,h,m;
int i;

fscanf(stdin,"%d %d %d",&w,&h,&m);
if((h==0)||(h>w))
 for(i=0;i<w;i++)
  printf("#\n");
else {

 for(i=1;i<h-1;i++)
  printf("#\n");
 printf("#");
 for(i=0;i<m/10;i++)
  printf(".");
 for(i=h;i<=w;i++)
  printf("#");
 printf("\n");
 }
 }


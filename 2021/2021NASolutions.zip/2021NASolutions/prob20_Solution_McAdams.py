import sys
import time
import os
from os import path,listdir
from os.path import isfile, join
from collections import Counter

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probBE' #prob20
# ------------------------------------------------------------------------

'''
PROBLEM: Pancaketopia
DIFFICULTY LEVEL: Intermediate
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 22 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 25 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-11
WHAT IT TESTS: 
    1.) Ability to think in 2-dimensional space
    2.) Ability to transpose 2D space coordinates for output
    3.) Ability to adjust for off-by-one errors with loops
    4.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    # The reason why this problem is worth more points than one might expect
    # at first glance is due to the time it will take to solve. Those who
    # jump right in to trying to code a solution for this will most likely
    # lose all of that time when they realize that their initial hunch about
    # solving the problem was (most likely) wrong.
    #
    # There are, of course, a number of ways to solve this problem. But the
    # most straight-forward way to solve it involves loops, lists/arrays and
    # 2D thinking. You could also do the calculations and output the "layers"
    # of the buildings in a calculated output algorithm -- but the number of
    # checks you would have to put into something like that to make sure the
    # layer being output accounted for the heights of all of the buildings in
    # that row makes it just as time-prohibitive as the way I am about to show.
    #
    # My initial thought on solving this was to do a grouping of the buildings
    # by height, and do just such a calculated output as I described above.
    # I wrote about 2 lines on that approach to solving it before I realized it
    # was going to be more trouble than it was worth. Then I took a step back
    # and sketched out on paper what I wanted to output as a 2D grid, and how
    # I could most easily do that.
    #
    # What I came up with was to simply turn the world on it's "side" and 
    # generate the output for the buildings with the "ground" on the "left"
    # and the "sky" on the "right". With that done, all I had to do to finalize
    # the output was to print out the 2D array starting in the "upper right"
    # most column, working toward the "lower left". So, from the example
    # given in the problem, from (X=5,Y=0) to (X=0,Y=4) (with (0,0) in the
    # "upper left" of the grid.
    # That's about it. A bunch of nested for-loops ^_-
    if (len(lines) > 0):
        #setup an array/list to hold our buildings (going to use the word list from here out, but the terms are interchangeable in Python)
        buildings = []
        #setup a list to hold the buildings grouped by height (not strictly necessary)
        groupings = []
        # 2 things happening below. One is necessary (loading our buildings into a container)
        # the other is my left over coding from originally planning to do this with grouped
        # output. I shifted that to simply getting the height of the tallest building, using
        # code I had already written rather than starting over, because when I solve these
        # I pretend to be a student with a time limit on solving, so refactoring is frowned on
        for i in range(1,len(lines)): #skipping the first line. Not needed in Python. More needed in Java if using scanner next row input
            parts = lines[i].strip().split(' ')
            groupings.append(int(parts[0].strip()))
            buildings.append(lines[i])
        # sort the buildings. Because the heights have leading zeros, and do not exceed 2 digits,
        # this will take care of all of the sorting you will need to do for this problem, if you
        # sort it here at the string stage, before you split it up into numbers and strings
        # (if you wait until you do that, you'll have an entirely different problem on your hands)
        buildings.sort()
        # this section isn't necessary, but doesn't hurt anything. It is from my abandoned 1st try
        # to solve this via groupings. I repurposed this code to getting the height of the tallest
        # building, to make it useful. Otherwise, the rest of this grouping code could be thrown
        # out, and it wouldn't change the outcome of the solution.
        groups = list(zip(Counter(groupings).keys(), Counter(groupings).values()))
        tallest = 0
        heights = {}
        for tup in groups:
            if (tup[0] > tallest):
                tallest = tup[0]
            heights[tup[0]] = tup[1]
        grid = []
        tallest += 1
        # setting up 2 nested loops to generate the "columns" of our final
        # output note that in this iteration of the output, the buildings
        # will be lying on their "sides" :) 
        # Note, if you don't put a character in for each position, then your
        # 2D array/list will be "lopsided" and you will get index out of range
        # errors when you try to print it
        for j in range(0,len(buildings)):
            col = []
            parts = buildings[j].strip().split(' ')
            col.append(parts[1])
            count = 0
            for l in range(0,tallest):
                count += 1
                if (count > int(parts[0])):
                    col.append(' ')
                else:
                    col.append('*')
                    if (count == int(parts[0])):
                        col.append('~')
            grid.append(col)
        # Now that we have the buildings generated, simply print out the
        # grid from "tallest" down to zero for the "row" (which is actually
        # going to end up being the "column" in the output), and zero to
        # the count of buildings for the "column" (which will be the row 
        # in the output)
        for row in range(tallest,-1,-1):
            for col in range(0,len(buildings)):
                print(grid[col][row],end='')
            print()
    else:
        print('** ERROR ** data file is malformed')
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    # time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    # counter = -1
    for file in files:
        if ('in.txt' in file):
            # counter +=1
            # print('')
            # print('')
            # print(f'example {counter}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

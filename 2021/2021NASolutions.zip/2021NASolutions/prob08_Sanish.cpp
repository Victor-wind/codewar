#include <iostream>
#include <string>
#include <bits/stdc++.h>
#include <map>
#include <math.h>

using namespace std;

int
main()
{
    string input;
    int wallHeight, ralphHeight, ralphAnger;

    getline(cin, input);

    istringstream ss(input);

    ss >> wallHeight;
    ss >> ralphHeight;
    ss >> ralphAnger;

    if (ralphHeight == 0 || (ralphHeight > wallHeight)) {
        // wall is unharmed

        // print the whole wall
        for (int i=wallHeight; i!=0; i--)
            cout << "#" << endl;;
    } else {
        // wall is damaged

        // print what is left standing ecept the lowest brick
        for (int i=ralphHeight; i>2; i--)
            cout << "#" << endl;;

        // print the lowest brick
        cout << "#";

        // show how far the bricks landed
        for (int i=0; i<ralphAnger/10; i++)
            cout << ".";

        // print the fallen bricks
        for (int i=wallHeight; i>=ralphHeight; i--)
            cout << "#";

        cout << endl;
    }
}

import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAY' #prob17
# ------------------------------------------------------------------------

'''
PROBLEM: 1.21 Gigawatts!
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 15 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 20 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-09
WHAT IT TESTS: 
    1.) Ability to rank data: e.g. what data is relevant and what data can be thrown away depending on what is needed (this is actually quite important in the real world)
    2.) Ability to change units with respect to time
    3.) Ability to round numerical output
    4.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 5):
        # Input format:
        # string: The method name of generating electricity
        # int: The number of people required to run the method
        # int: The amount of time the method can be run given Doc's resources (in minutes)
        # int: The startup time it takes before electricity is produced (in seconds)
        # float: The power output of the method (in watts/hour)
        # int: The number of people Doc Brown could borrow, beg, pay or cajole into helping him generate electricity for an hour
        method      = lines[0].strip()
        pplNeed     = int(lines[1].strip())
        minsCanRun  = int(lines[2].strip())
        secsStartup = int(lines[3].strip())
        wattsHour   = float(lines[4].strip())
        pplAvail    = int(lines[5].strip())
        # This one's pretty simple. We have 2 throw-away cases where
        # we don't need to run any caclulations at all:
        # (1) if we don't have enough people to run the method
        # (2) if the startup time before electricity is generated will take longer than we can run the method
        # If either of those cases is true, simply print the failure message and exit.
        # Else, we need to run calculations.
        # First convert the Watts/Hour to Watts/Second, then convert that
        # to a 2-decimal rounded string, then compare the Watts/Second
        # value to the minimum we need to generate (1.21 Gigawatts)
        # If the power we can generate per second is >= to that, print the
        # success message, else print how much power we CAN generate, and
        # print the failure message.
        # ... That's about it ^_- 
        if (pplAvail >= pplNeed and (secsStartup/60) < minsCanRun):
            wattsPerSecond = wattsHour / 60 / 60
            powerOut = format(round(wattsPerSecond,2),'.2f')
            GigaWatts121 = 1210000000.00
            print(f'{method} can generate {powerOut} watts/second')
            if wattsPerSecond >= GigaWatts121:
                print('MARTY CAN MAKE IT!')
            else:
                print(f'WHOA, HEAVY!')
        else:
            print(f'{method} can generate 0.00 watts/second\nWHOA, HEAVY!')
    else:
        print('** ERROR ** data file is malformed')
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    # counter = -1
    for file in files:
        if ('in.txt' in file):
            # counter +=1
            # print('')
            # print('')
            # print(f'example {counter}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

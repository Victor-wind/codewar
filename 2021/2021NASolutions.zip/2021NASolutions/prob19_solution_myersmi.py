# I got had the table reversed so my results were inaccurate. Maybe make that clearer?
# 30ish minutes

import sys


avenger_key = {
    "Iron Man":0,
    "Hulk":1,
    "Spider Man":2,
    "Captain America":3,
    "Thor":4,
    "Black Widow":5,
    "Hawkeye":6
}

synergy_multipliers = {
    "Iron Man": [1, 1.4, 1.7, 1.7, 1.4, 1.7, 1.7],
    "Hulk": [1.2, 1, 1.5, 1.7, 1.8, 1.4, 1.6],
    "Spider Man": [2.0, 1.3, 1, 1.7, 1.2, 1.3, 1.1],
    "Captain America": [1.6, 1.5, 1.7, 1, 1.6, 1.8, 1.8],
    "Thor": [1.7, 1.9, 1.2, 1.4, 1, 1.4, 1.3],
    "Black Widow": [1.7, 1.9, 1.4, 1.3, 1.4, 1, 2.0],
    "Hawkeye": [1.7, 1.6, 1.1, 1.8, 1.3, 2.0, 1]
}

if __name__ == "__main__":
    inputText = sys.stdin.read().split(',')
    thanos = inputText[-1].split()

    avengers = inputText[:-1]
    avenger_strength = {}
    for avenger in avengers:
        avenger = avenger.split()
        try:
            avenger_n = avenger[0]
            avenger_p = float(avenger[1])
        except ValueError:
            avenger_n = avenger[0] + " " + avenger[1]
            avenger_p = float(avenger[2])
        for key in avenger_strength.keys():
            avenger_strength[key] *= synergy_multipliers[key][avenger_key[avenger_n]]
            avenger_p *= synergy_multipliers[avenger_n][avenger_key[key]]
        avenger_strength[avenger_n] = avenger_p

    total_strength = sum([round(elem) for elem in list(avenger_strength.values())])

    result = ""
    if total_strength > float(thanos[1]):
        result = "Avengers win!"
    elif total_strength < float(thanos[1]):
        result = "Thanos's Army wins!"
    else:
        result = "Draw"

    print("{} {}-{}".format(result, total_strength, thanos[1]))
    

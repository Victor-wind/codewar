ip = input()
ip_arr = ip.split(" ")
n_sticks = int(ip_arr[0])
limit = float(ip_arr[2])

size = 0.0
if ip_arr[1]=="1/4":
    size = 1/4
elif ip_arr[1]=="1/3":
    size = 1/3
elif ip_arr[1]=="1/2":
    size = 1/2
else:
    size = float(ip_arr[1])

total_Sticks = n_sticks*size

MJ = round(total_Sticks*0.45*7.5 , 2)

if MJ<=limit:
    print(MJ," the Mask can eat it!")
else:
    print(MJ, "the Mask should not eat it!")


# 40ish minutes. It took me longer than I wanted because I didn't realize I needed to reverse the algorithm. That needs to be clearer unless you
# want this to be a trick question

import sys
import math

def encode(text, lookup):
    current = ""
    for char in text:
        current += '{0:08b}'.format(ord(char))

    final = ""
    for i in range(math.ceil(len(current)/6)):
        end = (i+1)*6
        if end > len(current):
            end = len(current)
        final += lookup[int(current[i*6:end], 2)+8]

    return final

def decode(text, lookup):
    current = ""
    for char in text:
        current += '{0:08b}'.format(lookup.index(char) - 8)[2:]

    final = ""
    for i in range(math.ceil(len(current)/8)):
        end = (i+1)*8
        if end > len(current):
            end = len(current)
        final += chr(int(current[i*8:end], 2))

    return final

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()

    encodedText = inputText[0]
    hash_lookup = inputText[1]


    print(decode(encodedText, hash_lookup))
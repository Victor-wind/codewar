import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probAO' #prob19
# ------------------------------------------------------------------------

'''
PROBLEM: Can we beat Thanos?
DIFFICULTY LEVEL: Novice (upper)
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 18 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 22 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-15
WHAT IT TESTS: 
    1.) Ability to parse floating point decimals from strings
    2.) Ability to navigate tabular data, either as a 2D array/list, or as a dictionary (please don't type it out as a dictionary)
    3.) Ability to realize that you can simply do a lookup in the table as a column for each avenger, or as a row. Don't have to calculate in both directions
    4.) Ability to skip items in a list
    5.) Ability to do iterative multiplication
    6.) Ability to round decimals to ints
    7.) Ability to compare numbers
    8.) Ability to compare strings regardless of case (and to also handle extra white space around data items)
    9.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 0):
        #setup a list of the avengers, we're going to use that as our "x" coordinate
        heroes = ['IRON MAN','HULK','SPIDER MAN','CAPTAIN AMERICA','THOR','BLACK WIDOW','HAWKEYE']
        #copy in the table from the text file of the power synergies, we're going to use that as our "y" coordinate
        synergy = [ #y,x coords
            [1.0, 1.2, 2.0, 1.6, 1.7, 1.7, 1.7],
            [1.4, 1.0, 1.3, 1.5, 1.9, 1.9, 1.6],
            [1.7, 1.5, 1.0, 1.7, 1.2, 1.4, 1.1],
            [1.7, 1.7, 1.7, 1.0, 1.4, 1.3, 1.8],
            [1.4, 1.8, 1.2, 1.6, 1.0, 1.4, 1.3],
            [1.7, 1.4, 1.3, 1.8, 1.4, 1.0, 2.0],
            [1.7, 1.6, 1.1, 1.8, 1.3, 2.0, 1.0]]
        # Run through a proof of the math (not strictly necessary, but this is what I did on paper, so wanted to capture it here)
        # <want 1944 according to problem description>
        # thor: 16  hulk-1.9 * spid-1.2 * blak-1.4 * hawk-1.3 = 66.3936
        # hulk: 100 thor-1.8 * spid-1.5 * blak-1.4 * hawk-1.6 = 604.8
        # spid: 1   thor-1.2 * hulk-1.3 * blak-1.3 * hawk-1.1 = 2.2308
        # blak: 162 thor-1.4 * hulk-1.9 * spid-1.4 * hawk-2.0 = 1206.576
        # hawk: 14  thor-1.3 * hulk-1.6 * spid-1.1 * blak-2.0 = 64.064
        #                                                     = 1944.0644 == match
        team = str(lines[0]).strip().split(',')
        AvengersPower = 0
        power = 0
        #loop through each avenger in the given team (ignoring the last "team" member for now, which is Thanos)
        for i in range(0,(len(team)-1)):
            # have to account for avengers with spaces in their names (╯°□°）╯︵ ┻━┻
            parts = str(team[i]).strip().split(' ')
            avenger = parts[0].strip().upper()
            power = 0
            if (len(parts) > 2):
                avenger = parts[0].strip().upper() + ' ' + parts[1].strip().upper()
                power = float(parts[2])
            else:
                power = float(parts[1])
            #grab our "x" coordinate (the easy part)
            x = heroes.index(avenger)
            #grab our "y" coordinate (the harder part). Doing this with the
            #avengers base power as the starting point, then using each "synergy"
            #as a multiplier on the power in a single pass across that hero's
            #column in the table. (Don't need to skip themselves, because their
            # multiplier against themselves is 1 -- so it shouldn't change anything)
            if ('IRON MAN' in lines[0].upper()):
                y = 0
                # print(f'syn: {synergy[y][x]}')
                power *= synergy[y][x]
            if ('HULK' in lines[0].upper()):
                y = 1
                # print(f'syn: {synergy[y][x]}')
                power *= synergy[y][x]
            if ('SPIDER MAN' in lines[0].upper()):
                y = 2
                # print(f'syn: {synergy[y][x]}')
                power *= synergy[y][x]
            if ('CAPTAIN AMERICA' in lines[0].upper()):
                y = 3
                # print(f'syn: {synergy[y][x]}')
                power *= synergy[y][x]
            if ('THOR' in lines[0].upper()):
                y = 4
                # print(f'syn: {synergy[y][x]}')
                power *= synergy[y][x]
            if ('BLACK WIDOW' in lines[0].upper()):
                y = 5
                # print(f'syn: {synergy[y][x]}')
                power *= synergy[y][x]
            if ('HAWKEYE' in lines[0].upper()):
                y = 6
                # print(f'syn: {synergy[y][x]}')
                power *= synergy[y][x]
            # print(power)
            AvengersPower += power
        #-----------------------------------------------------------------
        # Grab Thanos' power out of the final "team" member
        ThanosParts = str(team[len(team)-1]).strip().split(' ')
        ThanosArmy = float(ThanosParts[1])
        # Round both sets of powers to integers
        ThanosArmy = round(ThanosArmy)
        AvengersPower = round(AvengersPower)
        #compute the end state :D
        if (AvengersPower > ThanosArmy):
            print(f'Avengers win! {AvengersPower}-{ThanosArmy}')
        elif (AvengersPower < ThanosArmy):
            print(f'Thanos\'s Army win! {ThanosArmy}-{AvengersPower}')
        else:
            print(f'Draw {AvengersPower}-{AvengersPower}')
        #print(totalPower)
    else:
        print('** ERROR ** data file is malformed')

# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    for file in files:
        if ('in.txt' in file):
            # print(f'{file}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

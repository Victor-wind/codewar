def get_dataset(problem):
    #read and get input file
    with open(r'.\student_datasets\prob'+problem+'-in.txt') as fi:
        input_file=[]
        for line in fi:
            input_file.append(line.rstrip('\n'))
    
    #read output file
    with open(r'.\student_datasets\prob'+problem+'-out.txt') as fo:
        output_file=[]
        for line in fo:
            output_file.append(line.rstrip('\n'))
    
    #display example output
    print('Example output: ')
    for line in output_file:
        print(line)
    
    return input_file

for example in ['BD-1','BD-2', 'BD-3','BD-4']:
    input_file=get_dataset(example)
    
    unique_set=set()
    duplicate_set=set()
    
    for line in input_file:
        date=line[:-5]
        if date not in unique_set:
            unique_set.add(date)
        else:
            duplicate_set.add(date)
    
    num_duplicate=len(duplicate_set)
    
    print('Solution output: ')
    
    print(num_duplicate)
    if num_duplicate!=0:
        sorted_list=sorted(list(duplicate_set), key=lambda date: tuple(map(int, date.split('/'))))
        print('duplicates: {}\n'.format(' '.join(sorted_list)))
    else:
        print('duplicates: None\n')
        
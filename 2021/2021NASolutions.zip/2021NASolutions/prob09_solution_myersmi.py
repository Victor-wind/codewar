# 25ish minutes

import sys
import math

def volume_cockpit(rad):
    return (rad * rad * rad * math.pi * 4.0 / 3.0) - 2.2 - 4.1

def volume_body(rad, height):
    return (rad * rad * height * math.pi) - 12.1

def volume_storage(height, length, width):
    return 2.0 * ((height * length * width) / 3.0)

if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()

    minions = int(inputText[0])
    cockpit_rad = float(inputText[1])
    body = inputText[2].split()
    body_rad = float(body[0])
    body_height = float(body[1])
    storage_pods = inputText[3].split()
    storage_height = float(storage_pods[0])
    storage_length = float(storage_pods[1])
    storage_width = float(storage_pods[2])

    minions_need = minions * 1.2
    cockpit_avail = volume_cockpit(cockpit_rad)
    body_avail = volume_body(body_rad, body_height)
    storage_avail = volume_storage(storage_height, storage_length, storage_width)

    print("Cockpit {:.2f}".format(cockpit_avail))
    print("Body {:.2f}".format(body_avail))
    print("Pods {:.2f}".format(storage_avail))
    print("Minions Need {:.2f}".format(minions_need))
    if round(minions_need, 2) > round((cockpit_avail + body_avail + storage_avail), 2):
        print("PLAN REJECTED")
    else:
        print("PLAN ACCEPTED")
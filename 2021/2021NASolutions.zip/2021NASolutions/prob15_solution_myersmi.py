#Easy, some trial and error. 25ish minutes. Problem sets are fine. Instructions were clear

import sys

gems = {
    "Lapis":[],
    "Topaz":[],
    "Tourmaline":[],
    "Sapphire":[],
    "Peridot":[],
    "Ruby":[],
    "Pearl":[],
    "Emerald":[],
    "Diamond":[],
    "Aquamarine":[],
    "Amethyst":[],
    "Garnet":[]
}

def ponySort(pony_names):
    gem_names = gems.copy()
    nongem_names = []

    for name in pony_names:
        words = name.split()
        bestGem = len(gem_names)
        for word in words:
            try:
                result = list(gem_names.keys()).index(word)
                if result < bestGem:
                    bestGem = result
            except ValueError:
                pass
        if bestGem != len(gem_names):
            gem_names[list(gem_names.keys())[bestGem]].append(name)
        else:
            nongem_names.append(name)
    
    result = []
    for key, value in gem_names.items():
        value.sort()
        result.extend(value)
    nongem_names.sort()
    result.extend(nongem_names)
    
    return result


if __name__ == "__main__":
    inputText = sys.stdin.read().splitlines()[:-1]  #ignore END

    sorted_names = ponySort(inputText)

    for name in sorted_names:
        print(name)
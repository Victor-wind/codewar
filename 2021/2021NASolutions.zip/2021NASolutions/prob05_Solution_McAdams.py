import sys
import time
import os
from os import path,listdir
from os.path import isfile, join

# ------------------------------------------------------------------------
# CHANGE THIS BEFORE SUBMITTING!
AM_DEBUGGING = False
DATA_STUDENT = True
probID = 'probBD' #prob05
# ------------------------------------------------------------------------

'''
PROBLEM: Military Restrictions
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 3 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 6 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-12
WHAT IT TESTS: 
    1.) Ability to parse and split string data
    2.) Ability to count occurrences in a data set
    3.) Ability to sort and keep track of running totals of parsed data
    4.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
'''

# ========================================================================
def GetData(isDebug=False,filePath="input.txt"):
    'used to pull data from an input file, or standard in (depending on debug mode)'
    lines = []
    try:
        if (isDebug):
            myFile = open(filePath,"r")
            for line in myFile:
                #print(line.strip())
                lines.append(line.strip())
        else:
            for line in sys.stdin:
                #print(line.strip())
                lines.append(line.strip())
        return lines
    except:
        e = sys.exc_info()[0]
        print("bad things happened: "+str(e))
# ========================================================================
def Main(lines=[]):
    'Main Program'
    if (len(lines) > 1):
        #Setup a count for our loops (because for Python, we're going to ignore the first line)
        counter = -1
        #setup a dictionary to use to keep track of the count of occurrences of MM/DD birthdays
        birthdays = {}
        #loop through each line (skipping the first)
        for line in lines:
            counter += 1
            if (counter > 0):
                #split the line up on the forward slash symbol
                parts = line.strip().split('/')
                if (len(parts) > 2):
                    #create a new string out of just the month and day parts of the date
                    mmdd = parts[0]+'/'+parts[1]
                    #check to see if we already have that MM/DD combo in our dictionary
                    if mmdd not in birthdays.keys():
                        #if not, add it with an initial count of 1
                        birthdays[mmdd] = 1
                    else:
                        #else, increment the count
                        birthdays[mmdd] += 1
        #setup a list to count the duplicates. Not STRICTLY necessary, but handy to
        #use together with a loop to guard against off-by-one errors with spaces
        duplicates = []
        for bday in birthdays.items():
            if bday[1] > 1:
                duplicates.append(bday[0])
        #print out the count of duplicates we have in the list (could have also printed the dictionary count)
        print(len(duplicates))
        output = ''
        #print out the duplicates
        print('duplicates: ',end='')
        if (len(duplicates) > 0):
            for dup in duplicates:
                if (output != ''):
                    output += ' '
                output += dup
            print(output)
        else:
            print('None')
    else:
        print('** ERROR ** data file is malformed')
# ########################################################################
# ########################################################################
#                           MAIN PROGRAM
# ########################################################################
# ########################################################################

# Solutions I provide will be structured in this way, to allow quick-running
# all of the datasets (student and judge) -- as we use these solutions to
# generate the datasets ^_-
#
# That only will happen if debug mode is on. When reading from standard in
# this solution will always expect one (and only one) input file name/path.
#
# Student solutions would not be expected to be this in-depth. We would expect
# student solutions to simply look for the file to open :D

# ------------------------------------------------------------------------
# Display a warning to the Terminal if the solution is in Debug mode
if (AM_DEBUGGING):
    print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n         WARNING WARNING WARNING               \n             DEBUG MODE IS ON!                 \n    DO NOT SUBMIT FOR JUDGING IN THIS MODE!    \n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    # time.sleep(5)
# ------------------------------------------------------------------------
# GET THE DATA FROM THE DATA FILE(S)
DATASET = 'judge'
if (DATA_STUDENT):
    DATASET = 'student'
if (AM_DEBUGGING):
    files = [f for f in listdir(fr'{DATASET}_datasets\{probID}') if isfile(join(fr'{DATASET}_datasets\{probID}', f))]
    # counter = -1
    for file in files:
        if ('in.txt' in file):
            # counter +=1
            # print('')
            # print('')
            # print(f'example {counter}')
            lines = GetData(AM_DEBUGGING,fr'{DATASET}_datasets\{probID}\{file}')
            if (lines != None and len(lines) > 0):
                Main(lines)
            else:
                print('** ERROR ** data file was blank or missing')
else:
    lines = GetData(AM_DEBUGGING)
    if (lines != None and len(lines) > 0):
        Main(lines)
    else:
        print('** ERROR ** data file was blank or missing')

import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
import java.io.File;//required for I/O from file
import java.io.IOException;//required for I/O from file
import java.nio.file.Files;//required for I/O from file (new in Java 8)
public class prob08_Solution_McAdams {
/*
PROBLEM: I'm Gonna Wreck It!
DIFFICULTY LEVEL: Novice
TIME FOR PROBLEM AUTHOR TO CODE SOLUTION: 10 mins
ESTIMATED STUDENT COMPLETION TIME NEEDED: 15 mins
AUTHOR: Robert McAdams, mcadams@hpe.com, linkedin.com/in/RobertMcadams
LAST MODIFIED: 2021-02-06
WHAT IT TESTS: 
    1.) Ability to work with nested loops
    2.) Ability to force integer calculations
    3.) Ability to handle edge cases and multiple output states
    4.) Ability to handle one-off issues with loops
    5.) Ability to control how text is printed to the screen (end of line terminal character)
    6.) Ability to understand and program solutions using programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
    
NOTE: This solution was translated from my original solution in Python, into Java. I did that for the first 15 problems in the packet
so students who only code in Java will have solutions to look at in their native coding language. The algorithms are the same. The only
parts which change are language specific things (such as how to access list elements). I also collapsed some functions out of python
back into the main program in Java, just to save time. By comparing these 15 translated Java programs to their original Python
implementations, you should be able to pull out Java coding from the rest of the Python solutions, if you'd like. The techniques and
coding functionality used should (more or less) stay the same for the rest of the Python solutions I did. I tend to stick to basics
when at all possible: lists, dictionaries, loops, and logic structures. The only one which might get a little tricky going from
Python to Java will be Pirate Parlay(#27). If you get that one working, I will be impressed :)
*/
	//------------------------------------------------------------------------
	// CHANGE THIS BEFORE SUBMITTING!
	private static final boolean AM_DEBUGGING = true;
	private static final boolean DATA_STUDENT = true;
	private static final String DEBUG_PROB_ID = "prob08";
	private static final int DEBUG_PROB_IN = 1;
	private static final String DEBUG_PATH = System.getProperty("user.dir") + "\\src";
	private static final boolean DEBUG_MODE_ALL = true;
	//------------------------------------------------------------------------
	public static void main(String[] args) {
		try
		{
			GetData();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void MainProgram(List<String> lines) {
		if (lines.size() > 0) {
		    //0 = wall height
		    //1 = how high hit
		    //2 = Ralph mad 0-9 = no change, 10-19 = +1 distance away, 90-99 = +9 distance
		    String[] parts = lines.get(0).strip().split(" ");
		    if (parts.length > 2)
		    {
		        int height = Integer.parseInt(parts[0]);
		        int hit = Integer.parseInt(parts[1]);
		        int mad = Integer.parseInt(parts[2]);
		        if ((hit > height) || hit == 0)
		        {
		            //ralph missed, simply print the wall
		            for (int i=0; i<height; i++)
		            {
		                print("#");
		            }
		        }
		        else
		        {
		            //Ralph didn't miss
		        	for (int i=1; i<hit; i++)
		            {
		                // on the last block (at ground level) print the final block
		                // then print the periods to show space from the hit (if any)
		                // and the remainder of the wall pieces now lying on the ground
		                if (i == (hit -1))
		                {
		                	System.out.print("#");
		                    for (int j=0; j< (mad/10);j++)
		                    {
		                    	System.out.print(".");
		                    }
		                    for (int k=(hit-1); k<height;k++)
		                    {
		                    	System.out.print("#");
		                    }
		                    print("");
		                }
		                else
		                {
		                    //print the part of the wall left standing (it will be at least one block)
		                    print("#");
		                }
		            }
		        }
		    }
		}
		else
		{
			print("*****Error Malformed Data");
		}
	}
	private static List<String> inputFromStdIn() {
		List<String> lines =new ArrayList<String>();
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static void GetData() throws IOException {
		String dataset = "student";
		if (!DATA_STUDENT) {
			dataset = "judge";
		}
		if (AM_DEBUGGING) {
			if (DEBUG_MODE_ALL) {
				List<String> datasets =new ArrayList<String>();
				File datasetFolder = new File(DEBUG_PATH+"\\"+dataset+"_datasets\\");
				File[] files = datasetFolder.listFiles();
				for (File f:files) {
					if (f.isFile()) {
						if (f.getName().indexOf(DEBUG_PROB_ID) > -1 && f.getName().indexOf("in") > -1)
						{
							datasets.add(f.getName());
						}
					}
				}
				for (String file: datasets) {
					print("--------------------------------------------------------------------------------------");
					print("DEBUGGING OUTPUT FOR: "+file);
					MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+file).toPath()));
				}
			}
			else {
				MainProgram(Files.readAllLines(new File(DEBUG_PATH+"\\"+dataset+"_datasets\\"+DEBUG_PROB_ID+
						"-"+DEBUG_PROB_IN+"-in.txt").toPath()));
			}
		}
		else{
			MainProgram(inputFromStdIn());
		}
	}
	private static void print(String s) {
		//shortcut for moving back and forth between Python (and, also, (and I cannot stress this enough), I hate typing out the full System.out.println() ceremony every time
		System.out.println(s);
	}
}

# 20 ish minutes. probAK explains this better

import sys

def convert_to_meters(value, unit):
    if unit == "MILES":
        unit = "FEET"
        value = value * 5280
    if unit == "YARDS":
        unit = "FEET"
        value = value * 3
    if unit == "INCHES":
        unit = "FEET"
        value = value / 12.0
    if unit == "FEET":
        unit = "METERS"
        value = value / 3.28

    if unit == "KILOMETERS":
        unit = "METERS"
        value = value * 1000
    if unit == "CENTIMETERS":
        unit = "METERS"
        value = value * 0.01

    return value
    
def convert_to_meters_sec(value, unit):
    if unit == "HOUR":
        value = value / 3600.0
    if unit == "MINUTE":
        value = value / 60.0
    return value

if __name__ == "__main__":
    inputText = sys.stdin.read().split()

    contraption = inputText[0]
    speed = float(inputText[1])
    distance = inputText[2]
    time = inputText[4]

    meters_speed = convert_to_meters(speed, distance)
    meters_speed_per_sec = convert_to_meters_sec(meters_speed, time)

    height = meters_speed_per_sec * meters_speed_per_sec / (2.0 * 9.805)

    if height >= 25.00 and height <= 50.00:
        result = "SUCCESS" 
    elif height > 50.00:
        result = "OUCH"
    else:
        result = "SPLAT"

    print("{} will launch the messenger {:.2f} meters high, {}!".format(contraption, height, result))
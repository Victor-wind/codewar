#######################################################
# Task: Codewar Solution
# Problem: AW
# Description : Tight Fit
# Author : Yogesh Choubey (yogesh.choubey@hpe.compile)
#######################################################

import sys
import math


def main(args_list):

	#fetch minion count 
	mi_count = int(args_list[0])
	
	#fetch sphere attribute 
	cpit_radius = float(args_list[1])
	
	#fetch cylinder attributes 
	cy_radius,cy_height = args_list[2].split()
	cy_height = float(cy_height)
	cy_radius = float(cy_radius)
	
	#fetch pod attributes 
	pd_length,pd_weidth,pd_height = args_list[3].split()
	pd_length = float(pd_length)
	pd_weidth = float(pd_weidth)
	pd_height = float(pd_height)
	
	#calculate cockpit volume 
	cockpit_vol = calc_cockpit_volume(cpit_radius)
	
	#calculate Cylinder body voume 
	body_vol = calc_cylinder_volume(cy_radius,cy_height)
	
	#calculate pod volumes 
	pods_vol = calc_pods_volume(pd_length,pd_weidth,pd_height)
	
	#calculate total volume available for minions 
	total_available_vol = cockpit_vol + body_vol + pods_vol
	
	#Calculate volume needed by minions
	m_need = round(calc_minion_volume(mi_count),2)
	
	#print below lines to the terminal
	print(f"Cockpit {cockpit_vol}")
	print(f"Body {body_vol}")
	print(f"Pods {pods_vol}")
	print(f"Minions Need {m_need}")
	
	#condition to check total volume should be greater than total minion volume
	#if calc_minion_volume(mi_count) <= total_available_vol:
	if m_need <= total_available_vol:
		print("PLAN ACCEPTED")
	else:
		print("PLAN REJECTED")
		
	
#function to calculate cockpit volume 	
def calc_cockpit_volume(radius):
    cockpit_volume = (4/3)*math.pi*radius**3
    vol_available = cockpit_volume - cockpit_volume_occupied
    return round(vol_available,+2)

#function to calculate cylinder volume 	
def calc_cylinder_volume(radius,height):
    cylinder_vol = height*math.pi*radius**2
    vol_available = cylinder_vol-emergency_eqi_vol
    return round(vol_available,+2)

#function to calculate pods volume 
def calc_pods_volume(length,width,height):
	pod_volume = 2*(1/3)*length*width*height
	return round(pod_volume,+2)

#function to calculate minion volume 
def calc_minion_volume(minion_count):
    total_minion_volume = 1.2 * minion_count
    return  round(total_minion_volume,2)

#function to fetch input from terminal
def fetch_input():
	arg_list = list()
	
	#Input values from user 
	minion_count = input("Minion Count: ")
	ckp_radius = input("Cockpit Radius: ")
	cylinder_radius = input("Cylinder Radius: ")
	cylinder_height = input("Cylinder Height: ")
	pod_length = input("Pod Length: ")
	pod_width = input("Pod Width: ")
	pod_height = input("Pod Height: ")
	
	#Append Minion value to list 
	arg_list.append(minion_count)
	
	#Append cockpit radius to list 
	arg_list.append(ckp_radius)
	
	#Append cylinder attribute to list 
	cylinder_args = f"{cylinder_radius} {cylinder_height}"
	arg_list.append(cylinder_args)
	
	#Append pod attributes to list 
	pod_args = f"{pod_length} {pod_width} {pod_height}"
	arg_list.append(pod_args)
	
	return arg_list
	
	
	
	
if __name__ == "__main__":
	
	#Space consumption by GRu, Equipment and Controls
	Gru_space = 2.20                   # units in M3 (meter cube)
	cockpit_control_space = 4.10       # units in M3 (meter cube)
	emergency_eqi_vol = 12.10          # units in M3 (meter cube)
	cockpit_volume_occupied = Gru_space + cockpit_control_space     # units in M3 (meter cube)
	
	#check for fileinput or keyboard input 	
	if len(sys.argv) != 1:
		print("Fetching input through Terminal:")
		args_list = fetch_input()
		print('\n')
		main(args_list)
	else:
		filename = "input.txt" # sys.argv[1]
		try:
			args_list = [x for x in open(filename,'r')]
			args_list = list(map(lambda x:x.rstrip(),args_list))
			main(args_list)
			
		except IOError:
			print("File not accessible")
	

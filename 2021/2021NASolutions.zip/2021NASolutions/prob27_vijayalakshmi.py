# -*- coding: utf-8 -*-

import sys
import re

def read_input_data():
    in_data = sys.stdin.read().strip()
    return in_data

def eval_str_bool(p):
    p = p.replace("!F", "1")
    p = p.replace("!T", "0")
    p = p.replace("T", "1")
    p = p.replace("F", "0")
    eval_value = "T" if bool(eval(p)) else "F"
    return eval_value


def short_cut_eval(in_data):
    # evaluate given string format bool
    paranthesis_str = re.findall(r'\((.+?)\)', in_data)
    
    # focus on paranthesis expression
    for index, p in enumerate(paranthesis_str):
        eval_value = eval_str_bool(p)        
        in_data = in_data.replace(paranthesis_str[index], eval_value)
        in_data = re.sub(r'[\(\)]', '', in_data) 
        
    disinclined = eval_str_bool(in_data)
    
    return disinclined
    
def prob_AV(in_data):
    
    actual_data = in_data
    # move mapping
    move_symbols = {
            "!": "1 N",
            "&": "2 W",
            "|": "3 S",
            "T": "4 E",
            "F": "JUMP"
    }

    disinclined = short_cut_eval(in_data)    
    if disinclined == "F":
        print("I am disinclined to acquiesce to your request")
        return
    
    movements = []
    for l in actual_data:
        if l in ["(", ")"]:
            continue
        movements.append(move_symbols[l])
    
    print("\n".join(movements))
    
             
            
if __name__ == "__main__":
    
    in_data = read_input_data()
    prob_AV(in_data)
    

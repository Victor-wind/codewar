data = open('probBC-judge-2-in.txt', 'r').readlines()

# Python cheat for flipping lists
for line in data[::-1]:
    print(line.strip('\n'))
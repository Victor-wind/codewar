#######################################################
# Task: Codewar Solution
# Problem: AI
# Description : Base-74
# Author : Yogesh Choubey (yogesh.choubey@hpe.com)
#######################################################

import sys 

def main(encoded_mesg):
	encoded_mesg_list = list(map(get_encoding_value,encoded_mesg))
	encoded_mesg_list = list(map(lambda x: x-8,encoded_mesg_list))	
	bi_encoded_mesg_list = list(map(decimalToBinary,encoded_mesg_list))
	bi_encoded_mesg_list = list(map(lambda x:str(x).zfill(6),bi_encoded_mesg_list))	
	bi_encoded_mesg = ''.join(bi_encoded_mesg_list)
	out = [(bi_encoded_mesg[i:i+8]) for i in range(0, len(bi_encoded_mesg), 8)]
	out2 = list(map(binaryToDecimal,out))
	decoded_mesg_list = list(map(lambda x: chr(x),out2))
	decoded_mesg = ''.join(decoded_mesg_list)
	# print("output")
	print(decoded_mesg)
	
#function to lookup base74 table 	
def get_encoding_value(symbol):
	value = base74_table.find(symbol)
	return value 
	
#function to convert decimal to binary
def decimalToBinary(value):
	if value < 0: #Base case if number is a negative
		return 'Not positive'
	elif value == 0: #Base case if number is zero 
		return 0
	else:
		return 10*decimalToBinary(value//2) + value%2

#function to convert binary to decimal 	 
def binaryToDecimal(n): 
    return int(n,2) 
	
	
if __name__ == "__main__":
	 	
	if len(sys.argv) == 1:
		filename = "input.txt" # sys.argv[1]
		try:
			args_list = [x for x in open(filename,'r')]
			args_list= list(map(lambda x:x.rstrip(),args_list))
			encoded_mesg = args_list[0]
			base74_table = args_list[1]
			# print("Input")
			# print(encoded_mesg)
			# print(base74_table)
			# print('\n')
			main(encoded_mesg)
			
		except IOError:
			print("File not accessible")
	else:
		print('Argument error, Please provide input file')
	

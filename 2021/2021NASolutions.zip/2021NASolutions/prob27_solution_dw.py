#**********************************************************************************************************
# Donnie Wahlquist
#**********************************************************************************************************
import sys
import os



#***********************************************************
#***********************************************************
def myMain():


    input_file = "input.txt"
    orig_note = ""
    note = ""
    parts = []

    try:
        # Read input file
        with open(input_file, "r") as fp:
            for line in fp:
                orig_note = line.strip()
                break                       # only need 1 input line.
            fp.close()


        # Parse line into list "parts", where '!' has been handled, and parens designate new items.
        part = ""
        NOT_in_effect = False
        for ndx in range(0, len(orig_note)):   # for 0 to (len-1)
            if orig_note[ndx] == '('  or  orig_note[ndx] == ')':
                if len(part) != 0:
                    parts.append(part)
                part = ""
            elif orig_note[ndx] == '!':
                NOT_in_effect = True
            elif NOT_in_effect == True :
                if orig_note[ndx] == "F":
                    part += "T"
                else:
                    part += "F"
                NOT_in_effect = False
            else:
                part += orig_note[ndx]
        if len(part) != 0:
            parts.append(part)

        #print(orig_note)
        #print(parts)

        for ndx in range(0, len(parts)):          # reduce each part   
            parts[ndx] = reduce_Ands(parts[ndx])
        #print(parts)

        simplified = "".join(parts)     # join the list back into 1 simplified string.
        #print(simplified)

        simplified = reduce_Ands(simplified)
        #print(simplified)
        if simplified.find("T") != -1 :
            #print("    True")
            for ndx in range(0, len(orig_note)):    # print out the solution
                ch = orig_note[ndx]
                if ch == '!':
                    print("1 N")
                elif ch == '&':
                    print("2 W")
                elif ch == '|':
                    print("3 S")
                elif ch == 'T':   
                    print("4 E")                             
                elif ch == 'F':
                    print("JUMP")
        else:
            #print("    False")
            print("I am disinclined to acquiesce to your request")

              
    except e:
        print("\n    ## ERROR \n" + e)
        return 3




##########################################################
# reduce_Ands
##########################################################
def reduce_Ands(part):  
    reduced = ""
    state = True
    last_ndx = len(part) - 1
    for ndx in range(0, len(part)):          # look at each char
        if part[ndx] == 'F':
            state = False
        if part[ndx] == '|' :
            if ndx == 0:
                reduced += '|'
            elif state == True :
                reduced += "T|"
            else :
                reduced += "F|"
                state = True
        elif ndx == last_ndx :
            if state == True :
                reduced += "T"
            else:
                reduced += "F"
            if part[ndx] == '&':
                reduced += '&'

    return reduced  





if __name__ == '__main__':
    ec = myMain()
    sys.exit(ec)

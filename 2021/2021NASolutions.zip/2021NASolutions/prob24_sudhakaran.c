#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>


/*

void charToBinaryStr(char *buffer, unsigned char Char)
{
    unsigned char mask = 0x80;
    do{
        *buffer++ = (Char & mask) ? '1' : '0';
    }while(mask >>= 1);
}



unsigned char SixCharBinaryStrTochar(char *buffer)
{
    unsigned char cRetValue =0x0;
    unsigned char mask = 0x20;

    do{
        cRetValue |= ((*buffer++ == '1') ? mask : 0x0);
    }while((mask >>= 1) && (*buffer));

    return cRetValue;
} */

void charToSixcharBinaryStr(char *buffer, unsigned char Char)
{
    unsigned char mask = 0x20;

    do{
        *buffer++ = (Char & mask) ? '1' : '0';
    }while(mask >>= 1);
}

int charAt(char *str,char findchar)
{
    int index = 0;
    while(*str){
        if(*str == findchar)return index;
        str++;
        index++;
    }
    return -1;
}

unsigned char EightCharBinaryStrTochar(char *buffer)
{
    unsigned char cRetValue =0x0;
    unsigned char mask = 0x80;

    do{
        cRetValue |= ((*buffer++ == '1') ? mask : 0x0);
    }while((mask >>= 1) && (*buffer));

    return cRetValue;
}


void main(int argc,char **argv)
{
    unsigned char *ResultStr = (unsigned char *) calloc(500,sizeof(unsigned char));
    unsigned char *rp =  ResultStr;
    unsigned char *encoded = (unsigned char *) calloc(500,sizeof(unsigned char));
    unsigned char *ep = encoded;
    unsigned char *HashLookup = (unsigned char *) calloc(150,sizeof(unsigned char));
    unsigned char *HLp = HashLookup;
    unsigned char *Buffer = (unsigned char *) calloc(200*8,sizeof(unsigned char));
    unsigned char *p = Buffer;
    int index = -1;

    
    scanf("%s %s",encoded,HashLookup);
    /*
    printf("%s\n%s\n",encoded,HashLookup);

    // Code to Encode
    while(*ep){
        charToBinaryStr(p,*ep);
        p += sizeof(unsigned char)*8;
        ep += sizeof(unsigned char);
    }
    
    p = Buffer;
    while(*p){
       *rp = HashLookup[SixCharBinaryStrTochar(p) + 8];
       rp++;
       p += 6;
    }*/

    /* Code to Decode */
    while(*ep){
        if((index = charAt(HashLookup,*ep)) > -1){
            charToSixcharBinaryStr(p,index - 8);
            p += 6;
        }
        ep += sizeof(unsigned char);
    }

    p = Buffer;
    while(*p){
        *rp = EightCharBinaryStrTochar(p);
        p += 8;
        rp += sizeof(unsigned char);
    }
    
    printf("%s\n",ResultStr);

    free(Buffer);
    free(HashLookup);
    free(encoded);
    free(ResultStr);
}
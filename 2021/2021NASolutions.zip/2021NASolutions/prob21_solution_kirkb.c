#include <stdio.h>
#include <string.h>
#define VECTORS 9
#define LEN 4
#define R 0
#define C 1
#define DIM 25

char MOJO[]="MOJO";

int v[VECTORS][LEN][2] = {
{{0, 0},{ 0, 1},{ 0, 2},{ 0 ,3}},
{{0, 0},{ 0,-1},{ 0,-2},{ 0,-3}},
{{0, 0},{ 1, 0},{ 2, 0},{ 3, 0}},
{{0, 0},{-1, 0},{-2, 0},{-3, 0}},
{{0, 0},{ 1, 1},{ 2, 2},{ 3, 3}},
{{0, 0},{-1,-1},{-2,-2},{-3,-3}},
{{0, 0},{-1, 1},{-2, 2},{-3, 3}},
{{0, 0},{ 1,-1},{ 2,-2},{ 3,-3}},
{{0, 0},{ 0, 1},{ 1, 0},{ 1, 1}}
};

char board[DIM+1][DIM+1];
int lines=0;
int dim=DIM;

int legal(r,c,n) int r,c,n; {
int i;
int f=1;
for(i=0;i<LEN;i++)
 f=f && 
  ((r+v[n][i][R])>=0) && ((r+v[n][i][R])<dim) &&
  ((c+v[n][i][C])>=0) && ((c+v[n][i][C])<dim) &&
  (board[r+v[n][i][R]][c+v[n][i][C]] == MOJO[i]);
return f;
}

int main(argc,argv) int argc; char **argv; {
int r,c,i,n;
while(scanf("%s",board[lines])!=EOF) lines++;
dim=strlen(board[0]);
for(r=0;r<dim;r++)
 for(c=0;c<dim;c++)
  for(n=0;n<VECTORS;n++)
   if(legal(r,c,n))
    for(i=0;i<LEN;i++)
     printf("%c: %d,%d\n",MOJO[i],c+v[n][i][C],r+v[n][i][R]);
}
   

#!/bin/python3

import sys

def parse_inputs():
    wave = []
    for line in sys.stdin:
        wave.append(line.rstrip())
    num_lines = int(wave.pop(0))
    # print(num_lines, wave)
    return num_lines, wave 

def solution():
    num_lines, wave = parse_inputs()
    for i in range(num_lines -1, -1, -1):
        print(wave[i])

    
if __name__ == '__main__':
    solution()

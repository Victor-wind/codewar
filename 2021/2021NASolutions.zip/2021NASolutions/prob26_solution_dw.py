#**********************************************************************************************************
# Donnie Wahlquist
#**********************************************************************************************************
import sys
import os


map = []
height = 0
width = 0
gate_info = {}      # a hash created for each gate.  Key = "x,y"; Value = integer seconds for gate

solutions = []
solution_count = 0




#***********************************************************
#***********************************************************
def myMain():
    global map
    global height
    global width
    global gate_info

    input_file = "input.txt"

    try:
        # Read input file
        with open(input_file, "r") as fp:
            line_no = 0
            for line in fp:
                line_no += 1
                if line_no == 1:
                    w, h, g = line.split()
                    width = int(w)
                    height = int(h)
                    gate_count = int(g)
                elif line_no <= (height + 1):
                    map.append(line.strip())
                else:
                    gate_type, time_val, x, y = line.split()
                    key = x + "," + y
                    gate_info[key] = time_val
                    if line_no == (1 + height + gate_count):
                        break                                   # finished parsing all the lines we need.
            fp.close()


            # Find the location of 'B' (and optionally print map)
            x = 0
            y = 0
            for row in map:                 # note that "map" is indexed by 'y', then 'x'.
                ###print(row)
                x = row.find("B")           
                if x != -1:
                    Bx = x
                    By = y
                y += 1    

        
            # Solve the puzzle - Look for next moves recursively
            history = []
            next_step(history, Bx, By, 0, "")        # Find all working solutions (recursive function)

            # Solutions are all obtained in 'solutions' array.  
            # Time duration for each is in the 3rd element (index 2) of each step (time_elapse).
            i = 0
            index_of_quickest = 0
            quickest = 99999
            for a_solution in solutions: 
                t = a_solution[(len(a_solution)-1)][2]                # step = [ x, y, time, dir];  index 2 = time
                if t < quickest:
                    quickest = t 
                    index_of_quickest = i
                i += 1
            print_solution(solutions[index_of_quickest])
              
    except e:
        print("\n    ## ERROR \n" + e)
        return 3




def next_step(history, from_x, from_y, from_time, direction):  
    global map
    global solutions
    global solution_count

    my_moves = []
    my_moves = history.copy()                           # by making a new copy, every move has it own history on the stack
    my_moves.append([from_x, from_y, from_time, direction])
    
    # NOTE:  map[] is accessed as "map[y, x:x+1]";     'Y' is the 1st index;  'X' is second and requires string indexing.

    if map[from_y][from_x:from_x+1] == "F":
        # Success! - found end of path.
        # Save to proper index of "solutions" array
        solution_count += 1
        ###print("** Solution %d Found.  Took %d seconds to get to exit." % (solution_count, from_time))
        col = []
        solutions.append(col)                               # add an element to 'solutions' for this solution
        solutions[solution_count-1] = my_moves.copy()
        ###print(my_moves)
        return 

    if direction != "S":                                    # Not currently going "S"
        dir = "N"                                           # try "N"
        x = from_x
        y = from_y - 1
        if is_possible(my_moves, x, y, from_time+2):         
            next_step(my_moves, x, y, from_time+2, dir)        

    if direction != "N":                                    # Not currently going "N"
        dir = "S"                                           # try "S"
        x = from_x
        y = from_y + 1
        if is_possible(my_moves, x, y, from_time+2):         
            next_step(my_moves, x, y, from_time+2, dir)

    if direction != "W":                                    # Not currently going "W"
        dir = "E"                                           # try "E"
        x = from_x + 1
        y = from_y
        if is_possible(my_moves, x, y, from_time+2):         
            next_step(my_moves, x, y, from_time+2, dir)

    if direction != "E":                                    # Not currently going "E"
        dir = "W"                                           # try "W"
        x = from_x - 1
        y = from_y
        if is_possible(my_moves, x, y, from_time+2):         
            next_step(my_moves, x, y, from_time+2, dir)
    
    return 



def is_possible(previous_moves, to_x, to_y, time_elapse):
    global height
    global width
    global gate_info

    if to_x < 0 or to_x >= width or to_y < 0 or to_y >= height:     # Coordinates in range ?
        # NO - coordinate out of range
        return False
    elif map[to_y][to_x:to_x+1] == "F":                 # Final step - solution found !
        #  Yes - Final square
        return True  
    elif been_here_before(previous_moves, to_x, to_y):  # must prevent endless recursion.
        return False    
    elif map[to_y][to_x:to_x+1] == ".":
        #  Yes - regular square open
        return True
    elif map[to_y][to_x:to_x+1] == "R":                 # a Closing gate
        location = str(to_x) + "," + str(to_y)
        try:
            gate_close = gate_info[location]            # timer is value in a hash of name "X,Y"
        except KeyError:
            gate_close = "0"
            print("\nDidn't match gate coordinates: %s" % (location) )
        ###print("**** 'R' gate **** location: %s  Closes after %s seconds.  Current time: %d" % (location, gate_close, time_elapse))
        if int(gate_close) > time_elapse:               ##   QUESTION:  How long can I wait for the door to open?
            return True                                             #  Do I die if it is NOT open when I arrive?
        else:
            return False
    elif map[to_y][to_x:to_x+1] == "G":                 # an Opening gate
        location = str(to_x) + "," + str(to_y)
        try: 
            gate_open = gate_info[location]
        except KeyError:
            gate_open = "99999"
            print("\nDidn't match gate coordinates: %s" % (location) )
        ###print("**** 'G' gate **** location: %s  Opens after %s seconds.  Current time: %d" % (location, gate_open, time_elapse))
        if int(gate_open) <= time_elapse:
            return True
        else:
            return False
    else:
        return False



def been_here_before(previous_moves, to_x, to_y):  # must prevent endless recursion.
    for step in previous_moves:
        if (step[0] == to_x)  and (step[1] == to_y):    # prev_step = [ x, y, time, dir]
            return True
    return False
    


def print_solution(steps):
    current_direction=""
    steps_in_direction = 0
    for step in steps:                      
        dir = step[3]                           # step = [ x, y, time, dir];   'time' = index 3
        if dir == current_direction:
            steps_in_direction += 1
        else:
            if current_direction != "":
                print("%s %d" % (current_direction, steps_in_direction))
            current_direction = dir
            steps_in_direction = 1
    # print last step
    print("%s %d" % (current_direction, steps_in_direction))




if __name__ == '__main__':
    ec = myMain()
    sys.exit(ec)

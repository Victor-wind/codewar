// Roll the Bones
// Code Wars program written in JavaScript for the RingoJS environment
//
// The MIT License (MIT)
//
// Copyright (c) 2016 Lee Jenkins
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

var stdin = require("system").stdin;
var stdout = require("system").stdout;

var bones = {
    L: [ 1, 2, 3, 4, 5, 6 ],
    F: [ 0, 1, 1, 2, 3, 5 ],
    T: [ 0, 0, 1, 1, 2, 4 ],
    N: [ 1, 2, 2, 3, 3, 4 ],
    Z: [ 1, 1, 1, 2, 2, 3 ],
    P: [ 0, 1, 2, 3, 5, 7 ],
    G: [ 1, 2, 3, 3, 4, 5 ],
    X: [ 0 ]
};

// FULL_TABLE_MODE is used to during problem design and data-set generation
var FULL_TABLE_MODE = false;

function computeDistributionTable( letters ) {
    var distroTable = {
        sumCounts: [ ],
        trials: 0
    }

    var d0 = bones[ letters[0] ];
    var d1 = bones[ letters[1] ];
    var d2 = bones[ letters[2] ];

    for( var i0=0; i0<d0.length; ++i0 ) {
        for( var i1=0; i1<d1.length; ++i1 ) {
            for( var i2=0; i2<d2.length; ++i2 ) {
                var sum = d0[i0] + d1[i1] + d2[i2];
                while( typeof( distroTable.sumCounts[sum] ) !== "number" ) {
                    distroTable.sumCounts.push(0);
                }
                ++distroTable.trials;
                ++distroTable.sumCounts[sum];
            }
        }
    }

    return distroTable;
}

function printDistributionTable( sumValues, distroTable ) {
    if( FULL_TABLE_MODE ) {
        for( var sum=0; sum<distroTable.sumCounts.length; ++sum ) {
            stdout.writeLine( sum + "   " + distroTable.sumCounts[sum] + "   " + (100*distroTable.sumCounts[sum]/distroTable.trials) + "%" );
        }
    }
    else {
        for( var i=0; i<sumValues.length; ++i ) {
            var sum = sumValues[i];
            stdout.writeLine( sum + "   " + distroTable.sumCounts[sum] + "   " + (100*distroTable.sumCounts[sum]/distroTable.trials) + "%" );
        }
    }
}

function readDiceData() {
    var tokens = stdin.readLine().replace(/\n/,'').split(' ');
    var diceData = null;
    var xCount = 0;
    if( tokens.length === 6 ) {
        diceData = {
            letters: [ ],
            sumValues: [ ]
        };
        for( var i=0; i<3; ++i) {
            diceData.letters.push(tokens[i]);
            if( tokens[i] === 'X' ) {
                ++xCount;
            }
        }
        for( var i=3; i<6; ++i) {
            diceData.sumValues.push(parseInt(tokens[i]));
        }
        if( xCount === 3 ) {
            diceData = null;
        }
    }
    return diceData;
}

function main() {
    var diceData = null;
    while( (diceData=readDiceData()) !== null ) {
        var distroTable = computeDistributionTable( diceData.letters );
        stdout.writeLine( diceData.letters.join(" ") );
        printDistributionTable( diceData.sumValues, distroTable );
    }
}

main();

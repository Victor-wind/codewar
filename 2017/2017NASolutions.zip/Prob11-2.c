#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int let[26];
int r,c,t;
int w[100];
int n;
char g[100];

int main() {
int i,j,k;
scanf("%d %d %d",&r,&c,&t); while(getchar()!='\n');
/* printf("row=%d col=%d t=%d\n",r,c,t);  */
scanf("%d ",&n);
/*  printf("%d words\n",n); */
for(i=0;i<n;i++)
 scanf("%d",&w[i]);
/* for(i=0;i<n;i++)
 printf("word %d = %d\n",i,w[i]);  */
while(getchar()!='\n');
for(i=0;i<26;i++) let[i]=0;
i=0;

while(i<r*c) {
 while(!isalpha(g[i]=getchar()));
/*  printf("g[%d]=%c\n",i,g[i]);  */
 let[g[i]-'A']++;
 i++;
}

/* for(i=0;i<r*c;i++) putchar(g[i]); putchar('\n');*/

for(i=0;i<r*c;i++)
 if(let[g[i]-'A']>=t) g[i]='_';

/* for(i=0;i<r*c;i++) putchar(g[i]); putchar('\n'); */

k=0;
for(i=0;i<r*c;i++) {
 if(isalpha(g[i])) {
  putchar(g[i]);
  w[k]--;
  if(!w[k]) {
   k++;
   putchar(' ');
  }
 }
}
  
putchar('\n');
}
 

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main() {
int n;
double A,B,C,N,M;
double e;
double le;
double x,xn;

int i,j;

scanf("%d",&n); while(getchar()!='\n');
for(i=0;i<n;i++) {
scanf("%lf %lf %lf %lf %lf %lf",&A,&B,&C,&M,&N,&e); while(getchar()!='\n');
printf("%lf %lf %lf %lf %lf %lf\n",A,B,C,M,N,e);
x=3.;

for(j=0;j<100;j++) {
 xn = C + ( A * x + M) / (B * x + N);
 printf("%lf + (%lf * %lf + %lf) / (%lf * %lf + %lf) = %lf\n",C,A,x,M,B,x,N,xn);
 printf("%lf -> %lf, le=%lf, e=%lf\n",xn,x,fabs(x-xn),e);
 le=fabs(x-xn);
 if(le<e) {printf("%lf\n",xn); break;}
 x=xn;
}
if(le>e) printf("DIVERGENT\n");
}
}

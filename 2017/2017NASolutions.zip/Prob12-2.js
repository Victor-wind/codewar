var stdin = require('system').stdin;
var stdout = require('system').stdout;

(function tutors() {
    var tests = parseInt(stdin.readLine(), 10),
        tutors, tutees, pairs, ii, jj, cur;

    for (cur = 0; cur < tests; cur++) {
        // JavaScript's array sort uses lexicographical order ... including a comparator function for numerical order
        tutors = stdin.readLine().trim().split(/\s/).slice(1).map(Number).sort(function (a, b) { return a - b; });
        tutees = stdin.readLine().trim().split(/\s/).slice(1).map(Number).sort(function (a, b) { return a - b; });

        for (ii = 0, jj = 0, pairs = 0; ii < tutors.length; ii++) {
            // Increment position variable (jj) in the tutees array as long as the tutor (ii) has a higher skill
            // The arrays are sorted, so you don't need to restart counting from the start of tutees each time
            while (jj < tutees.length && tutors[ii] > tutees[jj]) {
                jj++;
            }

            // For each tutor (ii), the value of jj represents the number of eligible tutees
            pairs += jj;
        }

        stdout.writeLine(pairs);
    }
})();
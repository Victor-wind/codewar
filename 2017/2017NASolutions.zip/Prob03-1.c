#include <stdio.h>
#define RATE 0.2999792
int main(){
double t[3];

scanf("%lf %lf %lf",&t[0],&t[1],&t[2]);
printf("%lf\n%lf\n%lf\n",t[0]*RATE,t[1]*RATE,t[2]*RATE);

}


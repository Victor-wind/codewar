var stdin = require('system').stdin;
var stdout = require('system').stdout;

(function momentousOccasion() {
    stdout.writeLine(stdin.readLine()
        .split(/\s/)
        .map(Number)
        .reduce(function(acc, val) {return acc * val;}, 1)
    );
})();
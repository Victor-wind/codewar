var stdin = require('system').stdin;
var stdout = require('system').stdout;

(function alternateRoute() {
    var tests = parseInt(stdin.readLine(), 10),
        line, miles, minutes;

    while (tests--) {
        line = stdin.readLine().split(/\s/);
        miles = line[0];
        minutes = line[1];

        stdout.writeLine(60 * miles / minutes);
    }
})();
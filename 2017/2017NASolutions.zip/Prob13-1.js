// Duke Wordwalker
// Code Wars program written in JavaScript for the RingoJS environment
//
// The MIT License (MIT)
//
// Copyright (c) 2016 Lee Jenkins
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

var stdin = require("system").stdin;
var stdout = require("system").stdout;

function main() {
    var GRID_WIDTH = 300; // more than double the max text length
    var xMin = GRID_WIDTH;
    var xMax = 0;
    var yMin = GRID_WIDTH;
    var yMax = 0;
    var x = 0;
    var y = 0;
    var dx = 1;
    var dy = 0;
    var grid = [ ];
    var BLANK_SPACE = " ";

    // initialize the grid with spaces;
    for( x=0; x<GRID_WIDTH; ++x ) {
        var row = [ ];
        for( y=0; y<GRID_WIDTH; ++y ) {
            row.push(BLANK_SPACE);
        }
        grid.push(row);
    }
    // initialize the start position
    x = GRID_WIDTH / 2;
    y = GRID_WIDTH / 2;

    // read the text and begin processing
    var text = stdin.readLine();
    for( var i=0; i<text.length; ++i ) {
        var c = text.charAt(i);
        if( c < BLANK_SPACE ) {
            c = BLANK_SPACE;
        }
        grid[x][y] = c;
        if( xMin > x ) xMin = x;
        if( xMax < x ) xMax = x;
        if( yMin > y ) yMin = y;
        if( yMax < y ) yMax = y;
        c = c.toUpperCase();
        if( c === "D" ) { dy =  1; dx =  0; }
        if( c === "U" ) { dy = -1; dx =  0; }
        if( c === "R" ) { dy =  0; dx =  1; }
        if( c === "L" ) { dy =  0; dx = -1; }
        x += dx;
        y += dy;
    }

    // now print the grid
    for( y = yMin; y <= yMax; ++y ) {
        var rowText = '';
        for( x = xMin; x <= xMax; ++x ) {
            rowText += grid[x][y];
        }
        stdout.writeLine(rowText);
    }
}

main();

var stdin = require('system').stdin;
var stdout = require('system').stdout;

(function deltaInversion() {
    var tests = parseInt(stdin.readLine(), 10),
        nums, deltas, res;

    while (tests--) {
        nums = stdin.readLine().split(' ').map(Number).slice(1);
        deltas = nums.map(function(v, i, a) {return v - a[i+1];}).slice(0, -1);
        res = deltas.reduce(function(a, v, i) { return a.concat(v + a[i])}, [nums[0]]);
        stdout.writeLine(res.join(' '));
    }
})();
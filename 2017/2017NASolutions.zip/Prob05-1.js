var stdin = require('system').stdin;
var stdout = require('system').stdout;

(function spaceRace() {
    var teams = parseInt(stdin.readLine(), 10),
        bestTeam, bestTime, cur;

    while (teams--) {
        cur = stdin.readLine().split(/\s/);
        bestTime = bestTime || cur[1] / cur[2];
        bestTeam = bestTeam || cur[0];

        if (cur[1] / cur[2] < bestTime) {
            bestTime = cur[1] / cur[2];
            bestTeam = cur[0];
        }
    }

    stdout.writeLine(bestTeam + ' ' + bestTime);
})();
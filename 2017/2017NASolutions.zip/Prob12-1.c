#include <stdio.h>
#define MAX 100000

int tutors[MAX];
int tutees[MAX];
int matches;

void setup(){
int i;
for(i=0;i<MAX;i++) tutors[i]=tutees[i]=0;
matches=0;}

int main(){
int cases,c;
int ors,ees;
int i,o,e;
scanf("%d",&cases); while(getchar()!='\n');
/** printf("There are %d cases\n",cases); **/
for(c=0;c<cases;c++) {
 setup();
 scanf("%d",&ors);  
 /** printf("There are %d tutors\n",ors); **/
 for(i=0;i<ors;i++) scanf("%d ",&tutors[i]); 
 /** printf("tutors:"); for(i=0;i<ors;i++) printf("%d ",tutors[i]); printf("\n"); **/

 scanf("%d",&ees); 
 /** printf("There are %d tutees\n",ees); **/
 for(i=0;i<ees;i++) scanf("%d",&tutees[i]); 
 /** printf("tutees:"); for(i=0;i<ees;i++) printf("%d ",tutees[i]); printf("\n"); **/

 for(o=0;o<ors;o++)
  for(e=0;e<ees;e++)
   if(tutors[o]>tutees[e]) matches++;
 printf("%d\n",matches);
}
}

 


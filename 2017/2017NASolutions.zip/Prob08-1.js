var stdin = require('system').stdin;
var stdout = require('system').stdout;

(function parity() {
    function bitCount(num) {
        // Convert to a binary string and use a regular expression to count the ones ... empty array for the zero case.
        return (num.toString(2).match(/1/g) || []).length;
    }

    function getCount(num) {
        if (num < 0) {
            return 0;
        }

        if (num % 2 == 0) {
            // If num is even, the count of numbers from zero to num with even parity
            // is equal to num divided by two plus one if num has even parity itself
            return Math.floor(num / 2) + (bitCount(num) % 2 == 0 ? 1 : 0);
        }

        return Math.floor(num / 2) + 1;
    }

    var line, a, b;
    while (true) {
        line = stdin.readLine().trim().split(/\s/);
        a = parseInt(line[0], 10);
        b = parseInt(line[1], 10);

        if (a === 0 && b === 0) {
            break;
        }

        // The count of numbers with with even parity between a and b (inclusive)
        // is equal to the count of numbers with even parity from zero to b
        // minus the count of numbers with even parity from zero to a minus one
        stdout.writeLine(getCount(b) - getCount(a-1));
    }
})();
#!/usr/bin/env python
# Author: Sebastian.Schagerer@hpe.com

import sys

lines = sys.stdin.readlines()
(rows, cols, threshold) = lines[0].split(" ")
word_lengths = lines[1].split(" ")

# print int(threshold)
alpha = dict()

for r in range(2, int(rows) + 2):
    row = lines[r]
    letters = row.split(" ")
    for char in letters:
        c = char.strip()
        count = alpha.get(c)
        if count is None:
            count = 0
        count += 1
        alpha.update({c: count})
        # print "line %d is %s" % (r, row)

# print alpha

eliminate = []
for char in alpha:
    # print char
    # print int(alpha.get(char))
    if int(alpha.get(char)) >= int(threshold):
        eliminate.append(char.strip())

# print eliminate

message = []
for r in range(2, int(rows) + 2):
    row = lines[r]
    for c in row.split(" "):
        if c.strip() not in eliminate:
            message.append(c.strip())

# print message

word_length = 0
for word_len in word_lengths[1:]:
    # print w
    for i in range(0, int(word_len)):
        print message[i + word_length],
    print " ",
    word_length += int(word_len)

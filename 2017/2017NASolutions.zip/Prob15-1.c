#include <stdio.h>
#include <stdlib.h>
#define D 8
#define M 7

char *dn[D] = {
"X",
"Linear", 
"Fibonacci", 
"Tribonacci", 
"Normal", 
"Zipf", 
"Prime", 
"Gaussian"
};

int dv[D][6] = {
{0,0,0,0,0,0},
{1,2,3,4,5,6}, 
{0,1,1,2,3,5}, 
{0,0,1,1,2,4}, 
{1,2,2,3,3,4}, 
{1,1,1,2,2,3}, 
{0,1,2,3,5,7}, 
{1,2,3,3,4,5}
};


int v[M*3+1];
int d[3];
int l[3];
char n[3];

void reset(){
int i;
for(i=0;i<M*3+1;i++) v[i]=0;
for(i=0;i<3;i++) d[i]=0;
}

void pick(){
int i,j;
for(i=0;i<3;i++)
 for(j=0;j<D;j++) 

  if(n[i]==dn[j][0])  {
   d[i]=j;

 /* printf("check: %c == %s (%d)\n",n[i],dn[d[i]],d[i]); */
}
}

void calc() {
int q[3];

for(q[0]=0;q[0]<6;q[0]++)
 for(q[1]=0;q[1]<6;q[1]++)
  if(d[2])
   for(q[2]=0;q[2]<6;q[2]++) 
    v[dv[d[0]][q[0]]+dv[d[1]][q[1]]+dv[d[2]][q[2]]]++;
  else
   v[dv[d[0]][q[0]]+dv[d[1]][q[1]]]++;
}

void print(){
int i,j;
int t;
int c;
double r;

for(i=0;i<3;i++)
 printf("%c%s",n[i],(i==2)?"\n":" ");

for(t=1,i=0;i<3;i++) 
 if(n[i]!='X') t*=6;

for(i=0;i<3;i++)
 for(j=0;j<M*3+1;j++) {
 r= 100.0 * (double)v[j];
 r/= (double) t;
  if(l[i]==j)
   printf("%d\t%d\t%.2f%%\n",j,v[j],r);
 }
}

int main() {
for(;;) {
reset();
scanf("%c %c %c %d %d %d", &n[0], &n[1], &n[2], &l[0], &l[1], &l[2]);
while(getchar()!='\n'); 
if((n[0]=='X')&&(n[1]=='X')&&(n[2]=='X')) exit(0);
pick();
calc();
print();
}
}


#include <stdio.h>
#include <stdlib.h>

#define DIM 100
char grid[DIM][DIM];
int r,c;
int fi,fj;

void print() {
int i;
grid[fj][fi]='@';
for(i=0;i<r;i++)
 printf("%s",grid[i]);
}

void play(x,y) int x,y;  {
char t;

if(grid[x][y]=='X')
 {print(); exit(0); }

if((grid[x][y]==' ')||(grid[x][y]=='@')) {
t=grid[x][y];
grid[x][y]='*';
if(x>0) play(x-1,y);
if(x<r) play(x+1,y);
if(y>0) play(x,y-1);
if(y<c) play(x,y+1);

if((x>0)&&(y>0)) play(x-1,y-1);
if((x<r)&&(y>0)) play(x+1,y-1);
if((x>0)&&(y<c)) play(x-1,y+1);
if((x<r)&&(y<c)) play(x+1,y+1);

grid[x][y]=t;
}

}

int main() {
int i,j;
int f;
scanf("%d %d",&c,&r); while(getchar()!='\n');
for(i=0;i<r;i++)
 fgets(grid[i],DIM,stdin);
for(j=0;j<r;j++)
 for(i=0;i<c;i++)
  if(grid[j][i]=='@') {fi=i;fj=j;}
play(fj,fi);
}

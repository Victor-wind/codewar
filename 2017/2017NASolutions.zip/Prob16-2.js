// Letter Cubes
// Code Wars program written in JavaScript for the RingoJS environment
//
// the problem description was originally written with the word "dice"
// instead of "cubes" and this program was written using dice naming.
//
// The MIT License (MIT)
//
// Copyright (c) 2016 Lee Jenkins
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

var stdin = require("system").stdin;
var stdout = require("system").stdout;

function prune( word, dice ) {
    var prunedDice = [ ];
    for( var d=0; d<dice.length; ++d ) {
        var prunedDie = [ ];
        for( var f=0; f<6; ++f ) {
            var letter = dice[d][f];
            if( word.search( letter ) >= 0 ) {
                prunedDie.push( letter );
            }
        }
        if( prunedDie.length ) {
            prunedDice.push( prunedDie );
        }
    }
    return prunedDice;
}

function formWord( word, letterPosition, dice ) {
    if( letterPosition === word.length ) {
        return true;
    }
    var letter = word[ letterPosition ];
    for( var d=0; d<dice.length; ++d ) {
        var die = dice[d];
        for( var f=0; f<die.length; ++f ) {
            if( die[f] === letter ) {
                var newDice = [ ];
                for( var n=0; n<dice.length; ++n ) {
                    if( n !== d ) {
                        newDice.push( dice[n] );
                    }
                }
                if( formWord( word, letterPosition+1, newDice ) ) {
                    return true;
                }
            }
        }
    }
    return false;
}

function canBeFormed( word, dice ) {
    var prunedDice = prune( word, dice );
    var letterPosition = 0;
    return word.length <= prunedDice.length &&
           formWord( word, letterPosition, prunedDice );
}

function wordAnalysis( dice ) {
    var numberOfWords = parseInt( stdin.readLine() );
    for( var i=0; i<numberOfWords; ++i ) {
        var word = stdin.readLine().replace(/\s/g,"");
        var canForm = "can";
        if( !canBeFormed( word, dice ) ) {
            canForm = "CANNOT";
        }
        stdout.writeLine( word + " " + canForm + " be formed." );
    }
}

function readDice() {
    var numberOfDice = parseInt( stdin.readLine() );
    var dice = [ ];
    for( var i=0; i<numberOfDice; ++i ) {
        dice.push( stdin.readLine().replace(/\n/,'').split(' ') );
    }
    return dice;
}

function main() {
    var dice = readDice();
    wordAnalysis( dice );
}

main();

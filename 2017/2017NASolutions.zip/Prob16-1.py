#!/usr/bin/env python
# Author: Sebastian.Schagerer@hpe.com

import sys


def word_in_cubes(in_cubes, in_word):
    # print "w=%s c=%s" % (word, in_cubes)

    # Craete local copy of cubes
    # TODO: lambda or built-in function??
    cubes = []
    for in_cube in in_cubes:
        cubes.append(in_cube)

    # No more letters
    if len(in_word) == 0:
        return True

    # More letters than cubes
    if len(in_word) > len(cubes):
        return False

    # Last letter, one or more cubes
    if len(in_word) == 1 and len(cubes) > 0:
        found_letter = False
        for a_cube in cubes:
            if in_word[0] in a_cube:
                found_letter = True
        return found_letter

    for cu in cubes:
        if in_word[0] in cu:
            cubes.remove(cu)
            return word_in_cubes(cubes, in_word[1:])

    # print "ERROR: %s %s" % (word, lcubes)
    return False


num_cubes = sys.stdin.readline().strip()
all_cubes = []
for c in range(0, int(num_cubes)):
    line = sys.stdin.readline().split(" ")
    cube = []
    for letter in line:
        cube.append(letter.strip())
    all_cubes.append(cube)

# print cubes

num_words = sys.stdin.readline().strip()
words = []
for w in range(0, int(num_words)):
    words.append(sys.stdin.readline().strip())

# print words

for word in words:
    can_be_formed = word_in_cubes(all_cubes, word)
    if can_be_formed:
        message = "can"
    else:
        message = "CANNOT"

    print "{} {} be formed".format(word, message)

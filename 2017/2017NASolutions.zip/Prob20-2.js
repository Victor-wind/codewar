// Yet Another Maze Solver
// Code Wars program written in JavaScript for the RingoJS environment
//
// The MIT License (MIT)
//
// Copyright (c) 2016 Lee Jenkins
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

var system = require("system");
var stdin = require("system").stdin;
var stdout = require("system").stdout;

function readMaze() {
    var tokens = stdin.readLine().replace(/\n/,'').split(' ');
    var width = parseInt(tokens[0]);
    var height = parseInt(tokens[1]);
    var maze = [ ];
    for( var r=0; r<height; ++r ) {
        var row = stdin.readLine().replace(/\n/,'').split('');
        if( row.length !== width ) {
            stdout.writeLine("ERROR: width should be "+width+", but line length is "+row.length);
            system.exit(1);
        }
        maze.push( row );
    }
    return maze;
}

function findStart(maze) {
    var startPoint = { x: 0, y: 0 };
    for( var y=0; y<maze.length; ++y ) {
        for( var x=0; x<maze[y].length; ++x ) {
            if( maze[y][x] === '@' ) {
                startPoint = { x: x, y: y };
            }
        }
    }
    return startPoint;
}

var moves = [
    { dx:  1, dy:  1 },
    { dx:  1, dy:  0 },
    { dx:  1, dy: -1 },
    { dx:  0, dy: -1 },
    { dx: -1, dy: -1 },
    { dx: -1, dy:  0 },
    { dx: -1, dy:  1 },
    { dx:  0, dy:  1 }
];

function findPath( maze, locus ) {
    // printMaze( maze );
    for( var m=0; m<moves.length; ++m ) {
        var locusPrime = {
            x: locus.x + moves[m].dx,
            y: locus.y + moves[m].dy
        };
        if( maze[ locusPrime.y ][ locusPrime.x ] === 'X' ) {
            return true;
        }
        if( maze[ locusPrime.y ][ locusPrime.x ] === ' ' ) {
            maze[ locusPrime.y ][ locusPrime.x ] = '#';
            if( findPath( maze, locusPrime ) ) {
                return true;
            }
            maze[ locusPrime.y ][ locusPrime.x ] = ' ';
        }
    }
    return false;
}

function printMaze( maze ) {
    for( var y=0; y<maze.length; ++y ) {
        stdout.writeLine(maze[y].join(''));
    }
}

function main() {
    var maze = readMaze();
    var locus = findStart(maze);
    findPath( maze, locus );
    printMaze( maze );
}

main();

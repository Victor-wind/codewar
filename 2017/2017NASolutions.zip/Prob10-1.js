let stdin = require('system').stdin;
let stdout = require('system').stdout;

(function giantPalindromes() {
    let tests = parseInt(stdin.readLine(), 10);
    const minLength = 2,
          maxLength = 78;

    while (tests--) {
        let line = stdin.readLine().trim(),
            best = '';

        for (let i = 0; i + minLength <= line.length; i++) {
            // Palindrome must start with a letter or number
            if (isAlphanumeric(line[i]) === false) {
                continue;
            }

            for (let j = i + minLength; j <= line.length; j++) {
                // Palindrome must end with a letter or number
                // Using [j-1] since the second parameter in substring
                // represents the index of the last character NOT to include
                // in the returned substring
                if (isAlphanumeric(line[j-1]) === false) {
                    continue;
                }

                let candidate = line.substring(i, j);

                if (isPalindrome(candidate) && isLonger(candidate, best)) {
                    best = candidate;
                }
            }
        }
        
        stdout.writeLine(best ? best : 'NO PALINDROME');
    }

    function isLonger(candidate, current) {
        let regex = /[^a-z0-9]/gi;

        return candidate.replace(regex,'').length > current.replace(regex, '').length;
    }

    function isAlphanumeric(str) {
        return /^[a-z0-9]+$/i.test(str);
    }

    function isPalindrome(str) {
        // Palindrome calculation is not case sensitive
        str = str.toLowerCase();

        let i = 0, j = str.length - 1;
        while (i <= j) {
            if (str[i] !== str[j]) {
                return false;
            }

            // Move to the next characters
            i++;
            j--;

            // Skip over interior characters that are not alphanumeric
            while(isAlphanumeric(str[i]) === false) {
                i++;
            }
            while (isAlphanumeric(str[j]) === false) {
                j--;
            }
        }

        return true;
    }
})();
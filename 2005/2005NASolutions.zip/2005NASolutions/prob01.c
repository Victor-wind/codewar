#include <stdio.h>
#include <conio.h>

void main()
{
  char JudgesName[80];

  printf("Code Wars 6 - Problem #1 - Introduction\n");

  printf("\n\nPlease enter your name: ");
  scanf("%20s", JudgesName);

  printf("\n\nHello %s!\n", JudgesName);
  printf("We are Athens High School Lions: Mike Davis, Anh Nguyen, and Isok Patel\n");
}

